import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  Batch, 
  SubBatch, 
  RiderNode, 
  ShelterNode, 
  DonorNode, 
  AuditEvent, 
  AidItemType,
  PrerequisiteStatus,
  UserProfile,
  UserRole,
  RealtimeNotification,
  DonationHistoryRecord,
  FoodSafetyCheck
} from '../types';

interface UploadSurplusInput {
  title: string;
  donorId: string;
  itemType: AidItemType;
  dietaryType: 'veg' | 'non_veg' | 'vegan' | 'jain';
  quantity: number;
  maxSafeMinutes: number;
  pickupAddress: string;
  preparedTempC: number;
  packagingSealed: boolean;
  allergenFlags: string[];
  prerequisites: (keyof PrerequisiteStatus)[];
}

interface SimulationContextType {
  // State
  batches: Batch[];
  riders: RiderNode[];
  shelters: ShelterNode[];
  donors: DonorNode[];
  auditLogs: AuditEvent[];
  notifications: RealtimeNotification[];
  donationHistory: DonationHistoryRecord[];
  simulationSpeed: number; // 0, 1, 5, 15
  isPaused: boolean;
  virtualTimeElapsedSeconds: number;
  activeScenarioId: string | null;
  currentUser: UserProfile | null;

  // Auth / Role Selection
  login: (profile: UserProfile) => void;
  logout: () => void;
  switchRole: (role: UserRole, id?: string) => void;

  // Real-time Notifications
  markNotificationAsRead: (id: string) => void;
  clearNotifications: () => void;

  // Controls
  setSimulationSpeed: (speed: number) => void;
  togglePause: () => void;
  resetToInitial: () => void;

  // Core Platform Operations (Requested in prompt)
  uploadSurplusFood: (input: UploadSurplusInput) => void;
  riderAcceptPickup: (subBatchId: string, riderId: string) => void;
  receiverRequestFood: (batchId: string, shelterId: string, requestedQuantity: number) => void;
  completeDelivery: (subBatchId: string) => void;

  // Failure Simulators & Invariants
  triggerGhostRiderStall: (riderId?: string) => void;
  triggerMidTransitShelterClosure: (shelterId?: string, donatedCount?: number) => void;
  triggerBulkSurgePartition: (quantity?: number, expiryMinutes?: number) => void;
  triggerDependencyDispatchTest: (shelterId?: string) => void;
  resolvePrerequisite: (shelterId: string, prerequisiteKey: keyof PrerequisiteStatus) => void;
  
  // Direct Actions
  sendRiderHeartbeat: (riderId: string) => void;
  manualReassignSubBatch: (subBatchId: string, newRiderId: string) => void;
  manualRerouteSubBatch: (subBatchId: string, newShelterId: string) => void;
}

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

// Initial Seed Data grounded in the Problem Statement
const INITIAL_DONORS: DonorNode[] = [
  {
    id: 'donor_grand_palace',
    name: 'Grand Palace Convention & Banquet',
    type: 'banquet_hall',
    address: 'Sector 4, Central Avenue, Tech Zone',
    x: 24,
    y: 28,
    contactPerson: 'Chef Virender Singh',
    phone: '+91 98230 11442',
    fssaiNumber: '10018022007844',
    rating: 4.9,
    totalDonationsCount: 142
  },
  {
    id: 'donor_city_mess',
    name: 'Tech Campus Central Dining Mess',
    type: 'hostel_mess',
    address: 'North Tech Campus, Gate 3, Sector 8',
    x: 52,
    y: 18,
    contactPerson: 'Manager Suresh Patil',
    phone: '+91 98450 77123',
    fssaiNumber: '10019011004120',
    rating: 4.7,
    totalDonationsCount: 88
  },
  {
    id: 'donor_apex_pharmacy',
    name: 'Apex Medico Cold Storage Depot',
    type: 'pharmacy',
    address: 'Civil Lines Medical Complex, Block B',
    x: 18,
    y: 65,
    contactPerson: 'Dr. Neha Kulkarni',
    phone: '+91 97110 55901',
    fssaiNumber: 'MH-FDA-2024-88',
    rating: 5.0,
    totalDonationsCount: 31
  },
  {
    id: 'donor_metro_kitchen',
    name: 'Metro Civic Relief Central Kitchen',
    type: 'community_kitchen',
    address: 'Eastern Ring Bypass, Near Toll Gate',
    x: 78,
    y: 35,
    contactPerson: 'Harish Nair',
    phone: '+91 98330 44882',
    fssaiNumber: '10020033005519',
    rating: 4.8,
    totalDonationsCount: 205
  }
];

const INITIAL_SHELTERS: ShelterNode[] = [
  {
    id: 'shelter_alpha',
    name: 'North Railway Night Shelter',
    type: 'night_shelter',
    address: 'Platform 6 Approach, North Terminal Yard',
    x: 72,
    y: 22,
    capacityMax: 50,
    currentOccupants: 45,
    demandRemaining: {
      cooked_meals: 50,
      cold_chain_medicine: 0,
      infant_formula: 15,
      raw_ration_kits: 0
    },
    prerequisites: {
      cleanWater: true,
      cookingFuel: true,
      coldStorage: false,
      verifiedShelter: true
    },
    contactPerson: 'Sister Thomas',
    phone: '+91 98190 22001',
    verifiedStatus: true,
    receivedMealsTotal: 3420
  },
  {
    id: 'shelter_bravo',
    name: 'Riverside Community Aid Center',
    type: 'community_center',
    address: 'Old Barrage Road, Ward 12, Riverbank',
    x: 48,
    y: 76,
    capacityMax: 70,
    currentOccupants: 60,
    demandRemaining: {
      cooked_meals: 70,
      cold_chain_medicine: 0,
      infant_formula: 20,
      raw_ration_kits: 30
    },
    prerequisites: {
      cleanWater: true,
      cookingFuel: false, // Fuel absent!
      coldStorage: false,
      verifiedShelter: true
    },
    contactPerson: 'Mr. Arvind Joshi',
    phone: '+91 98220 88992',
    verifiedStatus: true,
    receivedMealsTotal: 2890
  },
  {
    id: 'shelter_charlie',
    name: 'East Flood Relief Camp Beta',
    type: 'flood_relief_camp',
    address: 'Submerged Lowlands Embankment Tent #4',
    x: 84,
    y: 68,
    capacityMax: 120,
    currentOccupants: 110,
    demandRemaining: {
      cooked_meals: 60,
      cold_chain_medicine: 25,
      infant_formula: 45,
      raw_ration_kits: 50
    },
    prerequisites: {
      cleanWater: false, // CONTAMINATED/NO WATER: Blocks raw rations and infant formula!
      cookingFuel: false,
      coldStorage: false,
      verifiedShelter: true
    },
    contactPerson: 'Camp Lead Ritu Sen',
    phone: '+91 99100 33441',
    verifiedStatus: true,
    receivedMealsTotal: 1540
  },
  {
    id: 'shelter_delta',
    name: 'St. Jude Geriatric Care Home',
    type: 'care_home',
    address: 'Hill View Road, Green Ridge Sector',
    x: 22,
    y: 82,
    capacityMax: 40,
    currentOccupants: 38,
    demandRemaining: {
      cooked_meals: 20,
      cold_chain_medicine: 40,
      infant_formula: 0,
      raw_ration_kits: 0
    },
    prerequisites: {
      cleanWater: true,
      cookingFuel: true,
      coldStorage: true, // Has solar powered cold chain vaccine fridge!
      verifiedShelter: true
    },
    contactPerson: 'Nurse Agnes D’Cruz',
    phone: '+91 98400 99112',
    verifiedStatus: true,
    receivedMealsTotal: 960
  },
  {
    id: 'shelter_echo',
    name: 'South Metro Transit Shelter',
    type: 'night_shelter',
    address: 'Bus Depot 9, Southern Ring Corridor',
    x: 36,
    y: 50,
    capacityMax: 60,
    currentOccupants: 35,
    demandRemaining: {
      cooked_meals: 45,
      cold_chain_medicine: 0,
      infant_formula: 10,
      raw_ration_kits: 20
    },
    prerequisites: {
      cleanWater: true,
      cookingFuel: true,
      coldStorage: false,
      verifiedShelter: true
    },
    contactPerson: 'Supervisor Imran Shaikh',
    phone: '+91 98770 11993',
    verifiedStatus: true,
    receivedMealsTotal: 2150
  }
];

const INITIAL_RIDERS: RiderNode[] = [
  {
    id: 'rider_arjun',
    name: 'Arjun Verma',
    vehicleType: 'scooter',
    maxCapacity: 45,
    currentCargoCount: 45,
    status: 'in_transit',
    x: 38,
    y: 42,
    targetX: 48,
    targetY: 76,
    reliabilityScore: 98,
    phone: '+91 98310 12001',
    lastHeartbeatSecondsAgo: 4,
    heartbeatThresholdSeconds: 25,
    activeSubBatchId: 'sub_batch_101_b',
    assignedShelterId: 'shelter_bravo',
    completedDeliveriesCount: 84,
    rating: 4.9
  },
  {
    id: 'rider_ravi',
    name: 'Ravi Teja',
    vehicleType: 'scooter',
    maxCapacity: 40,
    currentCargoCount: 40,
    status: 'claimed', // Simulator target for Ghost Stall
    x: 25,
    y: 31,
    targetX: 72,
    targetY: 22,
    reliabilityScore: 82,
    phone: '+91 98110 99443',
    lastHeartbeatSecondsAgo: 22, // ALMOST EXPIRED (25s SLA)
    heartbeatThresholdSeconds: 25,
    activeSubBatchId: 'sub_batch_101_a',
    assignedShelterId: 'shelter_alpha',
    completedDeliveriesCount: 41,
    rating: 4.6
  },
  {
    id: 'rider_maya',
    name: 'Maya Sundaram (Standby Reserve)',
    vehicleType: 'scooter',
    maxCapacity: 45,
    currentCargoCount: 0,
    status: 'standby',
    x: 27,
    y: 32, // Stationed right near Grand Palace banquet hall!
    reliabilityScore: 99,
    phone: '+91 98880 77112',
    lastHeartbeatSecondsAgo: 2,
    heartbeatThresholdSeconds: 30,
    completedDeliveriesCount: 112,
    rating: 5.0
  },
  {
    id: 'rider_alex',
    name: 'Alex D\'Souza',
    vehicleType: 'motorcycle',
    maxCapacity: 40,
    currentCargoCount: 40,
    status: 'in_transit',
    x: 58,
    y: 25, // Mid-transit towards Shelter Alpha!
    targetX: 72,
    targetY: 22,
    reliabilityScore: 95,
    phone: '+91 97660 33221',
    lastHeartbeatSecondsAgo: 5,
    heartbeatThresholdSeconds: 30,
    activeSubBatchId: 'sub_batch_101_c',
    assignedShelterId: 'shelter_alpha',
    completedDeliveriesCount: 76,
    rating: 4.9
  },
  {
    id: 'rider_tariq',
    name: 'Tariq Khan (Eco Van Fleet)',
    vehicleType: 'van',
    maxCapacity: 120,
    currentCargoCount: 0,
    status: 'available',
    x: 50,
    y: 48,
    reliabilityScore: 97,
    phone: '+91 98220 55009',
    lastHeartbeatSecondsAgo: 3,
    heartbeatThresholdSeconds: 35,
    completedDeliveriesCount: 135,
    rating: 4.8
  },
  {
    id: 'rider_fatima',
    name: 'Fatima Noor',
    vehicleType: 'bicycle',
    maxCapacity: 20,
    currentCargoCount: 0,
    status: 'available',
    x: 75,
    y: 25,
    reliabilityScore: 96,
    phone: '+91 98990 66228',
    lastHeartbeatSecondsAgo: 6,
    heartbeatThresholdSeconds: 30,
    completedDeliveriesCount: 52,
    rating: 4.9
  }
];

const INITIAL_BATCHES: Batch[] = [
  {
    id: 'batch_101',
    donorId: 'donor_grand_palace',
    donorName: 'Grand Palace Convention & Banquet',
    itemType: 'cooked_meals',
    dietaryType: 'veg',
    title: 'Surplus Fresh Cooked Biryani & Dal Makhani',
    description: 'Hot hygienic banquet surplus packed in food-grade thermal containers. 180 portions.',
    totalQuantity: 180,
    unit: 'meals',
    preparedTimeAgoMinutes: 20,
    maxSafeMinutes: 75,
    remainingSafeMinutes: 55,
    prerequisitesNeeded: ['verifiedShelter'],
    status: 'partitioned',
    createdAtTime: '23:30',
    pickupAddress: 'Sector 4, Central Avenue, Tech Zone',
    spoilagePreventedMeals: 0,
    safetyCheck: {
      isVerified: true,
      preparedTempC: 72,
      currentTempC: 66,
      packagingSealed: true,
      hygieneInspector: 'Chef Virender (FSSAI QA)',
      allergenFlags: ['Dairy (Butter/Ghee)'],
      safeWindowMinutes: 75
    },
    subBatches: [
      {
        id: 'sub_batch_101_a',
        parentBatchId: 'batch_101',
        itemType: 'cooked_meals',
        quantity: 40,
        donorId: 'donor_grand_palace',
        riderId: 'rider_ravi',
        targetShelterId: 'shelter_alpha',
        originalShelterId: 'shelter_alpha',
        rerouted: false,
        status: 'claimed',
        pickupEtaMinutes: 8,
        deliveryEtaMinutes: 22,
        progressPercent: 15,
        claimedAtSecondsAgo: 24,
        autoReassignedCount: 0,
        otpCode: '8492'
      },
      {
        id: 'sub_batch_101_b',
        parentBatchId: 'batch_101',
        itemType: 'cooked_meals',
        quantity: 45,
        donorId: 'donor_grand_palace',
        riderId: 'rider_arjun',
        targetShelterId: 'shelter_bravo',
        originalShelterId: 'shelter_bravo',
        rerouted: false,
        status: 'in_transit',
        pickupEtaMinutes: 0,
        deliveryEtaMinutes: 14,
        progressPercent: 55,
        claimedAtSecondsAgo: 35,
        autoReassignedCount: 0,
        otpCode: '3194'
      },
      {
        id: 'sub_batch_101_c',
        parentBatchId: 'batch_101',
        itemType: 'cooked_meals',
        quantity: 45,
        donorId: 'donor_grand_palace',
        riderId: 'rider_alex',
        targetShelterId: 'shelter_alpha', // Target for Mid-transit sudden shelter closure!
        originalShelterId: 'shelter_alpha',
        fallbackShelterId: 'shelter_echo',
        rerouted: false,
        status: 'in_transit',
        pickupEtaMinutes: 0,
        deliveryEtaMinutes: 10,
        progressPercent: 62,
        claimedAtSecondsAgo: 30,
        autoReassignedCount: 0,
        otpCode: '5821'
      },
      {
        id: 'sub_batch_101_d',
        parentBatchId: 'batch_101',
        itemType: 'cooked_meals',
        quantity: 50,
        donorId: 'donor_grand_palace',
        targetShelterId: 'shelter_echo',
        originalShelterId: 'shelter_echo',
        rerouted: false,
        status: 'pending_rider',
        pickupEtaMinutes: 12,
        deliveryEtaMinutes: 28,
        progressPercent: 0,
        autoReassignedCount: 0,
        otpCode: '9012'
      }
    ]
  },
  {
    id: 'batch_102',
    donorId: 'donor_apex_pharmacy',
    donorName: 'Apex Medico Cold Storage Depot',
    itemType: 'cold_chain_medicine',
    dietaryType: 'veg',
    title: 'Short-Life Pediatric Insulin & Sterile Dressings',
    description: '40 vials cold-chain insulin requiring temperature verification below 8°C.',
    totalQuantity: 40,
    unit: 'vials',
    preparedTimeAgoMinutes: 15,
    maxSafeMinutes: 120,
    remainingSafeMinutes: 105,
    prerequisitesNeeded: ['coldStorage', 'verifiedShelter'],
    status: 'draft',
    createdAtTime: '23:40',
    pickupAddress: 'Civil Lines Medical Complex, Block B',
    spoilagePreventedMeals: 0,
    safetyCheck: {
      isVerified: true,
      preparedTempC: 4,
      currentTempC: 4.5,
      packagingSealed: true,
      hygieneInspector: 'Dr. Neha Kulkarni',
      allergenFlags: [],
      safeWindowMinutes: 120
    },
    subBatches: [
      {
        id: 'sub_batch_102_a',
        parentBatchId: 'batch_102',
        itemType: 'cold_chain_medicine',
        quantity: 40,
        donorId: 'donor_apex_pharmacy',
        targetShelterId: 'shelter_delta',
        originalShelterId: 'shelter_delta',
        rerouted: false,
        status: 'pending_rider',
        pickupEtaMinutes: 15,
        deliveryEtaMinutes: 30,
        progressPercent: 0,
        autoReassignedCount: 0,
        otpCode: '4481'
      }
    ]
  }
];

const INITIAL_NOTIFICATIONS: RealtimeNotification[] = [
  {
    id: 'notif_1',
    title: 'New Surplus Posted: 180 Cooked Meals',
    message: 'Grand Palace Convention posted hot Biryani with 75-min safe window. Decomposed into 4 scooter dispatches.',
    time: '2 mins ago',
    type: 'surplus_posted',
    isRead: false,
    targetRole: 'all'
  },
  {
    id: 'notif_2',
    title: 'Courier Dispatched: Alex D\'Souza',
    message: 'Courier Alex accepted Sub-batch #101-C (45 meals) en route to Shelter Alpha.',
    time: '5 mins ago',
    type: 'courier_accepted',
    isRead: false,
    targetRole: 'rider'
  },
  {
    id: 'notif_3',
    title: 'Heartbeat Decay Alert: Rider Ravi',
    message: 'Courier Ravi has not sent GPS breadcrumbs for 22s. Watchdog monitoring ghost reservation.',
    time: '1 min ago',
    type: 'safety_flag',
    isRead: false,
    targetRole: 'admin'
  }
];

const INITIAL_HISTORY: DonationHistoryRecord[] = [
  {
    id: 'hist_01',
    batchTitle: 'Fresh Pulao & Paneer Curry (120 Portions)',
    donorName: 'Tech Campus Central Dining Mess',
    receiverName: 'North Railway Night Shelter',
    riderName: 'Maya Sundaram',
    quantity: 120,
    unit: 'meals',
    completedAt: 'Yesterday, 22:15',
    co2SavedKg: 300,
    safetyScore: 99
  },
  {
    id: 'hist_02',
    batchTitle: 'Pediatric Sterile Kits & Insulin (30 Vials)',
    donorName: 'Apex Medico Depot',
    receiverName: 'St. Jude Geriatric Care Home',
    riderName: 'Alex D\'Souza',
    quantity: 30,
    unit: 'vials',
    completedAt: 'Yesterday, 19:40',
    co2SavedKg: 45,
    safetyScore: 100
  },
  {
    id: 'hist_03',
    batchTitle: 'Fresh Baked Bread & Vegetable Stew (90 Portions)',
    donorName: 'Grand Palace Banquet',
    receiverName: 'Riverside Community Aid Center',
    riderName: 'Arjun Verma',
    quantity: 90,
    unit: 'meals',
    completedAt: '2 days ago, 23:10',
    co2SavedKg: 225,
    safetyScore: 97
  }
];

const INITIAL_LOGS: AuditEvent[] = [
  {
    id: 'log_01',
    timestamp: '23:45:10',
    type: 'BATCH_SPLIT',
    severity: 'nominal',
    title: 'Bulk Batch Partitioned Automatically',
    description: '180 cooked meals from Grand Palace split into 4 sub-batches (40, 45, 45, 50) matching two-wheeler capacities.',
    entityId: 'batch_101'
  },
  {
    id: 'log_02',
    timestamp: '23:47:02',
    type: 'SLA_HEARTBEAT_WARNING',
    severity: 'warning',
    title: 'Heartbeat Decay Warning (Rider Ravi)',
    description: 'Volunteer Ravi stalled for 22 seconds without GPS ping while holding 40 meals. Ghost reservation threshold approaching.',
    entityId: 'rider_ravi'
  }
];

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [batches, setBatches] = useState<Batch[]>(INITIAL_BATCHES);
  const [riders, setRiders] = useState<RiderNode[]>(INITIAL_RIDERS);
  const [shelters, setShelters] = useState<ShelterNode[]>(INITIAL_SHELTERS);
  const [donors, setDonors] = useState<DonorNode[]>(INITIAL_DONORS);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>(INITIAL_LOGS);
  const [notifications, setNotifications] = useState<RealtimeNotification[]>(INITIAL_NOTIFICATIONS);
  const [donationHistory, setDonationHistory] = useState<DonationHistoryRecord[]>(INITIAL_HISTORY);
  
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [virtualTimeElapsedSeconds, setVirtualTimeElapsedSeconds] = useState<number>(0);
  const [activeScenarioId, setActiveScenarioId] = useState<string | null>(null);
  
  // Current user (null initially to display Role Login / Signup screen first)
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);

  const addAuditLog = (
    type: AuditEvent['type'], 
    severity: AuditEvent['severity'], 
    title: string, 
    description: string, 
    entityId?: string
  ) => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    const newLog: AuditEvent = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: timeStr,
      type,
      severity,
      title,
      description,
      entityId
    };
    setAuditLogs(prev => [newLog, ...prev.slice(0, 40)]);
  };

  const addNotification = (
    title: string,
    message: string,
    type: RealtimeNotification['type'],
    targetRole: UserRole | 'all' = 'all'
  ) => {
    const newNotif: RealtimeNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      title,
      message,
      time: 'Just now',
      type,
      isRead: false,
      targetRole
    };
    setNotifications(prev => [newNotif, ...prev.slice(0, 15)]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  // Main simulation tick loop
  useEffect(() => {
    if (isPaused || simulationSpeed === 0) return;

    const interval = setInterval(() => {
      const dtSeconds = simulationSpeed;
      setVirtualTimeElapsedSeconds(prev => prev + dtSeconds);

      // 1. Advance Batch safe shelf-life
      setBatches(prevBatches => {
        return prevBatches.map(batch => {
          const newRemaining = Math.max(0, batch.remainingSafeMinutes - (dtSeconds / 60));
          const isExpired = newRemaining <= 0;

          const updatedSubBatches = batch.subBatches.map(sb => {
            if (sb.status === 'in_transit') {
              const newProgress = Math.min(100, sb.progressPercent + (dtSeconds * 1.5));
              if (newProgress >= 100) {
                return {
                  ...sb,
                  progressPercent: 100,
                  status: 'delivered' as const,
                  deliveryEtaMinutes: 0
                };
              }
              const remainingMinutes = Math.max(1, Math.round((100 - newProgress) / 5));
              return {
                ...sb,
                progressPercent: newProgress,
                deliveryEtaMinutes: remainingMinutes
              };
            }
            if (isExpired && sb.status !== 'delivered') {
              return { ...sb, status: 'spoiled' as const };
            }
            return sb;
          });

          const allDelivered = updatedSubBatches.every(sb => sb.status === 'delivered');
          const status = isExpired ? 'expired_spoiled' : allDelivered ? 'completed' : batch.status;

          return {
            ...batch,
            remainingSafeMinutes: Number(newRemaining.toFixed(1)),
            status,
            subBatches: updatedSubBatches
          };
        });
      });

      // 2. Monitor Riders Heartbeats
      setRiders(prevRiders => {
        return prevRiders.map(rider => {
          if (rider.status === 'unresponsive') return rider;

          const newHeartbeat = rider.lastHeartbeatSecondsAgo + dtSeconds;

          // Ghost stall trigger
          if (
            rider.status === 'claimed' && 
            newHeartbeat >= rider.heartbeatThresholdSeconds && 
            rider.activeSubBatchId
          ) {
            return {
              ...rider,
              status: 'unresponsive',
              lastHeartbeatSecondsAgo: newHeartbeat,
              reliabilityScore: Math.max(40, rider.reliabilityScore - 15)
            };
          }

          if (rider.status === 'in_transit' && rider.targetX !== undefined && rider.targetY !== undefined) {
            const step = 0.05 * dtSeconds;
            const newX = rider.x + (rider.targetX - rider.x) * step;
            const newY = rider.y + (rider.targetY - rider.y) * step;
            return {
              ...rider,
              x: Number(newX.toFixed(1)),
              y: Number(newY.toFixed(1)),
              lastHeartbeatSecondsAgo: newHeartbeat > 20 ? 0 : newHeartbeat
            };
          }

          return {
            ...rider,
            lastHeartbeatSecondsAgo: newHeartbeat
          };
        });
      });

    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, simulationSpeed]);

  // Automated Watchdog: Ghost Claim Auto-Failover to Maya
  useEffect(() => {
    const unresponsiveRider = riders.find(r => r.status === 'unresponsive' && r.activeSubBatchId);
    if (!unresponsiveRider || !unresponsiveRider.activeSubBatchId) return;

    const subBatchId = unresponsiveRider.activeSubBatchId;
    const standbyRider = riders.find(r => r.status === 'standby' || r.status === 'available');

    if (standbyRider) {
      addAuditLog(
        'GHOST_CLAIM_DETECTED',
        'critical',
        `Ghost Reservation Revoked: ${unresponsiveRider.name}`,
        `Rider exceeded ${unresponsiveRider.heartbeatThresholdSeconds}s heartbeat SLA. Failover initiated to protect ${unresponsiveRider.currentCargoCount} perishable units.`,
        unresponsiveRider.id
      );

      addNotification(
        '⚠️ Ghost Claim Revoked',
        `${unresponsiveRider.name} stalled in traffic. Handover transferred to Standby Reserve ${standbyRider.name}.`,
        'safety_flag',
        'admin'
      );

      setTimeout(() => {
        setRiders(prev => prev.map(r => {
          if (r.id === unresponsiveRider.id) {
            return {
              ...r,
              activeSubBatchId: undefined,
              currentCargoCount: 0,
              status: 'unresponsive'
            };
          }
          if (r.id === standbyRider.id) {
            return {
              ...r,
              status: 'in_transit',
              activeSubBatchId: subBatchId,
              currentCargoCount: unresponsiveRider.currentCargoCount,
              targetX: 72,
              targetY: 22
            };
          }
          return r;
        }));

        setBatches(prev => prev.map(b => ({
          ...b,
          subBatches: b.subBatches.map(sb => {
            if (sb.id === subBatchId) {
              return {
                ...sb,
                riderId: standbyRider.id,
                status: 'in_transit',
                autoReassignedCount: sb.autoReassignedCount + 1,
                progressPercent: 20
              };
            }
            return sb;
          })
        })));

        addAuditLog(
          'AUTO_REASSIGNED',
          'resolved',
          `Auto-Recovery Success: Handed to ${standbyRider.name}`,
          `Batch re-dispatched to nearby reserve scooter. Safe shelf-life window preserved.`,
          standbyRider.id
        );
      }, 800);
    }
  }, [riders]);

  // Auth / Role Selection Handlers
  const login = (profile: UserProfile) => {
    setCurrentUser(profile);
    addAuditLog(
      'DELIVERY_SUCCESS',
      'nominal',
      `Session Initialized: ${profile.name}`,
      `Signed in as ${profile.role.toUpperCase()} (${profile.facilityOrVehicle})`,
      profile.id
    );
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const switchRole = (role: UserRole, id?: string) => {
    if (role === 'donor') {
      const target = donors.find(d => d.id === id) || donors[0];
      setCurrentUser({
        role: 'donor',
        id: target.id,
        name: target.contactPerson,
        facilityOrVehicle: target.name,
        phone: target.phone,
        locationName: target.address,
        isVerified: true
      });
    } else if (role === 'rider') {
      const target = riders.find(r => r.id === id) || riders[3]; // Alex D'Souza
      setCurrentUser({
        role: 'rider',
        id: target.id,
        name: target.name,
        facilityOrVehicle: `${target.vehicleType.toUpperCase()} (Capacity: ${target.maxCapacity})`,
        phone: target.phone,
        locationName: 'Zone 4 Urban Grid',
        isVerified: true
      });
    } else if (role === 'shelter') {
      const target = shelters.find(s => s.id === id) || shelters[0];
      setCurrentUser({
        role: 'shelter',
        id: target.id,
        name: target.contactPerson,
        facilityOrVehicle: target.name,
        phone: target.phone,
        locationName: target.address,
        isVerified: true
      });
    } else {
      setCurrentUser({
        role: 'admin',
        id: 'admin_command',
        name: 'Civic Dispatch Commander',
        facilityOrVehicle: 'Central Operations Command',
        phone: '+91 80000 00100',
        locationName: 'City Command HQ',
        isVerified: true
      });
    }
  };

  const togglePause = () => setIsPaused(prev => !prev);

  const resetToInitial = () => {
    setBatches(INITIAL_BATCHES);
    setRiders(INITIAL_RIDERS);
    setShelters(INITIAL_SHELTERS);
    setDonors(INITIAL_DONORS);
    setAuditLogs(INITIAL_LOGS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setActiveScenarioId(null);
    setVirtualTimeElapsedSeconds(0);
  };

  // Core Platform Function 1: Donors upload surplus food
  const uploadSurplusFood = (input: UploadSurplusInput) => {
    const donor = donors.find(d => d.id === input.donorId) || donors[0];
    const newBatchId = `batch_${Date.now()}`;
    const chunkSize = 45; // Scooter limit
    const parcelCount = Math.ceil(input.quantity / chunkSize);
    const subBatches: SubBatch[] = [];

    const availableShelters = shelters.filter(s => s.demandRemaining[input.itemType] > 0);

    for (let i = 0; i < parcelCount; i++) {
      const chunkQty = Math.min(chunkSize, input.quantity - (i * chunkSize));
      const targetShelter = availableShelters[i % (availableShelters.length || 1)] || shelters[0];
      
      subBatches.push({
        id: `sub_${newBatchId}_${i + 1}`,
        parentBatchId: newBatchId,
        itemType: input.itemType,
        quantity: chunkQty,
        donorId: donor.id,
        targetShelterId: targetShelter.id,
        originalShelterId: targetShelter.id,
        rerouted: false,
        status: 'pending_rider',
        pickupEtaMinutes: 10,
        deliveryEtaMinutes: 25,
        progressPercent: 0,
        autoReassignedCount: 0,
        otpCode: String(Math.floor(1000 + Math.random() * 9000))
      });
    }

    const newBatch: Batch = {
      id: newBatchId,
      donorId: donor.id,
      donorName: donor.name,
      itemType: input.itemType,
      dietaryType: input.dietaryType,
      title: input.title,
      description: `Surplus food registered with strict temperature & hygiene checks. Auto-partitioned into ${parcelCount} courier legs.`,
      totalQuantity: input.quantity,
      unit: input.itemType === 'cold_chain_medicine' ? 'vials' : 'meals',
      preparedTimeAgoMinutes: 0,
      maxSafeMinutes: input.maxSafeMinutes,
      remainingSafeMinutes: input.maxSafeMinutes,
      prerequisitesNeeded: input.prerequisites,
      status: 'partitioned',
      createdAtTime: 'Just now',
      pickupAddress: input.pickupAddress || donor.address,
      subBatches,
      safetyCheck: {
        isVerified: true,
        preparedTempC: input.preparedTempC,
        currentTempC: input.preparedTempC,
        packagingSealed: input.packagingSealed,
        hygieneInspector: `${donor.contactPerson} (Certified QA)`,
        allergenFlags: input.allergenFlags,
        safeWindowMinutes: input.maxSafeMinutes
      }
    };

    setBatches(prev => [newBatch, ...prev]);

    addNotification(
      `New Surplus: ${input.title}`,
      `${donor.name} logged ${input.quantity} portions with ${input.maxSafeMinutes}m safe window. Couriers alerted.`,
      'surplus_posted',
      'all'
    );

    addAuditLog(
      'BATCH_SPLIT',
      'nominal',
      `Surplus Logged: ${input.title}`,
      `${input.quantity} units partitioned into ${parcelCount} micro-courier parcels to match vehicle constraints.`,
      newBatchId
    );
  };

  // Core Platform Function 2: Riders view & accept pickup
  const riderAcceptPickup = (subBatchId: string, riderId: string) => {
    const rider = riders.find(r => r.id === riderId);
    if (!rider) return;

    setBatches(prev => prev.map(b => ({
      ...b,
      subBatches: b.subBatches.map(sb => {
        if (sb.id === subBatchId) {
          return {
            ...sb,
            riderId,
            status: 'claimed',
            claimedAtSecondsAgo: 0
          };
        }
        return sb;
      })
    })));

    setRiders(prev => prev.map(r => {
      if (r.id === riderId) {
        return {
          ...r,
          status: 'claimed',
          activeSubBatchId: subBatchId,
          lastHeartbeatSecondsAgo: 0
        };
      }
      return r;
    }));

    addNotification(
      'Pickup Request Accepted',
      `Courier ${rider.name} accepted delivery for Sub-batch #${subBatchId.split('_').pop()}. ETA to pickup: 6 mins.`,
      'courier_accepted',
      'all'
    );
  };

  // Core Platform Function 3: Receivers browse & request available food
  const receiverRequestFood = (batchId: string, shelterId: string, requestedQuantity: number) => {
    const shelter = shelters.find(s => s.id === shelterId);
    const batch = batches.find(b => b.id === batchId);
    if (!shelter || !batch) return;

    // Check prerequisites!
    if (batch.prerequisitesNeeded.includes('cleanWater') && !shelter.prerequisites.cleanWater) {
      addNotification(
        '⚠️ Request Blocked: Water Dependency Missing',
        `Cannot dispatch to ${shelter.name}: Facility lacks certified clean water. Safety invariant enforced.`,
        'safety_flag',
        'shelter'
      );
      return;
    }

    addNotification(
      'Food Donation Requested',
      `${shelter.name} requested ${requestedQuantity} portions of ${batch.title}. Dispatch auto-assigned.`,
      'surplus_posted',
      'all'
    );
  };

  // Core Platform Function 4: Complete Delivery & update Donation History
  const completeDelivery = (subBatchId: string) => {
    let completedSubBatch: SubBatch | undefined;
    let parentBatch: Batch | undefined;

    setBatches(prev => prev.map(b => {
      const sb = b.subBatches.find(s => s.id === subBatchId);
      if (sb) {
        completedSubBatch = sb;
        parentBatch = b;
      }
      return {
        ...b,
        subBatches: b.subBatches.map(s => {
          if (s.id === subBatchId) {
            return {
              ...s,
              status: 'delivered',
              progressPercent: 100,
              deliveryEtaMinutes: 0
            };
          }
          return s;
        })
      };
    }));

    if (completedSubBatch && parentBatch) {
      const rider = riders.find(r => r.id === completedSubBatch?.riderId);
      const shelter = shelters.find(s => s.id === completedSubBatch?.targetShelterId);
      const donor = donors.find(d => d.id === completedSubBatch?.donorId);

      // Add to donation history
      const newHistoryItem: DonationHistoryRecord = {
        id: `hist_${Date.now()}`,
        batchTitle: parentBatch.title,
        donorName: donor?.name || 'Verified Donor',
        receiverName: shelter?.name || 'Receiving Facility',
        riderName: rider?.name || 'Volunteer Courier',
        quantity: completedSubBatch.quantity,
        unit: parentBatch.unit,
        completedAt: 'Just now',
        co2SavedKg: Math.round(completedSubBatch.quantity * 2.5),
        safetyScore: 99
      };

      setDonationHistory(prev => [newHistoryItem, ...prev]);

      addNotification(
        '✓ Delivery Completed & Verified',
        `${completedSubBatch.quantity} ${parentBatch.unit} handed over to ${shelter?.name}. Spoilage avoided.`,
        'delivered',
        'all'
      );

      addAuditLog(
        'DELIVERY_SUCCESS',
        'nominal',
        `Safe Delivery Verified: ${subBatchId}`,
        `Handover signed at ${shelter?.name}. ${Math.round(completedSubBatch.quantity * 2.5)}kg CO2 emissions averted.`,
        subBatchId
      );
    }
  };

  // Failure Scenario Triggers
  const triggerGhostRiderStall = (riderId: string = 'rider_ravi') => {
    setActiveScenarioId('ghost_rider_stall');
    setRiders(prev => prev.map(r => {
      if (r.id === riderId) {
        return {
          ...r,
          status: 'unresponsive',
          lastHeartbeatSecondsAgo: 32,
          reliabilityScore: 65
        };
      }
      return r;
    }));

    addAuditLog(
      'SLA_HEARTBEAT_WARNING',
      'warning',
      'Ghost Volunteer Stall Induced',
      `Courier stalled with 40 hot meals. Watch automatic SLA detection and failover handover.`,
      riderId
    );
  };

  const triggerMidTransitShelterClosure = (
    shelterId: string = 'shelter_alpha', 
    donatedCount: number = 50
  ) => {
    setActiveScenarioId('shelter_closure_midtransit');
    
    setShelters(prev => prev.map(s => {
      if (s.id === shelterId) {
        return {
          ...s,
          demandRemaining: {
            ...s.demandRemaining,
            cooked_meals: 0
          },
          currentOccupants: s.capacityMax
        };
      }
      return s;
    }));

    addNotification(
      '⚠️ Shelter Demand Filled by Citizen',
      `Local donor dropped off 50 meals at Shelter Alpha. En route couriers are being dynamically rerouted.`,
      'rerouted',
      'all'
    );

    setTimeout(() => {
      const fallbackShelter = shelters.find(s => s.id === 'shelter_echo') || shelters[4];

      setBatches(prev => prev.map(b => ({
        ...b,
        subBatches: b.subBatches.map(sb => {
          if (sb.targetShelterId === shelterId && sb.status === 'in_transit') {
            return {
              ...sb,
              targetShelterId: fallbackShelter.id,
              originalShelterId: shelterId,
              fallbackShelterId: fallbackShelter.id,
              rerouted: true,
              rerouteReason: 'Destination shelter filled by citizen walk-in',
              deliveryEtaMinutes: 8,
              progressPercent: 30
            };
          }
          return sb;
        })
      })));

      setRiders(prev => prev.map(r => {
        if (r.id === 'rider_alex') {
          return {
            ...r,
            assignedShelterId: fallbackShelter.id,
            targetX: fallbackShelter.x,
            targetY: fallbackShelter.y
          };
        }
        return r;
      }));

      addAuditLog(
        'DYNAMIC_REROUTE',
        'critical',
        `Mid-Transit Dynamic Re-route Executed: Courier Alex`,
        `Collision avoided! Rider Alex carrying 45 meals dynamically rerouted to Shelter Echo (8 mins away). Safe shelf-life window preserved.`,
        'rider_alex'
      );
    }, 700);
  };

  const triggerBulkSurgePartition = (quantity: number = 180, expiryMinutes: number = 65) => {
    uploadSurplusFood({
      title: 'Mega Banquet Biryani Surplus',
      donorId: 'donor_grand_palace',
      itemType: 'cooked_meals',
      dietaryType: 'veg',
      quantity,
      maxSafeMinutes: expiryMinutes,
      pickupAddress: 'Grand Palace Convention Center',
      preparedTempC: 74,
      packagingSealed: true,
      allergenFlags: ['Dairy'],
      prerequisites: ['verifiedShelter']
    });
  };

  const triggerDependencyDispatchTest = (shelterId: string = 'shelter_charlie') => {
    setActiveScenarioId('dependency_safety_trap');
    const targetShelter = shelters.find(s => s.id === shelterId);
    
    if (targetShelter && !targetShelter.prerequisites.cleanWater) {
      addNotification(
        '⛔ Safety Invariant Blocked Dispatch',
        `Infant formula blocked for ${targetShelter.name}: Site lacks potable water. Bacterial infection risk.`,
        'safety_flag',
        'all'
      );
      addAuditLog(
        'DEPENDENCY_BLOCKED',
        'critical',
        `Safety Invariant Violated: Infant Formula Blocked for ${targetShelter.name}`,
        `DISPATCH HALTED: Camp lacks clean potable water. Reconstituting powder with floodwater poses deadly infantile bacterial infection risk. Dispatch water purification kits first.`,
        shelterId
      );
    }
  };

  const resolvePrerequisite = (shelterId: string, prerequisiteKey: keyof PrerequisiteStatus) => {
    setShelters(prev => prev.map(s => {
      if (s.id === shelterId) {
        return {
          ...s,
          prerequisites: {
            ...s.prerequisites,
            [prerequisiteKey]: true
          }
        };
      }
      return s;
    }));

    addNotification(
      'Prerequisite Certified',
      `Ground status for ${String(prerequisiteKey)} marked ACTIVE at ${shelterId}. Distribution unlocked.`,
      'safety_flag',
      'shelter'
    );
  };

  const sendRiderHeartbeat = (riderId: string) => {
    setRiders(prev => prev.map(r => {
      if (r.id === riderId) {
        return {
          ...r,
          lastHeartbeatSecondsAgo: 0,
          status: r.status === 'unresponsive' ? (r.activeSubBatchId ? 'in_transit' : 'available') : r.status
        };
      }
      return r;
    }));
  };

  const manualReassignSubBatch = (subBatchId: string, newRiderId: string) => {
    const targetRider = riders.find(r => r.id === newRiderId);
    if (!targetRider) return;

    setBatches(prev => prev.map(b => ({
      ...b,
      subBatches: b.subBatches.map(sb => {
        if (sb.id === subBatchId) {
          return {
            ...sb,
            riderId: newRiderId,
            status: 'claimed',
            autoReassignedCount: sb.autoReassignedCount + 1
          };
        }
        return sb;
      })
    })));

    setRiders(prev => prev.map(r => {
      if (r.id === newRiderId) {
        return { ...r, status: 'claimed', activeSubBatchId: subBatchId };
      }
      return r;
    }));
  };

  const manualRerouteSubBatch = (subBatchId: string, newShelterId: string) => {
    const targetShelter = shelters.find(s => s.id === newShelterId);
    if (!targetShelter) return;

    setBatches(prev => prev.map(b => ({
      ...b,
      subBatches: b.subBatches.map(sb => {
        if (sb.id === subBatchId) {
          return {
            ...sb,
            targetShelterId: newShelterId,
            rerouted: true,
            rerouteReason: 'Manual operator redirect'
          };
        }
        return sb;
      })
    })));
  };

  return (
    <SimulationContext.Provider
      value={{
        batches,
        riders,
        shelters,
        donors,
        auditLogs,
        notifications,
        donationHistory,
        simulationSpeed,
        isPaused,
        virtualTimeElapsedSeconds,
        activeScenarioId,
        currentUser,
        login,
        logout,
        switchRole,
        markNotificationAsRead,
        clearNotifications,
        setSimulationSpeed,
        togglePause,
        resetToInitial,
        uploadSurplusFood,
        riderAcceptPickup,
        receiverRequestFood,
        completeDelivery,
        triggerGhostRiderStall,
        triggerMidTransitShelterClosure,
        triggerBulkSurgePartition,
        triggerDependencyDispatchTest,
        resolvePrerequisite,
        sendRiderHeartbeat,
        manualReassignSubBatch,
        manualRerouteSubBatch
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};
