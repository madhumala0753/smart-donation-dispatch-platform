export type AidItemType = 
  | 'cooked_meals' 
  | 'cold_chain_medicine' 
  | 'infant_formula' 
  | 'raw_ration_kits';

export type UserRole = 'donor' | 'rider' | 'shelter' | 'admin';

export interface UserProfile {
  role: UserRole;
  id: string;
  name: string;
  facilityOrVehicle: string;
  phone: string;
  locationName: string;
  email?: string;
  avatar?: string;
  isVerified?: boolean;
}

export interface PrerequisiteStatus {
  cleanWater: boolean;
  cookingFuel: boolean;
  coldStorage: boolean;
  verifiedShelter: boolean;
}

export interface FoodSafetyCheck {
  isVerified: boolean;
  preparedTempC: number;
  currentTempC: number;
  packagingSealed: boolean;
  hygieneInspector: string;
  allergenFlags: string[];
  safeWindowMinutes: number;
}

export interface DonorNode {
  id: string;
  name: string;
  type: 'banquet_hall' | 'hostel_mess' | 'pharmacy' | 'community_kitchen' | 'restaurant' | 'supermarket';
  address: string;
  x: number; // 0-100 percentage for topology map
  y: number;
  contactPerson: string;
  phone: string;
  fssaiNumber?: string;
  rating?: number;
  totalDonationsCount?: number;
}

export interface ShelterNode {
  id: string;
  name: string;
  type: 'night_shelter' | 'flood_relief_camp' | 'care_home' | 'community_center' | 'orphanage';
  address: string;
  x: number;
  y: number;
  capacityMax: number;
  currentOccupants: number;
  demandRemaining: Record<AidItemType, number>;
  prerequisites: PrerequisiteStatus;
  contactPerson: string;
  phone: string;
  verifiedStatus?: boolean;
  receivedMealsTotal?: number;
}

export interface RiderNode {
  id: string;
  name: string;
  vehicleType: 'scooter' | 'motorcycle' | 'bicycle' | 'van';
  maxCapacity: number; // in items (e.g., meals or kits)
  currentCargoCount: number;
  status: 'available' | 'claimed' | 'in_transit' | 'unresponsive' | 'standby';
  x: number;
  y: number;
  targetX?: number;
  targetY?: number;
  reliabilityScore: number; // 0-100
  phone: string;
  lastHeartbeatSecondsAgo: number;
  heartbeatThresholdSeconds: number; // 30s in accelerated time = 10-15m real
  activeSubBatchId?: string;
  assignedShelterId?: string;
  completedDeliveriesCount?: number;
  rating?: number;
}

export interface SubBatch {
  id: string;
  parentBatchId: string;
  itemType: AidItemType;
  quantity: number;
  riderId?: string;
  donorId: string;
  targetShelterId: string;
  originalShelterId?: string;
  fallbackShelterId?: string;
  rerouted: boolean;
  rerouteReason?: string;
  status: 'pending_rider' | 'claimed' | 'in_transit' | 'delivered' | 'spoiled' | 'rerouting';
  pickupEtaMinutes: number;
  deliveryEtaMinutes: number;
  progressPercent: number; // 0 to 100 for transit
  claimedAtSecondsAgo?: number;
  autoReassignedCount: number;
  otpCode?: string;
}

export interface Batch {
  id: string;
  donorId: string;
  donorName: string;
  itemType: AidItemType;
  title: string;
  description: string;
  totalQuantity: number;
  unit: string;
  dietaryType: 'veg' | 'non_veg' | 'vegan' | 'jain';
  preparedTimeAgoMinutes: number;
  maxSafeMinutes: number;
  remainingSafeMinutes: number;
  prerequisitesNeeded: (keyof PrerequisiteStatus)[];
  status: 'draft' | 'partitioned' | 'all_dispatched' | 'completed' | 'spoilage_prevented' | 'expired_spoiled';
  subBatches: SubBatch[];
  safetyCheck: FoodSafetyCheck;
  createdAtTime: string;
  pickupAddress: string;
  spoilagePreventedMeals?: number;
}

export interface RealtimeNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'surplus_posted' | 'courier_accepted' | 'rerouted' | 'safety_flag' | 'delivered';
  isRead: boolean;
  targetRole?: UserRole | 'all';
}

export interface DonationHistoryRecord {
  id: string;
  batchTitle: string;
  donorName: string;
  receiverName: string;
  riderName: string;
  quantity: number;
  unit: string;
  completedAt: string;
  co2SavedKg: number;
  safetyScore: number;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  type: 
    | 'BATCH_SPLIT' 
    | 'GHOST_CLAIM_DETECTED' 
    | 'AUTO_REASSIGNED' 
    | 'DYNAMIC_REROUTE' 
    | 'DEPENDENCY_BLOCKED' 
    | 'DEPENDENCY_RESOLVED' 
    | 'DELIVERY_SUCCESS' 
    | 'SLA_HEARTBEAT_WARNING'
    | 'DIRECT_DONATION_CONFLICT';
  severity: 'nominal' | 'warning' | 'critical' | 'resolved';
  title: string;
  description: string;
  entityId?: string;
}
