import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { X, Plus, Package, Clock, ShieldCheck, Thermometer, MapPin, Check } from 'lucide-react';
import { AidItemType, PrerequisiteStatus } from '../types';

interface NewBatchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewBatchModal: React.FC<NewBatchModalProps> = ({ isOpen, onClose }) => {
  const { donors, uploadSurplusFood, currentUser } = useSimulation();

  const [title, setTitle] = useState('');
  const [donorId, setDonorId] = useState(currentUser?.id || donors[0]?.id || '');
  const [itemType, setItemType] = useState<AidItemType>('cooked_meals');
  const [dietaryType, setDietaryType] = useState<'veg' | 'non_veg' | 'vegan' | 'jain'>('veg');
  const [quantity, setQuantity] = useState(120);
  const [safeMinutes, setSafeMinutes] = useState(75);
  const [pickupAddress, setPickupAddress] = useState(currentUser?.locationName || 'Sector 4, Central Avenue');
  const [preparedTempC, setPreparedTempC] = useState(72);
  const [packagingSealed, setPackagingSealed] = useState(true);
  const [allergenNote, setAllergenNote] = useState('Dairy (Butter/Ghee)');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const prereqs: (keyof PrerequisiteStatus)[] = ['verifiedShelter'];
    if (itemType === 'cold_chain_medicine') prereqs.push('coldStorage');

    uploadSurplusFood({
      title,
      donorId,
      itemType,
      dietaryType,
      quantity,
      maxSafeMinutes: safeMinutes,
      pickupAddress,
      preparedTempC,
      packagingSealed,
      allergenFlags: allergenNote ? allergenNote.split(',').map(s => s.trim()) : [],
      prerequisites: prereqs
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-7 space-y-5">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">
                Food Safety Verified Listing
              </span>
            </div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight mt-1">
              Upload Surplus Food Batch
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              System auto-partitions bulk lots into scooter parcels with live GPS courier matching.
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Surplus Food Description & Dish Details *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. 180 Fresh Cooked Vegetable Biryani & Dal Makhani Portions"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Donor Facility</label>
              <select
                value={donorId}
                onChange={e => setDonorId(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium"
              >
                {donors.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Dietary Category</label>
              <select
                value={dietaryType}
                onChange={e => setDietaryType(e.target.value as any)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium"
              >
                <option value="veg">Vegetarian</option>
                <option value="non_veg">Non-Vegetarian</option>
                <option value="vegan">Vegan</option>
                <option value="jain">Jain Compliant</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Quantity (Portions / Meals) *</label>
              <input
                type="number"
                min="10"
                max="600"
                value={quantity}
                onChange={e => setQuantity(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono focus:outline-none focus:border-emerald-500 focus:bg-white font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Safe Shelf-Life (Minutes) *</label>
              <input
                type="number"
                min="15"
                max="180"
                value={safeMinutes}
                onChange={e => setSafeMinutes(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono focus:outline-none focus:border-emerald-500 focus:bg-white font-bold text-amber-700"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Pickup Address & Gate Number *</label>
            <input
              type="text"
              required
              value={pickupAddress}
              onChange={e => setPickupAddress(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
            />
          </div>

          {/* Mandatory Food Safety Check Box */}
          <div className="p-3.5 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-2">
            <span className="text-[11px] font-bold text-emerald-950 uppercase tracking-wider block">
              Mandatory Food Safety Check (Pre-Dispatch Audit)
            </span>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-emerald-800 text-[11px] mb-0.5">Cooking Temp (°C)</label>
                <input
                  type="number"
                  value={preparedTempC}
                  onChange={e => setPreparedTempC(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-emerald-300 rounded-lg text-emerald-950 font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-emerald-800 text-[11px] mb-0.5">Declared Allergens</label>
                <input
                  type="text"
                  placeholder="e.g. Dairy, Peanuts"
                  value={allergenNote}
                  onChange={e => setAllergenNote(e.target.value)}
                  className="w-full p-1.5 bg-white border border-emerald-300 rounded-lg text-emerald-950 text-xs"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 text-emerald-900 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={packagingSealed}
                onChange={e => setPackagingSealed(e.target.checked)}
                className="rounded border-emerald-300 text-emerald-600 focus:ring-0"
              />
              <span className="font-medium text-[11px]">Food grade thermal containers sealed with tamper hygiene tape</span>
            </label>
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md shadow-emerald-600/20 active:scale-95 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Verify & Dispatch Surplus</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
