import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Bike, 
  MapPin, 
  Navigation, 
  Clock, 
  Phone, 
  ShieldCheck, 
  AlertTriangle, 
  Maximize2, 
  ZoomIn, 
  ZoomOut, 
  Crosshair,
  Building2,
  Home,
  CheckCircle2,
  Radio,
  Sparkles
} from 'lucide-react';
import { RiderNode, ShelterNode, DonorNode, SubBatch } from '../types';

export const ZomatoDeliveryMap: React.FC = () => {
  const { 
    riders, 
    shelters, 
    donors, 
    batches, 
    sendRiderHeartbeat, 
    triggerGhostRiderStall,
    triggerMidTransitShelterClosure,
    completeDelivery
  } = useSimulation();

  const [selectedRiderId, setSelectedRiderId] = useState<string>('rider_alex');
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showTraffic, setShowTraffic] = useState<boolean>(true);

  // Active sub-batches
  const allSubBatches = batches.flatMap(b => b.subBatches.map(sb => ({ ...sb, parentBatch: b })));
  const currentRider = riders.find(r => r.id === selectedRiderId) || riders[0];
  const activeSubBatch = allSubBatches.find(sb => sb.id === currentRider?.activeSubBatchId);
  const targetShelter = shelters.find(s => s.id === activeSubBatch?.targetShelterId);
  const donor = donors.find(d => d.id === activeSubBatch?.donorId);

  // Waypoints for the selected active delivery route
  const startX = donor ? donor.x : 24;
  const startY = donor ? donor.y : 28;
  const riderX = currentRider?.x ?? 58;
  const riderY = currentRider?.y ?? 25;
  const endX = targetShelter ? targetShelter.x : 72;
  const endY = targetShelter ? targetShelter.y : 22;

  return (
    <div className="space-y-4">
      
      {/* Top Banner: Courier & Route Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-500 shadow-xs">
            <Bike className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Live Courier Navigation Track
              </h2>
              <span className="inline-flex items-center gap-1 text-[11px] font-mono font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                GPS Active
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Simulating turn-by-turn road micro-logistics with dynamic destination updates.
            </p>
          </div>
        </div>

        {/* Courier selector pills */}
        <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1 sm:pb-0">
          <span className="text-xs text-slate-400 font-medium whitespace-nowrap">Track Courier:</span>
          {riders.map(r => (
            <button
              key={r.id}
              onClick={() => setSelectedRiderId(r.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-full transition-all whitespace-nowrap border ${
                selectedRiderId === r.id
                  ? 'bg-rose-500 text-white border-rose-500 shadow-xs shadow-rose-500/20'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              🛵 {r.name.split(' ')[0]} {r.currentCargoCount > 0 ? `(${r.currentCargoCount})` : ''}
            </button>
          ))}
        </div>
      </div>

      {/* Main Map Box Styled like Zomato Live Delivery Tracking */}
      <div className="relative w-full aspect-[16/9] min-h-[440px] bg-[#f2efe9] rounded-2xl border border-slate-200 overflow-hidden shadow-sm select-none">
        
        {/* Realistic SVG City Map Layer with Roads, Rivers, Parks & Labels */}
        <svg 
          className="absolute inset-0 w-full h-full" 
          viewBox="0 0 1000 600" 
          preserveAspectRatio="none"
        >
          <defs>
            {/* Park pattern */}
            <linearGradient id="parkGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#dcfce7" />
              <stop offset="100%" stopColor="#bbf7d0" />
            </linearGradient>

            {/* River pattern */}
            <linearGradient id="waterGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e0f2fe" />
              <stop offset="100%" stopColor="#bae6fd" />
            </linearGradient>

            {/* Pulsing route glow */}
            <filter id="routeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#f43f5e" floodOpacity="0.3" />
            </filter>
          </defs>

          {/* Urban Green Spaces & Parks */}
          <path d="M 50 40 C 90 20, 160 50, 200 90 C 220 140, 150 180, 80 160 Z" fill="url(#parkGrad)" opacity="0.8" />
          <text x="110" y="100" fill="#15803d" fontSize="12" fontWeight="600" opacity="0.6">Central Park</text>

          <path d="M 680 320 C 740 300, 840 330, 890 380 C 900 460, 780 490, 720 440 Z" fill="url(#parkGrad)" opacity="0.8" />
          <text x="760" y="400" fill="#15803d" fontSize="12" fontWeight="600" opacity="0.6">Riverside Eco Zone</text>

          {/* Civic River Canal (Water body) */}
          <path 
            d="M 320 0 C 350 150, 410 280, 390 400 C 370 490, 390 550, 420 600" 
            fill="none" 
            stroke="url(#waterGrad)" 
            strokeWidth="48" 
            strokeLinecap="round" 
            opacity="0.85"
          />
          <text x="355" y="240" fill="#0284c7" fontSize="11" fontWeight="600" opacity="0.5" transform="rotate(70 355 240)">Civic Riverway Canal</text>

          {/* Secondary Street Grid (Light Grey Roads) */}
          <g stroke="#ffffff" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" opacity="0.95">
            {/* Horizontal streets */}
            <line x1="0" y1="120" x2="1000" y2="120" />
            <line x1="0" y1="260" x2="1000" y2="260" />
            <line x1="0" y1="410" x2="1000" y2="410" />
            <line x1="0" y1="520" x2="1000" y2="520" />

            {/* Vertical streets */}
            <line x1="180" y1="0" x2="180" y2="600" />
            <line x1="500" y1="0" x2="500" y2="600" />
            <line x1="720" y1="0" x2="720" y2="600" />
            <line x1="880" y1="0" x2="880" y2="600" />

            {/* Diagonal cross-streets */}
            <path d="M 0 350 L 320 180 L 700 260 L 1000 150" />
            <path d="M 120 600 L 400 410 L 780 500 L 1000 460" />
          </g>

          {/* Primary Arterial Roads & Highways (Warm pastel beige/orange) */}
          <g stroke="#fef08a" strokeWidth="16" strokeLinecap="round" strokeLinejoin="round" opacity="0.9">
            <line x1="0" y1="180" x2="1000" y2="180" />
            <line x1="360" y1="0" x2="360" y2="600" />
            <path d="M 100 50 L 520 280 L 850 180 L 980 320" />
          </g>

          {/* Road center lines */}
          <g stroke="#fde047" strokeWidth="2" strokeDasharray="8 6" opacity="0.8">
            <line x1="0" y1="180" x2="1000" y2="180" />
            <line x1="360" y1="0" x2="360" y2="600" />
          </g>

          {/* Traffic conditions (Soft pastel red/orange overlays if enabled) */}
          {showTraffic && (
            <g stroke="#fca5a5" strokeWidth="4" strokeLinecap="round" opacity="0.7">
              <line x1="360" y1="160" x2="360" y2="280" />
              <line x1="500" y1="260" x2="680" y2="260" />
            </g>
          )}

          {/* Road Name Typography */}
          <text x="60" y="174" fill="#64748b" fontSize="10" fontWeight="600">Grand Trunk Express</text>
          <text x="370" y="80" fill="#64748b" fontSize="10" fontWeight="600" transform="rotate(90 370 80)">Metro Corridor North</text>
          <text x="540" y="254" fill="#64748b" fontSize="10" fontWeight="600">Old Hospital Road</text>
          <text x="740" y="114" fill="#64748b" fontSize="10" fontWeight="600">Tech Ring Highway</text>

          {/* ZOMATO-STYLE ACTIVE DELIVERY ROUTE POLYLINE */}
          {activeSubBatch && (
            <g filter="url(#routeGlow)">
              {/* Outer stroke shadow */}
              <path
                d={`M ${startX * 10} ${startY * 6} Q ${(startX + riderX) * 5} ${startY * 6}, ${riderX * 10} ${riderY * 6} T ${endX * 10} ${endY * 6}`}
                fill="none"
                stroke={activeSubBatch.rerouted ? '#0284c7' : '#e11d48'}
                strokeWidth="6"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.9"
              />

              {/* Pulsing route dashed indicator */}
              <path
                d={`M ${startX * 10} ${startY * 6} Q ${(startX + riderX) * 5} ${startY * 6}, ${riderX * 10} ${riderY * 6} T ${endX * 10} ${endY * 6}`}
                fill="none"
                stroke="#ffffff"
                strokeWidth="2"
                strokeDasharray="6 8"
                strokeLinecap="round"
              />
            </g>
          )}
        </svg>

        {/* Floating Map Controls (Top Right) */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
          <div className="bg-white/95 backdrop-blur-md rounded-xl border border-slate-200/80 shadow-md p-1 flex flex-col gap-1">
            <button 
              onClick={() => setZoomLevel(prev => Math.min(prev + 0.2, 1.6))}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setZoomLevel(prev => Math.max(prev - 0.2, 0.8))}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button 
              onClick={() => {}}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors"
              title="Center on Courier"
            >
              <Crosshair className="w-4 h-4 text-rose-500" />
            </button>
          </div>

          <button
            onClick={() => setShowTraffic(prev => !prev)}
            className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-medium backdrop-blur-md transition-all shadow-xs ${
              showTraffic
                ? 'bg-white/95 text-slate-700 border-slate-200'
                : 'bg-slate-100/90 text-slate-400 border-slate-300'
            }`}
          >
            Traffic {showTraffic ? '🟢 Live' : '⚪ Off'}
          </button>
        </div>

        {/* Node Markers: Donors (Restaurant / Banquet / Kitchen Pickup Pin) */}
        {donors.map(d => {
          const isCurrentPickup = donor?.id === d.id;
          return (
            <div
              key={d.id}
              style={{ left: `${d.x}%`, top: `${d.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group cursor-pointer"
            >
              <div className="flex flex-col items-center">
                {/* Zomato-style Store Badge */}
                <div className={`p-2 rounded-xl shadow-lg border transition-transform group-hover:scale-110 flex items-center justify-center ${
                  isCurrentPickup 
                    ? 'bg-rose-500 text-white border-white ring-4 ring-rose-200 shadow-rose-300' 
                    : 'bg-white text-slate-700 border-slate-200'
                }`}>
                  <Building2 className="w-4 h-4" />
                </div>
                
                {/* Tooltip callout */}
                <div className="mt-1 px-2 py-0.5 rounded-md bg-white/95 border border-slate-200 text-[10px] font-semibold text-slate-800 whitespace-nowrap shadow-xs">
                  {d.name.split(' ')[0]} (Pick-up)
                </div>
              </div>
            </div>
          );
        })}

        {/* Node Markers: Shelters (Drop-off Pin with Destination Target) */}
        {shelters.map(s => {
          const isTarget = targetShelter?.id === s.id;
          const isFilled = s.demandRemaining.cooked_meals === 0;

          return (
            <div
              key={s.id}
              style={{ left: `${s.x}%`, top: `${s.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group cursor-pointer"
            >
              <div className="flex flex-col items-center">
                <div className={`p-2 rounded-xl shadow-lg border transition-transform group-hover:scale-110 flex items-center justify-center ${
                  isTarget 
                    ? 'bg-emerald-600 text-white border-white ring-4 ring-emerald-200 shadow-emerald-200' 
                    : isFilled 
                      ? 'bg-slate-200 text-slate-500 border-slate-300' 
                      : 'bg-white text-emerald-600 border-emerald-200'
                }`}>
                  <Home className="w-4 h-4" />
                </div>
                
                <div className="mt-1 px-2 py-0.5 rounded-md bg-white/95 border border-slate-200 text-[10px] font-semibold text-slate-800 whitespace-nowrap shadow-xs flex flex-col items-center">
                  <span>{s.name.split(' ')[0]} {s.name.split(' ')[1] || ''}</span>
                  <span className="text-[9px] font-mono text-slate-500 tabular-nums font-normal">
                    {isFilled ? 'Capacity Met (0 need)' : `Need: ${s.demandRemaining.cooked_meals}`}
                  </span>
                </div>
              </div>
            </div>
          );
        })}

        {/* Dynamic Rider Markers (Zomato Scooter Delivery Partner with Pulse Radar Wave) */}
        {riders.map(r => {
          const isSelected = selectedRiderId === r.id;
          const isUnresponsive = r.status === 'unresponsive';

          return (
            <div
              key={r.id}
              onClick={() => setSelectedRiderId(r.id)}
              style={{ left: `${r.x}%`, top: `${r.y}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 z-30 cursor-pointer transition-all duration-700 ease-out ${
                isSelected ? 'scale-110' : 'hover:scale-105'
              }`}
            >
              <div className="flex flex-col items-center relative">
                
                {/* Zomato Radar Pulse Ring */}
                {isSelected && (
                  <span className="absolute -inset-2 rounded-full bg-rose-400/40 animate-ping pointer-events-none" />
                )}

                {/* Scooter Badge */}
                <div className={`w-9 h-9 rounded-full flex items-center justify-center border shadow-md relative ${
                  isSelected 
                    ? 'bg-rose-500 text-white border-white shadow-rose-300 ring-2 ring-rose-400' 
                    : isUnresponsive
                      ? 'bg-amber-500 text-white border-white animate-bounce'
                      : 'bg-white text-rose-500 border-rose-200'
                }`}>
                  <Bike className="w-4 h-4" />
                </div>

                {/* Label pill */}
                <div className="mt-1 px-2 py-0.5 rounded-full bg-slate-900 text-white text-[9px] font-mono font-medium whitespace-nowrap shadow-xs flex items-center gap-1">
                  <span>{r.name.split(' ')[0]}</span>
                  {r.currentCargoCount > 0 && (
                    <span className="text-rose-300 font-bold">· {r.currentCargoCount}m</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* FLOATING ZOMATO-STYLE BOTTOM DELIVERY SUMMARY CARD */}
        {activeSubBatch && currentRider && (
          <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:max-w-md z-30 bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200/90 shadow-xl p-4 transition-all">
            
            {/* Delivery Partner Profile Row */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-500 font-bold text-sm shrink-0 shadow-xs">
                  🛵
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                      {currentRider.name}
                    </h3>
                    <span className="text-[11px] font-mono font-bold text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                      ★ {currentRider.reliabilityScore}%
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {activeSubBatch.parentBatch.title} ({activeSubBatch.quantity} meals)
                  </p>
                </div>
              </div>

              {/* ETA badge */}
              <div className="text-right">
                <span className="text-base font-bold font-mono text-rose-600 tabular-nums">
                  {activeSubBatch.deliveryEtaMinutes} mins
                </span>
                <span className="text-[10px] text-slate-400 block">EST. ARRIVAL</span>
              </div>
            </div>

            {/* Dynamic Reroute Alert if Shelter Changed Mid-Transit */}
            {activeSubBatch.rerouted && (
              <div className="mt-3 p-2.5 rounded-xl bg-sky-50 border border-sky-200 text-xs text-sky-900 flex items-start gap-2">
                <Navigation className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Dynamic Re-routing Active:</span> Shelter Alpha filled by walk-in donation. Heading to <strong>Shelter Echo</strong> (Safe window preserved).
                </div>
              </div>
            )}

            {/* Ghost Inactivity Alert */}
            {currentRider.status === 'unresponsive' && (
              <div className="mt-3 p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Heartbeat Stalled ({currentRider.lastHeartbeatSecondsAgo}s):</span> Auto-failover watchdog transferring cargo to Standby Maya.
                </div>
              </div>
            )}

            {/* Thermal / Perishable Integrity Bar */}
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-500" />
                <span>Safe Shelf-Life:</span>
                <strong className="font-mono text-slate-900 font-semibold tabular-nums">
                  {Math.round(activeSubBatch.parentBatch.remainingSafeMinutes)}m left
                </strong>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => sendRiderHeartbeat(currentRider.id)}
                  className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                >
                  Ping Heartbeat
                </button>
                <button
                  onClick={() => completeDelivery(activeSubBatch.id)}
                  className="px-2.5 py-1 text-[11px] font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-xs"
                >
                  Handover
                </button>
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Quick Interactive Ground Triggers for this Map */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <button
          onClick={() => triggerMidTransitShelterClosure('shelter_alpha', 50)}
          className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700 transition-all flex items-center gap-2 shadow-xs text-left"
        >
          <div className="w-6 h-6 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
            <Home className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="font-bold text-slate-900">Simulate Shelter Alpha Closure</div>
            <div className="text-[11px] text-slate-500">Citizen walk-in triggers dynamic reroute</div>
          </div>
        </button>

        <button
          onClick={() => triggerGhostRiderStall(currentRider.id)}
          className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700 transition-all flex items-center gap-2 shadow-xs text-left"
        >
          <div className="w-6 h-6 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="font-bold text-slate-900">Simulate Ghost Courier Stall</div>
            <div className="text-[11px] text-slate-500">Watch SLA watchdog auto-reassign to Maya</div>
          </div>
        </button>

        <button
          onClick={() => sendRiderHeartbeat(currentRider.id)}
          className="p-3 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700 transition-all flex items-center gap-2 shadow-xs text-left"
        >
          <div className="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Radio className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="font-bold text-slate-900">Send Rider GPS Heartbeat</div>
            <div className="text-[11px] text-slate-500">Refreshes breadcrumbs & resets stall SLA</div>
          </div>
        </button>
      </div>

    </div>
  );
};
