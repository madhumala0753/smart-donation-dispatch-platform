import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Navigation, 
  Split, 
  RotateCcw, 
  CheckCircle2, 
  ShieldAlert,
  Clock
} from 'lucide-react';
import { AuditEvent } from '../types';

export const AuditFeed: React.FC = () => {
  const { auditLogs } = useSimulation();

  const getLogBadge = (type: AuditEvent['type']) => {
    switch (type) {
      case 'BATCH_SPLIT':
        return <span className="p-1 rounded-md bg-amber-100 text-amber-700"><Split className="w-3.5 h-3.5" /></span>;
      case 'GHOST_CLAIM_DETECTED':
        return <span className="p-1 rounded-md bg-amber-100 text-amber-700"><AlertTriangle className="w-3.5 h-3.5" /></span>;
      case 'AUTO_REASSIGNED':
        return <span className="p-1 rounded-md bg-emerald-100 text-emerald-700"><CheckCircle2 className="w-3.5 h-3.5" /></span>;
      case 'DYNAMIC_REROUTE':
        return <span className="p-1 rounded-md bg-sky-100 text-sky-700"><Navigation className="w-3.5 h-3.5" /></span>;
      case 'DEPENDENCY_BLOCKED':
        return <span className="p-1 rounded-md bg-rose-100 text-rose-700"><ShieldAlert className="w-3.5 h-3.5" /></span>;
      case 'DEPENDENCY_RESOLVED':
        return <span className="p-1 rounded-md bg-emerald-100 text-emerald-700"><CheckCircle2 className="w-3.5 h-3.5" /></span>;
      case 'DELIVERY_SUCCESS':
        return <span className="p-1 rounded-md bg-emerald-100 text-emerald-700"><ShieldCheck className="w-3.5 h-3.5" /></span>;
      default:
        return <span className="p-1 rounded-md bg-slate-100 text-slate-600"><Clock className="w-3.5 h-3.5" /></span>;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">
            Algorithmic Safety & Real-Time Audit Log
          </h3>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Automated failovers, SLA interventions, and dynamic reroute decisions across all 3 parts.
          </p>
        </div>
        <span className="text-[11px] font-mono font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 tabular-nums">
          {auditLogs.length} Events Logged
        </span>
      </div>

      <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
        {auditLogs.map(log => (
          <div
            key={log.id}
            className="p-3 rounded-xl bg-slate-50/70 border border-slate-200/60 text-xs space-y-1 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold text-slate-900">
                {getLogBadge(log.type)}
                <span>{log.title}</span>
              </div>
              <span className="font-mono text-[10px] text-slate-400 tabular-nums">
                {log.timestamp}
              </span>
            </div>

            <p className="text-[11px] text-slate-600 leading-relaxed pl-7">
              {log.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
