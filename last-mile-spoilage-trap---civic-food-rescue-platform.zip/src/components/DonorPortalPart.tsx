import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Building2, 
  Clock, 
  Plus, 
  Split, 
  Bike, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { AidItemType, PrerequisiteStatus } from '../types';

interface DonorPortalPartProps {
  onOpenNewBatchModal: () => void;
}

export const DonorPortalPart: React.FC<DonorPortalPartProps> = ({ onOpenNewBatchModal }) => {
  const { donors, batches, triggerBulkSurgePartition } = useSimulation();

  return (
    <div className="space-y-6">
      
      {/* Editorial Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl border border-amber-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold bg-amber-100/80 px-2.5 py-0.5 rounded-full border border-amber-300">
              Part 1 of 3 · Aid Providers
            </span>
            <span className="text-xs text-amber-800">Surplus Kitchens & Pharmacies</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 mt-1">
            Donor Intake & Perishable Surplus Log
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Banquet halls, messes, and hospitals log untouched cooked food and fragile medicines before shelf-life decay.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerBulkSurgePartition(180, 65)}
            className="px-3.5 py-2 text-xs font-semibold text-amber-900 bg-amber-200/80 hover:bg-amber-300 border border-amber-300 rounded-xl transition-all shadow-xs"
            title="Simulate 180 cooked biryani meals bulk surplus from Grand Palace"
          >
            Quick 180-Meal Bulk Surge
          </button>
          <button
            onClick={onOpenNewBatchModal}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-rose-500 hover:bg-rose-600 rounded-xl transition-all shadow-xs shadow-rose-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>Log Custom Surplus</span>
          </button>
        </div>
      </div>

      {/* Donors Profiles Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {donors.map(d => {
          const donorBatches = batches.filter(b => b.donorId === d.id);
          const totalUnits = donorBatches.reduce((acc, b) => acc + b.totalQuantity, 0);

          return (
            <div 
              key={d.id} 
              className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-3 hover:border-amber-300 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                  <Building2 className="w-4 h-4" />
                </div>
                <span className="text-[11px] font-mono font-medium text-slate-500 capitalize bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200">
                  {d.type.replace('_', ' ')}
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-slate-900 line-clamp-1">{d.name}</h3>
                <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{d.address}</p>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                <span>Active Batches: <strong className="font-mono text-slate-900">{donorBatches.length}</strong></span>
                <span className="font-mono text-amber-700 font-semibold">{totalUnits} units</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Batches Logged & Auto-Partitioning Status */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
          Active Perishable Surplus & Dispatch Breakdown
        </h3>

        <div className="space-y-4">
          {batches.map(batch => (
            <div 
              key={batch.id} 
              className="p-5 bg-white rounded-2xl border border-slate-200/90 shadow-sm space-y-4"
            >
              {/* Top row */}
              <div className="flex flex-wrap items-start justify-between gap-4 pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-base font-bold text-slate-900 tracking-tight">
                      {batch.title}
                    </h4>
                    <span className="text-[11px] font-mono font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                      {batch.totalQuantity} {batch.unit}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <span>{batch.donorName}</span>
                    <span aria-hidden="true">·</span>
                    <span>Prepared {batch.preparedTimeAgoMinutes}m ago</span>
                    <span aria-hidden="true">·</span>
                    <span>Max safe window: {batch.maxSafeMinutes}m</span>
                  </div>
                </div>

                {/* Shelf-Life Countdown */}
                <div className="text-right">
                  <div className="text-sm font-bold font-mono text-amber-600 tabular-nums flex items-center gap-1.5 justify-end">
                    <Clock className="w-4 h-4 text-amber-500" />
                    <span>{Math.round(batch.remainingSafeMinutes)}m safe remaining</span>
                  </div>
                  <span className="text-[10px] text-slate-400">Ticking Spoilage Clock</span>
                </div>
              </div>

              {/* Automated Decomposition into Micro-Courier Runs */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <span className="font-semibold flex items-center gap-1.5">
                    <Split className="w-3.5 h-3.5 text-amber-600" />
                    Auto-Partitioned Delivery Legs ({batch.subBatches.length} Couriers Assigned)
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Vehicle constraints: $\le 45$ meals/scooter
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {batch.subBatches.map((sb, idx) => (
                    <div 
                      key={sb.id} 
                      className={`p-3 rounded-xl border text-xs space-y-1.5 ${
                        sb.rerouted 
                          ? 'bg-sky-50 border-sky-200 text-sky-950' 
                          : sb.status === 'delivered' 
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
                            : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex justify-between font-mono font-bold text-[11px]">
                        <span>Parcel #{idx + 1}</span>
                        <span className="text-rose-600">{sb.quantity} {batch.unit}</span>
                      </div>
                      <div className="text-slate-600 truncate flex items-center gap-1">
                        <Bike className="w-3.5 h-3.5 text-slate-400" />
                        <span>{sb.riderId ? `Courier ${sb.riderId.replace('rider_', '').toUpperCase()}` : 'Assigning...'}</span>
                      </div>
                      <div className="text-[11px] font-mono pt-1 border-t border-slate-200/60 flex justify-between">
                        <span className={sb.rerouted ? 'text-sky-700 font-semibold' : 'text-slate-500'}>
                          {sb.rerouted ? 'REROUTED' : sb.status.toUpperCase()}
                        </span>
                        <span className="text-slate-700">ETA {sb.deliveryEtaMinutes}m</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
