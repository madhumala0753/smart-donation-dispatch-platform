import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Home, 
  Droplets, 
  Flame, 
  Snowflake, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  MapPin, 
  Users, 
  Package,
  Plus
} from 'lucide-react';
import { PrerequisiteStatus } from '../types';

export const SheltersView: React.FC = () => {
  const { 
    shelters, 
    resolvePrerequisite, 
    triggerMidTransitShelterClosure,
    triggerDependencyDispatchTest 
  } = useSimulation();

  return (
    <div className="space-y-6">
      
      {/* Editorial Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-white">
          Receiving Shelters & Prerequisite Safety Enforcement
        </h2>
        <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
          <span>Active Variable #4: Dynamic Fallback Destinations</span>
          <span aria-hidden="true">·</span>
          <span>Active Variable #5: Prerequisite Dependency Rules</span>
          <span aria-hidden="true">·</span>
          <span>Biochemical & Hygiene Guardrails</span>
        </div>
      </div>

      {/* Dependency Rules Callout Banner */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-xl">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
          Strict Aid Dependency Policies Enforced by ReliefMesh
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed mb-4">
          Per the civic logistics problem statement: dispatching raw rations or powdered infant formula to sites lacking clean potable water or cooking fuel causes severe gastrointestinal toxicity in flood zones. Cold-chain biotherapeutics (insulin, rabies vaccines) strictly require verified cold storage.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-start gap-2.5">
            <Droplets className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Clean Water Invariant</span>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Infant formula & raw ration distribution is locked until local potable water certification is registered.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-start gap-2.5">
            <Flame className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Cooking Fuel Invariant</span>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Bulk grains/lentils requiring heat preparation are routed only to facilities with active LPG or firewood.
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-start gap-2.5">
            <Snowflake className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">Cold Storage Invariant</span>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Insulin and temperature-sensitive biologics require temperature-logged refrigeration (2°C–8°C).
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Shelters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {shelters.map(shelter => {
          const unmetMeals = shelter.demandRemaining.cooked_meals;
          const isMealsFilled = unmetMeals === 0;

          return (
            <div
              key={shelter.id}
              className={`rounded-xl border p-5 shadow-lg space-y-4 ${
                isMealsFilled 
                  ? 'bg-slate-900/60 border-slate-800' 
                  : 'bg-slate-900 border-slate-800'
              }`}
            >
              
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-white tracking-tight line-clamp-1">
                    {shelter.name}
                  </h4>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
                    <MapPin className="w-3 h-3 text-slate-500" />
                    <span className="truncate max-w-[200px]">{shelter.address}</span>
                  </div>
                </div>

                <div className="text-right font-mono text-xs">
                  <span className="text-white font-semibold tabular-nums">{shelter.currentOccupants}</span>
                  <span className="text-slate-400">/{shelter.capacityMax}</span>
                  <div className="text-[10px] text-slate-400">occupancy</div>
                </div>
              </div>

              {/* Demand Status Strip */}
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Cooked Meals Unmet:</span>
                  <span className={`font-mono font-bold tabular-nums ${
                    isMealsFilled ? 'text-slate-400' : 'text-emerald-400'
                  }`}>
                    {unmetMeals} meals {isMealsFilled && '(Filled by Walk-in)'}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Infant Formula Need:</span>
                  <span className="font-mono tabular-nums text-slate-300">
                    {shelter.demandRemaining.infant_formula} kits
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Cold Medicine Need:</span>
                  <span className="font-mono tabular-nums text-slate-300">
                    {shelter.demandRemaining.cold_chain_medicine} vials
                  </span>
                </div>
              </div>

              {/* Prerequisites Verification Checkers */}
              <div className="space-y-2">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Ground Prerequisite Status
                </span>

                {/* Clean Water */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950/80 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-3.5 h-3.5 text-sky-400" />
                    <span>Clean Potable Water</span>
                  </div>
                  {shelter.prerequisites.cleanWater ? (
                    <span className="text-emerald-400 font-mono text-[11px] font-semibold">VERIFIED</span>
                  ) : (
                    <button
                      onClick={() => resolvePrerequisite(shelter.id, 'cleanWater')}
                      className="px-2 py-0.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded text-[10px] transition-colors"
                      title="Click to resolve and clear this prerequisite"
                    >
                      MISSING · Certify Now
                    </button>
                  )}
                </div>

                {/* Cooking Fuel */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950/80 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>Cooking Fuel / Gas</span>
                  </div>
                  {shelter.prerequisites.cookingFuel ? (
                    <span className="text-emerald-400 font-mono text-[11px] font-semibold">VERIFIED</span>
                  ) : (
                    <button
                      onClick={() => resolvePrerequisite(shelter.id, 'cookingFuel')}
                      className="px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded text-[10px] transition-colors"
                      title="Click to resolve and clear this prerequisite"
                    >
                      MISSING · Certify Now
                    </button>
                  )}
                </div>

                {/* Cold Storage */}
                <div className="flex items-center justify-between p-2 rounded bg-slate-950/80 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <Snowflake className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Cold Chain Storage</span>
                  </div>
                  {shelter.prerequisites.coldStorage ? (
                    <span className="text-emerald-400 font-mono text-[11px] font-semibold">ACTIVE</span>
                  ) : (
                    <span className="text-slate-400 font-mono text-[10px]">NOT EQUIPPED</span>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <button
                  onClick={() => triggerMidTransitShelterClosure(shelter.id, 50)}
                  className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  title="Simulates citizen walk-in dropoff filling shelter demand instantly to test dynamic reroute"
                >
                  <span>Simulate Walk-in Dropoff (Fill Demand)</span>
                </button>

                {!shelter.prerequisites.cleanWater && (
                  <button
                    onClick={() => triggerDependencyDispatchTest(shelter.id)}
                    className="w-full py-1 px-3 bg-rose-950/30 hover:bg-rose-900/50 border border-rose-800/60 text-rose-300 text-[11px] font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Test Dependency Violation Trap</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
