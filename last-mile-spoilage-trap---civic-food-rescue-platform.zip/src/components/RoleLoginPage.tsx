import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Building2, 
  Bike, 
  Home, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2, 
  UserCheck, 
  Phone,
  Zap,
  Lock,
  Mail,
  UserPlus,
  LogIn
} from 'lucide-react';
import { UserRole, UserProfile } from '../types';

interface RoleLoginPageProps {
  onOpenProblemStatement: () => void;
  onOpenJudgeSuite: () => void;
  onBackToPortals?: () => void;
}

export const RoleLoginPage: React.FC<RoleLoginPageProps> = ({
  onOpenProblemStatement,
  onOpenJudgeSuite,
  onBackToPortals
}) => {
  const { donors, riders, shelters, login, switchRole } = useSimulation();

  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [selectedRole, setSelectedRole] = useState<UserRole>('donor');

  // Pre-configured login selections
  const [selectedDonorId, setSelectedDonorId] = useState<string>(donors[0]?.id || '');
  const [selectedRiderId, setSelectedRiderId] = useState<string>(riders[3]?.id || riders[0]?.id || '');
  const [selectedShelterId, setSelectedShelterId] = useState<string>(shelters[0]?.id || '');

  // Signup form fields
  const [signupOrgName, setSignupOrgName] = useState('');
  const [signupContactName, setSignupContactName] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupLocation, setSignupLocation] = useState('');
  const [signupExtra, setSignupExtra] = useState(''); // e.g. FSSAI or Vehicle

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    switchRole(
      selectedRole, 
      selectedRole === 'donor' 
        ? selectedDonorId 
        : selectedRole === 'rider' 
          ? selectedRiderId 
          : selectedShelterId
    );
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signupOrgName || !signupContactName) return;

    const newProfile: UserProfile = {
      role: selectedRole,
      id: `user_${Date.now()}`,
      name: signupContactName,
      facilityOrVehicle: signupOrgName,
      phone: signupPhone || '+91 98000 12345',
      locationName: signupLocation || 'Central Zone',
      isVerified: true
    };

    login(newProfile);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col justify-between p-6 sm:p-10 font-sans">
      
      {/* Top Bar */}
      <div className="max-w-6xl w-full mx-auto flex items-center justify-between pb-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-900 tracking-tight">
              Last-Mile Spoilage Trap
            </h1>
            <span className="text-[11px] text-slate-500">
              Civic Food Rescue & Micro-Logistics Platform
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {onBackToPortals && (
            <button
              onClick={onBackToPortals}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-3.5 py-1.5 rounded-xl border border-emerald-200 transition-colors"
            >
              ← Back to 3 Portals
            </button>
          )}
          <button
            onClick={onOpenProblemStatement}
            className="text-xs text-slate-600 hover:text-slate-900 font-medium transition-colors"
          >
            Problem Brief
          </button>
          <button
            onClick={onOpenJudgeSuite}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-all shadow-xs"
          >
            <Zap className="w-3.5 h-3.5 fill-white" />
            <span>Judge Sandbox</span>
          </button>
        </div>
      </div>

      {/* Main Login / Signup Card */}
      <div className="max-w-4xl w-full mx-auto my-auto py-8 space-y-6">
        
        {/* Editorial Heading */}
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-bold bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-300">
            Secure Role Portal Access
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
            {authMode === 'login' ? 'Sign In to Your Operational Dashboard' : 'Register a New Platform Account'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Connecting Food Donors, Delivery Couriers, and Receiving Facilities to eliminate last-mile food waste.
          </p>
        </div>

        {/* 3 Role Selection Pills */}
        <div className="grid grid-cols-3 gap-3 max-w-lg mx-auto">
          
          <button
            type="button"
            onClick={() => setSelectedRole('donor')}
            className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
              selectedRole === 'donor'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20 font-bold'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Building2 className="w-5 h-5" />
            <span className="text-xs">1. Food Donor</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedRole('rider')}
            className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
              selectedRole === 'rider'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20 font-bold'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Bike className="w-5 h-5" />
            <span className="text-xs">2. Delivery Rider</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedRole('shelter')}
            className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
              selectedRole === 'shelter'
                ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20 font-bold'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-xs">3. Food Receiver</span>
          </button>

        </div>

        {/* Form Container */}
        <div className="max-w-xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-5">
          
          {/* Tab Switcher: Login vs Sign Up */}
          <div className="flex items-center p-1 bg-slate-100 rounded-2xl border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setAuthMode('login')}
              className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                authMode === 'login' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In (Existing Profile)</span>
            </button>

            <button
              onClick={() => setAuthMode('signup')}
              className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                authMode === 'signup' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Create New Account</span>
            </button>
          </div>

          {/* Form Mode: Login */}
          {authMode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
              
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Select {selectedRole === 'donor' ? 'Registered Donor Facility' : selectedRole === 'rider' ? 'Volunteer Courier Profile' : 'Receiving Facility'}:
                </label>
                
                {selectedRole === 'donor' && (
                  <select
                    value={selectedDonorId}
                    onChange={e => setSelectedDonorId(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none focus:border-emerald-500 focus:bg-white"
                  >
                    {donors.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.contactPerson}) · FSSAI #{d.fssaiNumber || 'Verified'}
                      </option>
                    ))}
                  </select>
                )}

                {selectedRole === 'rider' && (
                  <select
                    value={selectedRiderId}
                    onChange={e => setSelectedRiderId(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none focus:border-emerald-500 focus:bg-white"
                  >
                    {riders.map(r => (
                      <option key={r.id} value={r.id}>
                        {r.name} · {r.vehicleType.toUpperCase()} (Cap: {r.maxCapacity}) · ★ {r.rating}
                      </option>
                    ))}
                  </select>
                )}

                {selectedRole === 'shelter' && (
                  <select
                    value={selectedShelterId}
                    onChange={e => setSelectedShelterId(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none focus:border-emerald-500 focus:bg-white"
                  >
                    {shelters.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.contactPerson}) · Capacity: {s.capacityMax} beds
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Passcode / OTP</label>
                <input
                  type="password"
                  defaultValue="••••••••"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                <span>Sign In as {selectedRole.toUpperCase()}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </form>
          ) : (
            /* Form Mode: Sign Up */
            <form onSubmit={handleSignupSubmit} className="space-y-4 text-xs">
              
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {selectedRole === 'donor' ? 'Organization / Restaurant Name' : selectedRole === 'rider' ? 'Full Legal Name' : 'NGO / Shelter Name'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={selectedRole === 'donor' ? 'e.g. Skyline Banquet & Catering' : selectedRole === 'rider' ? 'e.g. Sameer Kulkarni' : 'e.g. Hope Haven Relief Home'}
                  value={signupOrgName}
                  onChange={e => setSignupOrgName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Contact Officer Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rajesh Kumar"
                    value={signupContactName}
                    onChange={e => setSignupContactName(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Direct Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 98XXX XXXXX"
                    value={signupPhone}
                    onChange={e => setSignupPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Operating Address / GPS Sector</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sector 5, Outer Ring Corridor"
                  value={signupLocation}
                  onChange={e => setSignupLocation(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                <span>Create Account & Enter Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>

            </form>
          )}

        </div>

        {/* Bypass to Overview */}
        <div className="text-center pt-2">
          <button
            onClick={() => switchRole('admin')}
            className="text-xs text-slate-500 hover:text-emerald-700 font-semibold underline underline-offset-4"
          >
            Or Browse Platform as Central Operations Supervisor
          </button>
        </div>

      </div>

      {/* Footer */}
      <div className="max-w-6xl w-full mx-auto text-center text-xs text-slate-400 pt-6 border-t border-slate-200">
        Last-Mile Spoilage Trap · Certified Zero-Waste Civic Micro-Logistics Engine
      </div>

    </div>
  );
};
