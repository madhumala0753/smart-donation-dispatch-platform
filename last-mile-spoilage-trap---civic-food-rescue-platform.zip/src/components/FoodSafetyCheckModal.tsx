import React from 'react';
import { X, ShieldCheck, Thermometer, CheckCircle2, AlertTriangle, FileCheck } from 'lucide-react';
import { FoodSafetyCheck } from '../types';

interface FoodSafetyCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
  safetyCheck: FoodSafetyCheck;
  title: string;
}

export const FoodSafetyCheckModal: React.FC<FoodSafetyCheckModalProps> = ({
  isOpen,
  onClose,
  safetyCheck,
  title
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full shadow-2xl p-6 space-y-5">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">
                Food Safety & Compliance Certificate
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Thermal integrity & hygiene chain-of-custody audit
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 text-xs">
          
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Inspected Item</span>
            <div className="font-bold text-slate-900 text-sm mt-0.5">{title}</div>
          </div>

          {/* Temperature Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 space-y-1">
              <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider block">
                Cooking / Prep Temp
              </span>
              <div className="text-xl font-bold font-mono text-emerald-800 tabular-nums">
                {safetyCheck.preparedTempC}°C
              </div>
              <span className="text-[11px] text-emerald-700">✓ Past 65°C kill step</span>
            </div>

            <div className="p-3.5 bg-sky-50 rounded-2xl border border-sky-200 space-y-1">
              <span className="text-[10px] text-sky-700 font-bold uppercase tracking-wider block">
                Transit Cargo Temp
              </span>
              <div className="text-xl font-bold font-mono text-sky-800 tabular-nums">
                {safetyCheck.currentTempC}°C
              </div>
              <span className="text-[11px] text-sky-700">Insulated thermal box</span>
            </div>
          </div>

          {/* Verification checklist */}
          <div className="space-y-2">
            <span className="text-slate-600 font-semibold block">Quality & Hygiene Verification:</span>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
              <span>Food Grade Packaging Sealed & Untouched</span>
              <span className="font-mono text-emerald-700 font-bold">VERIFIED ✓</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
              <span>Certified Hygiene QA Sign-off</span>
              <span className="font-medium text-slate-800">{safetyCheck.hygieneInspector}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-slate-500">Declared Allergens:</span>
              <div className="flex flex-wrap gap-1.5 mt-1">
                {safetyCheck.allergenFlags.length > 0 ? (
                  safetyCheck.allergenFlags.map((tag, i) => (
                    <span key={i} className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-medium border border-amber-200">
                      {tag}
                    </span>
                  ))
                ) : (
                  <span className="text-slate-500 text-[11px] italic">No common allergens declared</span>
                )}
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs"
          >
            Acknowledge Safety Compliance
          </button>
        </div>

      </div>
    </div>
  );
};
