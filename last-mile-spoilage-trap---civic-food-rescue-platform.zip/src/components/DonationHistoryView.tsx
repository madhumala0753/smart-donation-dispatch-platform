import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  History, 
  Download, 
  ShieldCheck, 
  Search, 
  Filter, 
  Sparkles, 
  CheckCircle2, 
  Leaf, 
  Building2, 
  Home, 
  Bike,
  FileSpreadsheet
} from 'lucide-react';
import { DonationHistoryRecord } from '../types';

export const DonationHistoryView: React.FC = () => {
  const { donationHistory } = useSimulation();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'meals' | 'vials'>('all');

  const filteredHistory = donationHistory.filter(item => {
    const matchesSearch = 
      item.batchTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.donorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.receiverName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.riderName.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filterType === 'meals') return matchesSearch && item.unit === 'meals';
    if (filterType === 'vials') return matchesSearch && item.unit === 'vials';
    return matchesSearch;
  });

  const totalMeals = donationHistory.reduce((acc, h) => acc + (h.unit === 'meals' ? h.quantity : 0), 0) + 10240;
  const totalCo2Kg = donationHistory.reduce((acc, h) => acc + h.co2SavedKg, 0) + 25600;

  // Real CSV export function
  const handleExportCSV = () => {
    const headers = ['Record ID,Batch Title,Donor,Receiver,Rider,Quantity,Unit,Completed At,CO2 Saved (kg),Safety Score'];
    const rows = filteredHistory.map(h => 
      `"${h.id}","${h.batchTitle}","${h.donorName}","${h.receiverName}","${h.riderName}",${h.quantity},"${h.unit}","${h.completedAt}",${h.co2SavedKg},${h.safetyScore}%`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LastMileSpoilageTrap_DonationHistory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 sm:space-y-10">
      
      {/* Banner - Spacious & Airy */}
      <div className="p-6 sm:p-8 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-3xl border border-emerald-200/90 shadow-sm flex flex-wrap items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-bold bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-300">
              Verified Audit Ledger
            </span>
            <span className="text-xs text-emerald-700 font-medium">FSSAI & WHO Aligned Chain of Custody</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
            Donation History & ESG Impact Ledger
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Every rescued meal is tracked from donor preparation to shelter receipt with verified thermal safety.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-md shadow-emerald-600/20 active:scale-95"
        >
          <Download className="w-4 h-4" />
          <span>Export ESG Report (CSV)</span>
        </button>
      </div>

      {/* Aggregate Impact KPI Cards - Airy & Spacious */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
        
        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <span className="text-xs sm:text-sm text-slate-500 font-medium block">Total Meals Rescued</span>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-600 tabular-nums">
              {totalMeals.toLocaleString()} <span className="text-sm font-normal text-slate-500 font-sans">meals</span>
            </div>
          </div>
          <span className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100 block">100% human-safe quality</span>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <span className="text-xs sm:text-sm text-slate-500 font-medium block">GHG Emissions Averted</span>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 tabular-nums">
              {(totalCo2Kg / 1000).toFixed(1)} <span className="text-sm font-normal text-slate-500 font-sans">tons CO₂e</span>
            </div>
          </div>
          <span className="text-xs text-slate-500 font-medium pt-3 border-t border-slate-100 block">Methane landfill offset</span>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <span className="text-xs sm:text-sm text-slate-500 font-medium block">Avg. Handover Speed</span>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 tabular-nums">
              18.4 <span className="text-sm font-normal text-slate-500 font-sans">mins</span>
            </div>
          </div>
          <span className="text-xs text-slate-500 font-medium pt-3 border-t border-slate-100 block">Pickup to shelter delivery</span>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <span className="text-xs sm:text-sm text-slate-500 font-medium block">Audit Compliance</span>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-600 tabular-nums">
              99.2%
            </div>
          </div>
          <span className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100 block">Thermal & hygiene pass</span>
        </div>

      </div>

      {/* Filter and Search Bar - Spacious */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 sm:p-6 bg-white rounded-3xl border border-slate-200/90 shadow-sm">
        <div className="relative flex-1 min-w-[280px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by meal, donor kitchen, receiving shelter, or courier..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:border-emerald-500 focus:bg-white transition-all shadow-2xs"
          />
        </div>

        <div className="flex items-center gap-2 p-1.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs sm:text-sm">
          <button
            onClick={() => setFilterType('all')}
            className={`px-4 py-2 font-semibold rounded-xl transition-colors ${
              filterType === 'all' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            All Items
          </button>
          <button
            onClick={() => setFilterType('meals')}
            className={`px-4 py-2 font-semibold rounded-xl transition-colors ${
              filterType === 'meals' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Cooked Meals
          </button>
          <button
            onClick={() => setFilterType('vials')}
            className={`px-4 py-2 font-semibold rounded-xl transition-colors ${
              filterType === 'vials' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Cold Medicine
          </button>
        </div>
      </div>

      {/* Ledger Table - Spacious */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-xs tracking-wider">
              <tr>
                <th className="px-6 py-4">Rescue Mission</th>
                <th className="px-6 py-4">Donor Kitchen</th>
                <th className="px-6 py-4">Receiving Facility</th>
                <th className="px-6 py-4">Courier</th>
                <th className="px-6 py-4 text-right">Portions</th>
                <th className="px-6 py-4 text-right">CO₂ Mitigated</th>
                <th className="px-6 py-4 text-center">Safety Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.map(row => (
                <tr key={row.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-6 py-4.5 sm:py-5">
                    <div className="font-bold text-slate-900 text-sm sm:text-base">{row.batchTitle}</div>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">{row.completedAt}</div>
                  </td>
                  <td className="px-6 py-4.5 sm:py-5 text-slate-700">
                    <div className="flex items-center gap-2 font-medium">
                      <Building2 className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>{row.donorName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4.5 sm:py-5 text-slate-700">
                    <div className="flex items-center gap-2 font-medium">
                      <Home className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{row.receiverName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4.5 sm:py-5 text-slate-700">
                    <div className="flex items-center gap-2">
                      <Bike className="w-4 h-4 text-sky-600 shrink-0" />
                      <span>{row.riderName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4.5 sm:py-5 text-right font-mono font-bold text-slate-900 tabular-nums">
                    {row.quantity} {row.unit}
                  </td>
                  <td className="px-6 py-4.5 sm:py-5 text-right font-mono text-emerald-700 font-semibold tabular-nums">
                    {row.co2SavedKg} kg
                  </td>
                  <td className="px-6 py-4.5 sm:py-5 text-center">
                    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-mono font-bold text-emerald-800 bg-emerald-100 border border-emerald-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      {row.safetyScore}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
