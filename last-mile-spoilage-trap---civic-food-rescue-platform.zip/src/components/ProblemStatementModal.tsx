import React from 'react';
import { X, FileText, CheckCircle2, ExternalLink } from 'lucide-react';

interface ProblemStatementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProblemStatementModal: React.FC<ProblemStatementModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-6">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-500 shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-wider text-rose-700 font-bold block">
                Official Hackathon Handout
              </span>
              <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                Vibe-A-Thon: Social Impact & Civic Micro-Logistics
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="space-y-6 text-xs text-slate-600 leading-relaxed">
          
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
            <h4 className="text-sm font-bold text-slate-900 tracking-tight">
              "The Last-Mile Spoilage Trap: Coordinating Perishable Surplus & Fragile Aid Under Uncertainty"
            </h4>
            <div className="flex items-center gap-2 text-slate-500 font-mono text-[11px]">
              <span>Domain: Social Impact, Civic Logistics & Zero-Waste Redistribution</span>
              <span aria-hidden="true">·</span>
              <span>Target: All Years</span>
            </div>
          </div>

          {/* Core Challenges Table */}
          <div className="space-y-3">
            <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Problem Statement Specifications & ReliefMesh Architecture
            </h5>

            <div className="space-y-3">
              
              <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs">
                    1. Bulk Supply vs. Single-Point Demand & Transport Capacity
                  </span>
                  <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-300">IMPLEMENTED</span>
                </div>
                <p className="text-slate-500 text-[11px] italic">
                  "A banquet hall may have 180 cooked meals that will spoil in 75 minutes, while a single volunteer rider can only carry 40 meals on a scooter, and nearby Shelter A only has space for 50 people."
                </p>
                <p className="text-emerald-800 text-[11px] pt-1">
                  <strong>ReliefMesh Engine:</strong> Slices bulk into discrete micro-batches constrained by vehicle weight limits (Scooters $\le 45$, Vans $\le 120$) and balances distribution across multiple receiving nodes.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs">
                    2. Ghost Reservations & Human Unreliability
                  </span>
                  <span className="text-[10px] font-mono font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-300">IMPLEMENTED</span>
                </div>
                <p className="text-slate-500 text-[11px] italic">
                  "A volunteer or NGO claims a batch on their phone to reserve it, gets stuck in traffic or goes unresponsive for 30 minutes... food sits unclaimed with only 15 minutes of safe shelf-life left."
                </p>
                <p className="text-amber-800 text-[11px] pt-1">
                  <strong>ReliefMesh Engine:</strong> Real-time heartbeat handshake (25s threshold). Watchdog automatically revokes claims upon SLA breach and transfers custody to pre-positioned Standby Reserve riders before safe window expires.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs">
                    3. Mid-Journey Ground Condition Mutations
                  </span>
                  <span className="text-[10px] font-mono font-bold text-sky-800 bg-sky-100 px-2 py-0.5 rounded-full border border-sky-300">IMPLEMENTED</span>
                </div>
                <p className="text-slate-500 text-[11px] italic">
                  "While a volunteer is halfway to Shelter A carrying 40 meals, a local citizen drops off food directly at Shelter A, filling its requirement completely — leaving the incoming rider stranded with ticking perishable cargo."
                </p>
                <p className="text-sky-800 text-[11px] pt-1">
                  <strong>ReliefMesh Engine:</strong> Dynamic collision detection recalculates ETA to adjacent unmet shelters and instantly pushes an updated turn-by-turn waypoint to the rider's active device.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs">
                    4. Strict Prerequisite & Dependency Rules
                  </span>
                  <span className="text-[10px] font-mono font-bold text-rose-800 bg-rose-100 px-2 py-0.5 rounded-full border border-rose-300">IMPLEMENTED</span>
                </div>
                <p className="text-slate-500 text-[11px] italic">
                  "Dispatching raw ration kits or infant formula to a site that currently lacks clean water or cooking fuel is counterproductive."
                </p>
                <p className="text-rose-800 text-[11px] pt-1">
                  <strong>ReliefMesh Engine:</strong> Prerequisite verification matrix (potable water, cooking fuel, cold-chain refrigeration) acts as an automated safety lockout preventing contaminated distribution.
                </p>
              </div>

            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <div className="text-[11px] text-slate-400 font-mono">
            Source: /public/assets/aistudio/Vibe-A-Thon_Problem_Statement_381fc32f.pdf
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
          >
            Dismiss
          </button>
        </div>

      </div>
    </div>
  );
};
