import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Home, 
  Droplets, 
  Flame, 
  Snowflake, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Users, 
  MapPin, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { PrerequisiteStatus } from '../types';

export const ShelterDepotPart: React.FC = () => {
  const { 
    shelters, 
    resolvePrerequisite, 
    triggerMidTransitShelterClosure, 
    triggerDependencyDispatchTest 
  } = useSimulation();

  return (
    <div className="space-y-6">
      
      {/* Editorial Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl border border-emerald-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-emerald-700 font-bold bg-emerald-100/80 px-2.5 py-0.5 rounded-full border border-emerald-300">
              Part 3 of 3 · Receiving Depots
            </span>
            <span className="text-xs text-emerald-800">Night Shelters & Relief Camps</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 mt-1">
            Shelter Demand & Prerequisite Safety Matrix
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Monitors real-time capacity and enforces clean water/fuel requirements before aid distribution.
          </p>
        </div>

        <button
          onClick={() => triggerMidTransitShelterClosure('shelter_alpha', 50)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl transition-all shadow-xs"
          title="Simulate a local citizen walking into Shelter Alpha with 50 meals to test mid-transit dynamic rerouting"
        >
          Simulate Walk-in Citizen Dropoff (Shelter Alpha)
        </button>
      </div>

      {/* Shelters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {shelters.map(shelter => {
          const unmetMeals = shelter.demandRemaining.cooked_meals;
          const isMealsMet = unmetMeals === 0;

          return (
            <div
              key={shelter.id}
              className={`p-5 rounded-2xl border shadow-sm transition-all space-y-4 ${
                isMealsMet 
                  ? 'bg-slate-50 border-slate-200/90' 
                  : 'bg-white border-slate-200/90 hover:border-emerald-300'
              }`}
            >
              
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center border shadow-xs ${
                    isMealsMet 
                      ? 'bg-slate-100 text-slate-500 border-slate-200' 
                      : 'bg-emerald-50 text-emerald-600 border-emerald-200'
                  }`}>
                    <Home className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 tracking-tight line-clamp-1">
                      {shelter.name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                      <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                      <span className="truncate max-w-[170px]">{shelter.address}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono text-sm font-bold text-slate-800 tabular-nums">
                    {shelter.currentOccupants}/{shelter.capacityMax}
                  </span>
                  <div className="text-[10px] text-slate-400">capacity</div>
                </div>
              </div>

              {/* Demand Status Box */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Cooked Meals Need:</span>
                  <span className={`font-mono font-bold tabular-nums ${
                    isMealsMet ? 'text-slate-400' : 'text-rose-600'
                  }`}>
                    {unmetMeals} meals {isMealsMet && '(Filled)'}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Infant Formula:</span>
                  <span className="font-mono font-medium text-slate-800 tabular-nums">
                    {shelter.demandRemaining.infant_formula} kits
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Cold Biologics (Insulin):</span>
                  <span className="font-mono font-medium text-slate-800 tabular-nums">
                    {shelter.demandRemaining.cold_chain_medicine} vials
                  </span>
                </div>
              </div>

              {/* Prerequisites Matrix */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Ground Hygiene & Dependency Status
                </span>

                {/* Clean Water */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/80 text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Droplets className="w-3.5 h-3.5 text-sky-500" />
                    <span>Clean Potable Water</span>
                  </div>
                  {shelter.prerequisites.cleanWater ? (
                    <span className="text-emerald-700 font-mono text-[11px] font-bold">VERIFIED ✓</span>
                  ) : (
                    <button
                      onClick={() => resolvePrerequisite(shelter.id, 'cleanWater')}
                      className="px-2 py-0.5 bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-200 rounded text-[10px] font-medium transition-colors"
                      title="Contaminated ground water. Click to certify water filtration units."
                    >
                      MISSING · Certify
                    </button>
                  )}
                </div>

                {/* Cooking Fuel */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/80 text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Flame className="w-3.5 h-3.5 text-amber-500" />
                    <span>Cooking Fuel / Gas</span>
                  </div>
                  {shelter.prerequisites.cookingFuel ? (
                    <span className="text-emerald-700 font-mono text-[11px] font-bold">VERIFIED ✓</span>
                  ) : (
                    <button
                      onClick={() => resolvePrerequisite(shelter.id, 'cookingFuel')}
                      className="px-2 py-0.5 bg-amber-100 hover:bg-amber-200 text-amber-800 border border-amber-200 rounded text-[10px] font-medium transition-colors"
                    >
                      MISSING · Certify
                    </button>
                  )}
                </div>

                {/* Cold Storage */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-200/80 text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Snowflake className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Cold Chain Storage</span>
                  </div>
                  {shelter.prerequisites.coldStorage ? (
                    <span className="text-emerald-700 font-mono text-[11px] font-bold">ACTIVE ✓</span>
                  ) : (
                    <span className="text-slate-400 font-mono text-[10px]">None</span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <button
                  onClick={() => triggerMidTransitShelterClosure(shelter.id, 50)}
                  className="w-full py-1.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5"
                  title="Simulate walk-in citizen donation satisfying meals demand"
                >
                  <span>Simulate Walk-in Dropoff (Fill Need)</span>
                </button>

                {!shelter.prerequisites.cleanWater && (
                  <button
                    onClick={() => triggerDependencyDispatchTest(shelter.id)}
                    className="w-full py-1 px-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-800 text-[11px] font-semibold rounded-xl transition-colors"
                  >
                    Test Dependency Safety Lockout
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
