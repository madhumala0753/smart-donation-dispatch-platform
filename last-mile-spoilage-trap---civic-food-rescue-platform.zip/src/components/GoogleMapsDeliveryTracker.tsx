import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Bike, 
  MapPin, 
  Navigation, 
  Clock, 
  Phone, 
  ShieldCheck, 
  AlertTriangle, 
  ZoomIn, 
  ZoomOut, 
  Crosshair,
  Layers,
  Thermometer,
  CheckCircle2,
  Radio,
  Building2,
  Home,
  Compass
} from 'lucide-react';
import { RiderNode, ShelterNode, DonorNode, SubBatch } from '../types';

export const GoogleMapsDeliveryTracker: React.FC = () => {
  const { 
    riders, 
    shelters, 
    donors, 
    batches, 
    sendRiderHeartbeat, 
    triggerGhostRiderStall,
    triggerMidTransitShelterClosure,
    completeDelivery
  } = useSimulation();

  const [selectedRiderId, setSelectedRiderId] = useState<string>('rider_alex');
  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'terrain'>('roadmap');
  const [showTraffic, setShowTraffic] = useState<boolean>(true);
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  // Active deliveries
  const allSubBatches = batches.flatMap(b => b.subBatches.map(sb => ({ ...sb, parentBatch: b })));
  const currentRider = riders.find(r => r.id === selectedRiderId) || riders[0];
  const activeSubBatch = allSubBatches.find(sb => sb.id === currentRider?.activeSubBatchId);
  const targetShelter = shelters.find(s => s.id === activeSubBatch?.targetShelterId);
  const donor = donors.find(d => d.id === activeSubBatch?.donorId);

  // Waypoint coordinates
  const startX = donor ? donor.x : 24;
  const startY = donor ? donor.y : 28;
  const riderX = currentRider?.x ?? 58;
  const riderY = currentRider?.y ?? 25;
  const endX = targetShelter ? targetShelter.x : 72;
  const endY = targetShelter ? targetShelter.y : 22;

  return (
    <div className="space-y-4">
      
      {/* Google Maps Style Header Bar - Spacious & Airy */}
      <div className="flex flex-wrap items-center justify-between gap-6 p-5 sm:p-6 bg-white rounded-3xl border border-slate-200/90 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 shadow-sm shrink-0">
            <Navigation className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                Google Maps Delivery Routing & Telemetry
              </h2>
              <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100 px-3 py-0.5 rounded-full border border-emerald-300">
                Maps Engine Active
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Live GPS arterial tracking with collision detection and automated mid-transit rerouting.
            </p>
          </div>
        </div>

        {/* Courier selector */}
        <div className="flex items-center gap-2.5 overflow-x-auto max-w-full pb-1 sm:pb-0">
          <span className="text-xs sm:text-sm text-slate-400 font-medium whitespace-nowrap">Track Courier:</span>
          {riders.map(r => (
            <button
              key={r.id}
              onClick={() => setSelectedRiderId(r.id)}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-2xl transition-all whitespace-nowrap border ${
                selectedRiderId === r.id
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm shadow-emerald-600/20'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              🛵 {r.name.split(' ')[0]} {r.currentCargoCount > 0 ? `(${r.currentCargoCount} meals)` : ''}
            </button>
          ))}
        </div>
      </div>

      {/* Main Google Maps Box - Spacious Viewport Presence */}
      <div className={`relative w-full aspect-[16/9] min-h-[560px] sm:min-h-[640px] rounded-3xl border border-slate-200 overflow-hidden shadow-sm select-none transition-colors ${
        mapType === 'satellite' ? 'bg-[#0f1d14]' : mapType === 'terrain' ? 'bg-[#eef2e6]' : 'bg-[#e5e3df]'
      }`}>
        
        {/* SVG Map Canvas with Google Maps Road Vector Elements */}
        <svg 
          className="absolute inset-0 w-full h-full" 
          viewBox="0 0 1000 600" 
          preserveAspectRatio="none"
        >
          <defs>
            {/* Soft Green Eco Park */}
            <linearGradient id="gmapPark" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#c8e6c9" />
              <stop offset="100%" stopColor="#a5d6a7" />
            </linearGradient>

            {/* River Water Blue */}
            <linearGradient id="gmapWater" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#b3e5fc" />
              <stop offset="100%" stopColor="#81d4fa" />
            </linearGradient>

            {/* Glowing route effect */}
            <filter id="routeGlowGreen" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#059669" floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Urban Parks (Google Maps Style Greenery) */}
          <path d="M 60 50 C 120 30, 180 70, 220 120 C 230 180, 140 200, 70 170 Z" fill="url(#gmapPark)" opacity="0.9" />
          <text x="110" y="110" fill="#2e7d32" fontSize="11" fontWeight="700" opacity="0.6">Metro Botanical Gardens</text>

          <path d="M 690 330 C 760 310, 860 340, 910 400 C 900 480, 790 510, 720 460 Z" fill="url(#gmapPark)" opacity="0.9" />
          <text x="760" y="410" fill="#2e7d32" fontSize="11" fontWeight="700" opacity="0.6">Riverbank Eco Preserve</text>

          {/* Waterway (Google Maps Blue River) */}
          <path 
            d="M 330 0 C 360 160, 420 290, 395 410 C 375 500, 395 560, 430 600" 
            fill="none" 
            stroke="url(#gmapWater)" 
            strokeWidth="52" 
            strokeLinecap="round" 
            opacity="0.9"
          />
          <text x="360" y="250" fill="#0277bd" fontSize="11" fontWeight="700" opacity="0.6" transform="rotate(72 360 250)">Civic Riverway Canal</text>

          {/* Local Streets (White with subtle borders) */}
          <g stroke="#ffffff" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" opacity="0.95">
            <line x1="0" y1="130" x2="1000" y2="130" />
            <line x1="0" y1="270" x2="1000" y2="270" />
            <line x1="0" y1="420" x2="1000" y2="420" />
            <line x1="0" y1="530" x2="1000" y2="530" />

            <line x1="190" y1="0" x2="190" y2="600" />
            <line x1="510" y1="0" x2="510" y2="600" />
            <line x1="730" y1="0" x2="730" y2="600" />
            <line x1="890" y1="0" x2="890" y2="600" />

            <path d="M 0 360 L 330 190 L 710 270 L 1000 160" />
            <path d="M 130 600 L 410 420 L 790 510 L 1000 470" />
          </g>

          {/* Major Arterial Highways (Google Maps Yellow/Orange) */}
          <g stroke="#fed7aa" strokeWidth="16" strokeLinecap="round" strokeLinejoin="round" opacity="0.95">
            <line x1="0" y1="190" x2="1000" y2="190" />
            <line x1="370" y1="0" x2="370" y2="600" />
            <path d="M 110 60 L 530 290 L 860 190 L 990 330" />
          </g>

          <g stroke="#fdba74" strokeWidth="3" strokeDasharray="8 6" opacity="0.8">
            <line x1="0" y1="190" x2="1000" y2="190" />
            <line x1="370" y1="0" x2="370" y2="600" />
          </g>

          {/* Live Traffic Overlay (Green / Orange / Red) */}
          {showTraffic && (
            <g strokeLinecap="round" opacity="0.85">
              <line x1="20" y1="190" x2="350" y2="190" stroke="#4ade80" strokeWidth="4" />
              <line x1="370" y1="170" x2="370" y2="290" stroke="#f87171" strokeWidth="5" />
              <line x1="510" y1="270" x2="700" y2="270" stroke="#facc15" strokeWidth="4" />
            </g>
          )}

          {/* Road typography */}
          <text x="70" y="184" fill="#64748b" fontSize="10" fontWeight="700">National Bypass Express (NH-44)</text>
          <text x="380" y="90" fill="#64748b" fontSize="10" fontWeight="700" transform="rotate(90 380 90)">Central Tech Corridor</text>
          <text x="550" y="264" fill="#64748b" fontSize="10" fontWeight="700">Hospital Cross Road</text>
          <text x="750" y="124" fill="#64748b" fontSize="10" fontWeight="700">East Ring Highway</text>

          {/* GOOGLE MAPS NAVIGATION ROUTE POLYLINE */}
          {activeSubBatch && (
            <g filter="url(#routeGlowGreen)">
              {/* Outer stroke route */}
              <path
                d={`M ${startX * 10} ${startY * 6} Q ${(startX + riderX) * 5} ${startY * 6}, ${riderX * 10} ${riderY * 6} T ${endX * 10} ${endY * 6}`}
                fill="none"
                stroke={activeSubBatch.rerouted ? '#0284c7' : '#059669'}
                strokeWidth="7"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.9"
              />

              {/* Pulsing route arrows */}
              <path
                d={`M ${startX * 10} ${startY * 6} Q ${(startX + riderX) * 5} ${startY * 6}, ${riderX * 10} ${riderY * 6} T ${endX * 10} ${endY * 6}`}
                fill="none"
                stroke="#ffffff"
                strokeWidth="2.5"
                strokeDasharray="6 8"
                strokeLinecap="round"
              />
            </g>
          )}
        </svg>

        {/* Google Maps View Controls (Top Left & Top Right) */}
        <div className="absolute top-4 left-4 z-20 flex items-center gap-1.5 bg-white/95 backdrop-blur-md p-1 rounded-2xl border border-slate-200/90 shadow-sm">
          <button
            onClick={() => setMapType('roadmap')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              mapType === 'roadmap' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Map
          </button>
          <button
            onClick={() => setMapType('satellite')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              mapType === 'satellite' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Satellite
          </button>
          <button
            onClick={() => setMapType('terrain')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
              mapType === 'terrain' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Terrain
          </button>
        </div>

        {/* Zoom & Traffic Controls (Top Right) */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
          <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200 shadow-sm p-1 flex flex-col gap-1">
            <button 
              onClick={() => setZoomLevel(prev => Math.min(prev + 0.2, 1.6))}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-xl transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setZoomLevel(prev => Math.max(prev - 0.2, 0.8))}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-xl transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button 
              onClick={() => {}}
              className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-xl transition-colors"
              title="Center on Courier GPS"
            >
              <Crosshair className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => setShowTraffic(prev => !prev)}
            className={`px-3 py-1.5 rounded-xl border text-[11px] font-semibold backdrop-blur-md transition-all shadow-xs ${
              showTraffic
                ? 'bg-white text-emerald-800 border-emerald-300'
                : 'bg-slate-100 text-slate-400 border-slate-300'
            }`}
          >
            🚦 Traffic {showTraffic ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Google Maps Origin Pin: Food Donor */}
        {donors.map(d => {
          const isPickup = donor?.id === d.id;
          return (
            <div
              key={d.id}
              style={{ left: `${d.x}%`, top: `${d.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group cursor-pointer"
            >
              <div className="flex flex-col items-center">
                <div className={`p-2 rounded-2xl shadow-lg border transition-transform group-hover:scale-110 flex items-center justify-center ${
                  isPickup 
                    ? 'bg-emerald-600 text-white border-white ring-4 ring-emerald-200 shadow-emerald-200' 
                    : 'bg-white text-emerald-700 border-slate-200'
                }`}>
                  <Building2 className="w-4 h-4" />
                </div>
                <div className="mt-1 px-2.5 py-0.5 rounded-full bg-white/95 border border-slate-200 text-[10px] font-bold text-slate-800 whitespace-nowrap shadow-xs">
                  {d.name.split(' ')[0]} (Pick-up)
                </div>
              </div>
            </div>
          );
        })}

        {/* Google Maps Destination Pin: Food Receiver / Shelter */}
        {shelters.map(s => {
          const isTarget = targetShelter?.id === s.id;
          const isFilled = s.demandRemaining.cooked_meals === 0;

          return (
            <div
              key={s.id}
              style={{ left: `${s.x}%`, top: `${s.y}%` }}
              className="absolute -translate-x-1/2 -translate-y-1/2 z-20 group cursor-pointer"
            >
              <div className="flex flex-col items-center">
                <div className={`p-2 rounded-2xl shadow-lg border transition-transform group-hover:scale-110 flex items-center justify-center ${
                  isTarget 
                    ? 'bg-rose-500 text-white border-white ring-4 ring-rose-200 shadow-rose-200' 
                    : isFilled 
                      ? 'bg-slate-200 text-slate-500 border-slate-300' 
                      : 'bg-white text-rose-500 border-rose-200'
                }`}>
                  <Home className="w-4 h-4" />
                </div>
                
                <div className="mt-1 px-2.5 py-0.5 rounded-full bg-white/95 border border-slate-200 text-[10px] font-bold text-slate-800 whitespace-nowrap shadow-xs flex flex-col items-center">
                  <span>{s.name.split(' ')[0]}</span>
                  <span className="text-[9px] font-mono text-slate-500 font-normal">
                    {isFilled ? 'Demand Met (0)' : `Need: ${s.demandRemaining.cooked_meals}`}
                  </span>
                </div>
              </div>
            </div>
          );
        })}

        {/* Moving Delivery Courier Marker */}
        {riders.map(r => {
          const isSelected = selectedRiderId === r.id;
          const isUnresponsive = r.status === 'unresponsive';

          return (
            <div
              key={r.id}
              onClick={() => setSelectedRiderId(r.id)}
              style={{ left: `${r.x}%`, top: `${r.y}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 z-30 cursor-pointer transition-all duration-700 ease-out ${
                isSelected ? 'scale-110' : 'hover:scale-105'
              }`}
            >
              <div className="flex flex-col items-center relative">
                
                {/* Google Maps GPS Ping Radar */}
                {isSelected && (
                  <span className="absolute -inset-2 rounded-full bg-emerald-400/40 animate-ping pointer-events-none" />
                )}

                <div className={`w-10 h-10 rounded-full flex items-center justify-center border shadow-md relative ${
                  isSelected 
                    ? 'bg-emerald-600 text-white border-white shadow-emerald-300 ring-2 ring-emerald-400' 
                    : isUnresponsive
                      ? 'bg-amber-500 text-white border-white animate-bounce'
                      : 'bg-white text-emerald-600 border-emerald-200'
                }`}>
                  <Bike className="w-5 h-5" />
                </div>

                <div className="mt-1 px-2 py-0.5 rounded-full bg-slate-900 text-white text-[9px] font-mono font-medium whitespace-nowrap shadow-xs flex items-center gap-1">
                  <span>{r.name.split(' ')[0]}</span>
                  {r.currentCargoCount > 0 && (
                    <span className="text-emerald-300 font-bold">· {r.currentCargoCount} meals</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* FLOATING GOOGLE MAPS NAVIGATION & TELEMETRY CARD */}
        {activeSubBatch && currentRider && (
          <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:max-w-md z-30 bg-white/95 backdrop-blur-md rounded-3xl border border-slate-200 shadow-xl p-4 transition-all">
            
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 font-bold text-lg shrink-0 shadow-xs">
                  🛵
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                      {currentRider.name}
                    </h3>
                    <span className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-100 px-2 py-0.2 rounded-full border border-emerald-300">
                      ★ {currentRider.reliabilityScore}% On-Time
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Carrying {activeSubBatch.quantity} Meals · {activeSubBatch.parentBatch.title}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-lg font-bold font-mono text-emerald-600 tabular-nums">
                  {activeSubBatch.deliveryEtaMinutes} mins
                </span>
                <span className="text-[10px] text-slate-400 block uppercase font-medium">ETA to drop-off</span>
              </div>
            </div>

            {/* Dynamic Reroute Alert Banner */}
            {activeSubBatch.rerouted && (
              <div className="mt-3 p-3 rounded-2xl bg-sky-50 border border-sky-200 text-xs text-sky-950 flex items-start gap-2 animate-in fade-in">
                <Navigation className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Dynamic Destination Mutation Detected:</span> Shelter Alpha closed by walk-in donation. Rerouting to <strong>Shelter Echo</strong> (Safe shelf-life window preserved).
                </div>
              </div>
            )}

            {/* Thermal IoT Temperature Telemetry & Shelf-life */}
            <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-3 text-xs">
              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-xl border border-slate-200">
                <Thermometer className="w-4 h-4 text-rose-500" />
                <div>
                  <span className="text-[10px] text-slate-400 block">Cargo Temp</span>
                  <strong className="font-mono text-slate-800">
                    {activeSubBatch.parentBatch.safetyCheck.currentTempC}°C (Hot)
                  </strong>
                </div>
              </div>

              <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-xl border border-slate-200">
                <Clock className="w-4 h-4 text-amber-500" />
                <div>
                  <span className="text-[10px] text-slate-400 block">Safe Window</span>
                  <strong className="font-mono text-slate-800">
                    {Math.round(activeSubBatch.parentBatch.remainingSafeMinutes)}m left
                  </strong>
                </div>
              </div>
            </div>

            {/* Handover & Heartbeat action buttons */}
            <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                onClick={() => sendRiderHeartbeat(currentRider.id)}
                className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5"
              >
                <Radio className="w-3.5 h-3.5 text-emerald-600" />
                <span>GPS Heartbeat ({currentRider.lastHeartbeatSecondsAgo}s)</span>
              </button>

              <button
                onClick={() => completeDelivery(activeSubBatch.id)}
                className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verify Handover</span>
              </button>
            </div>

          </div>
        )}

      </div>

      {/* Operational Test Triggers for Judges and Evaluators - Spacious & Airy */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs sm:text-sm">
        <button
          onClick={() => triggerMidTransitShelterClosure('shelter_alpha', 50)}
          className="p-5 sm:p-6 bg-white hover:bg-slate-50 border border-slate-200/90 rounded-3xl font-medium text-slate-700 transition-all flex items-center gap-4 shadow-sm text-left hover:border-emerald-300"
        >
          <div className="w-10 h-10 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
            <Home className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-slate-900 text-sm">Shelter Alpha Closes Mid-Transit</div>
            <div className="text-xs text-slate-500 mt-0.5">Citizen dropoff triggers instant rerouting</div>
          </div>
        </button>

        <button
          onClick={() => triggerGhostRiderStall(currentRider.id)}
          className="p-5 sm:p-6 bg-white hover:bg-slate-50 border border-slate-200/90 rounded-3xl font-medium text-slate-700 transition-all flex items-center gap-4 shadow-sm text-left hover:border-amber-300"
        >
          <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-slate-900 text-sm">Courier Goes Unresponsive</div>
            <div className="text-xs text-slate-500 mt-0.5">Heartbeat SLA decays & hands over to Maya</div>
          </div>
        </button>

        <button
          onClick={() => sendRiderHeartbeat(currentRider.id)}
          className="p-5 sm:p-6 bg-white hover:bg-slate-50 border border-slate-200/90 rounded-3xl font-medium text-slate-700 transition-all flex items-center gap-4 shadow-sm text-left hover:border-emerald-300"
        >
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="font-bold text-slate-900 text-sm">Send Courier Breadcrumb</div>
            <div className="text-xs text-slate-500 mt-0.5">Refreshes GPS & resets ghost claim SLA</div>
          </div>
        </button>
      </div>

    </div>
  );
};
