import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Building2, 
  Bike, 
  Home, 
  ArrowRight, 
  CheckCircle2, 
  Plus, 
  MapPin, 
  Clock, 
  Thermometer, 
  ShieldCheck, 
  Split, 
  Radio, 
  Navigation, 
  Package, 
  Droplets, 
  Zap, 
  FileText, 
  UserCheck,
  ArrowLeftRight
} from 'lucide-react';
import { UserRole } from '../types';

interface CorporateLandingViewProps {
  onSelectRole: (role: UserRole) => void;
  onOpenProblemStatement: () => void;
  onOpenJudgeSuite: () => void;
  onOpenNewBatchModal: () => void;
  onOpenMap: () => void;
  onOpenRoleLogin: () => void;
}

export const CorporateLandingView: React.FC<CorporateLandingViewProps> = ({
  onSelectRole,
  onOpenProblemStatement,
  onOpenJudgeSuite,
  onOpenNewBatchModal,
  onOpenMap,
  onOpenRoleLogin
}) => {
  const { batches, riders, shelters, donors } = useSimulation();

  const totalMealsInSystem = batches.reduce((acc, b) => acc + b.totalQuantity, 0);
  const activeTransits = batches.flatMap(b => b.subBatches).filter(sb => sb.status === 'in_transit').length;
  const availableLots = batches.filter(b => b.remainingSafeMinutes > 10 && b.status !== 'completed').length;

  return (
    <div className="space-y-10 sm:space-y-12 py-2">
      
      {/* 1. Header Banner - Clean, Focused, Non-Cluttered */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-50 via-teal-50/60 to-emerald-50 border border-emerald-200/90 p-8 sm:p-12 text-center shadow-xs">
        <div className="max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/90 border border-emerald-300 text-xs font-bold text-emerald-800">
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
            <span>Three Specialized Civic Micro-Logistics Portals</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Last-Mile Spoilage Trap
          </h1>

          <p className="text-sm sm:text-base text-slate-600 max-w-2xl mx-auto leading-relaxed">
            Eliminating food waste and fragile aid spoilage under real-world uncertainty. Select your specialized portal below to access dedicated real-time tools for Donors, Delivery Couriers, or Food Receivers.
          </p>

          {/* Quick Status Pill Bar */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2 text-xs font-medium text-slate-600">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/80 rounded-full border border-emerald-200 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <strong>{totalMealsInSystem}</strong> Surplus Portions Active
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/80 rounded-full border border-sky-200 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-sky-500" />
              <strong>{activeTransits}</strong> Couriers En Route
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/80 rounded-full border border-slate-200 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-slate-500" />
              <strong>{shelters.length}</strong> Community Shelters Ready
            </span>
          </div>
        </div>
      </section>

      {/* 2. THE THREE SPECIALIZED PORTALS (The Focal Point of Front Page) */}
      <section className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-2 px-1">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900">
              Select Your Specialized Portal
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Each portal provides role-tailored dashboards, real-time telemetry, and automated failure protections.
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-300">
            3 Portals Active
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          
          {/* ==================== PORTAL 1: FOOD DONORS ==================== */}
          <div className="p-7 sm:p-8 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              
              {/* Card Header & Badge */}
              <div className="flex items-start justify-between gap-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 shadow-xs shrink-0">
                  <Building2 className="w-7 h-7" />
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-mono font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300 block">
                    Portal 01
                  </span>
                  <span className="text-xs text-emerald-700 font-semibold mt-1 inline-block">Surplus Dispatch</span>
                </div>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Food Donors Portal
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  For Commercial Kitchens, Hotels, Banquet Halls, Caterers & Corporate Messes
                </p>
              </div>

              {/* Real-time live status strip */}
              <div className="p-3.5 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-xs space-y-1">
                <div className="flex justify-between items-center text-emerald-950 font-bold">
                  <span>Registered Donors:</span>
                  <span className="font-mono text-emerald-800">{donors.length} Verified Facilities</span>
                </div>
                <div className="flex justify-between items-center text-slate-600">
                  <span>Surplus Portions Ready:</span>
                  <span className="font-mono font-bold text-emerald-700">{totalMealsInSystem} portions</span>
                </div>
              </div>

              {/* Key Functional Capabilities */}
              <div className="space-y-2.5 pt-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Core Portal Workflows
                </span>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-600">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Surplus Food Upload:</strong> Post cooked lots with exact shelf-life countdown clock.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Split className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Bulk Decomposition:</strong> Slices 180+ meal lots into 40-unit parallel scooter runs.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Thermometer className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <span><strong>FSSAI Thermal Safety:</strong> Digital probe verification (≥65°C hot holding standard).</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <span><strong>Courier Allocation:</strong> Live tracking as couriers accept and pick up parcels.</span>
                  </li>
                </ul>
              </div>

            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-100 space-y-2.5">
              <button
                onClick={() => onSelectRole('donor')}
                className="w-full py-3.5 px-5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-md shadow-emerald-600/25 active:scale-95 flex items-center justify-center gap-2"
              >
                <Building2 className="w-4 h-4" />
                <span>Enter Food Donor Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenNewBatchModal}
                className="w-full py-2.5 px-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Quick Upload Surplus Food</span>
              </button>
            </div>
          </div>

          {/* ==================== PORTAL 2: DELIVERY RIDERS ==================== */}
          <div className="p-7 sm:p-8 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-sky-300 hover:shadow-md transition-all flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              
              {/* Card Header & Badge */}
              <div className="flex items-start justify-between gap-4">
                <div className="w-14 h-14 rounded-2xl bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700 shadow-xs shrink-0">
                  <Bike className="w-7 h-7" />
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-mono font-extrabold uppercase tracking-wider text-sky-800 bg-sky-100 px-3 py-1 rounded-full border border-sky-300 block">
                    Portal 02
                  </span>
                  <span className="text-xs text-sky-700 font-semibold mt-1 inline-block">Two-Wheeler Logistics</span>
                </div>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Delivery Riders Portal
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  For Volunteer Couriers, Two-Wheeler Riders & Civic Delivery Fleets
                </p>
              </div>

              {/* Real-time live status strip */}
              <div className="p-3.5 bg-sky-50/60 rounded-2xl border border-sky-200 text-xs space-y-1">
                <div className="flex justify-between items-center text-sky-950 font-bold">
                  <span>Courier Fleet:</span>
                  <span className="font-mono text-sky-800">{riders.length} Registered Couriers</span>
                </div>
                <div className="flex justify-between items-center text-slate-600">
                  <span>Active On-Road Transits:</span>
                  <span className="font-mono font-bold text-sky-700">{activeTransits} courier runs</span>
                </div>
              </div>

              {/* Key Functional Capabilities */}
              <div className="space-y-2.5 pt-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Core Portal Workflows
                </span>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-600">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                    <span><strong>Open Pickup Queue:</strong> View and claim 40-meal courier runs waiting nearby.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                    <span><strong>Google Maps Navigation:</strong> Turn-by-turn road polyline with live traffic overlay.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Radio className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <span><strong>Ghost Claim SLA Watchdog:</strong> Heartbeat watchdog revokes claims if GPS stalls.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Navigation className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Mid-Transit Rerouting:</strong> Automatic destination reroute if a shelter gets filled.</span>
                  </li>
                </ul>
              </div>

            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-100 space-y-2.5">
              <button
                onClick={() => onSelectRole('rider')}
                className="w-full py-3.5 px-5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-md shadow-sky-600/25 active:scale-95 flex items-center justify-center gap-2"
              >
                <Bike className="w-4 h-4" />
                <span>Enter Delivery Rider Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenMap}
                className="w-full py-2.5 px-4 bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-900 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Open Live Google Maps Tracker</span>
              </button>
            </div>
          </div>

          {/* ==================== PORTAL 3: FOOD RECEIVERS ==================== */}
          <div className="p-7 sm:p-8 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              
              {/* Card Header & Badge */}
              <div className="flex items-start justify-between gap-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 shadow-xs shrink-0">
                  <Home className="w-7 h-7" />
                </div>
                <div className="text-right">
                  <span className="text-[11px] font-mono font-extrabold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300 block">
                    Portal 03
                  </span>
                  <span className="text-xs text-emerald-700 font-semibold mt-1 inline-block">Community Facilities</span>
                </div>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  Food Receivers Portal
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  For Night Shelters, Relief Camps, Care Homes & Community Kitchens
                </p>
              </div>

              {/* Real-time live status strip */}
              <div className="p-3.5 bg-emerald-50/60 rounded-2xl border border-emerald-200 text-xs space-y-1">
                <div className="flex justify-between items-center text-emerald-950 font-bold">
                  <span>Shelter Network:</span>
                  <span className="font-mono text-emerald-800">{shelters.length} Facilities Connected</span>
                </div>
                <div className="flex justify-between items-center text-slate-600">
                  <span>Available Food Lots:</span>
                  <span className="font-mono font-bold text-emerald-700">{availableLots} lots ready</span>
                </div>
              </div>

              {/* Key Functional Capabilities */}
              <div className="space-y-2.5 pt-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Core Portal Workflows
                </span>
                <ul className="space-y-2 text-xs sm:text-sm text-slate-600">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>Browse Surplus Catalog:</strong> Search available cooked meals & 1-click request.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Droplets className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                    <span><strong>Prerequisite Hygiene Gate:</strong> Requires verified clean water & cooking fuel.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <Home className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <span><strong>Walk-in Surplus Logging:</strong> Log spontaneous donations and trigger rerouting.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span><strong>OTP Handover Sign-Off:</strong> Confirm physical receipt via shelter verification code.</span>
                  </li>
                </ul>
              </div>

            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-100 space-y-2.5">
              <button
                onClick={() => onSelectRole('shelter')}
                className="w-full py-3.5 px-5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-md active:scale-95 flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                <span>Enter Food Receiver Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectRole('shelter')}
                className="w-full py-2.5 px-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-900 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
              >
                <Package className="w-3.5 h-3.5" />
                <span>Browse Available Food Surplus</span>
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* 3. Clean Quick Utility Bar (Problem Brief, Failure Sandbox, Role Login) */}
      <section className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
            Mesh
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">
              Enterprise Resilience & Authentication
            </h4>
            <p className="text-xs text-slate-500">
              Need to test edge-cases or register as a donor, courier, or shelter coordinator?
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          <button
            onClick={onOpenRoleLogin}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl transition-colors"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-slate-600" />
            <span>Role Login / Sign Up</span>
          </button>

          <button
            onClick={onOpenJudgeSuite}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold rounded-xl transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-emerald-600" />
            <span>Test 4 Invariant Failures</span>
          </button>

          <button
            onClick={onOpenProblemStatement}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold rounded-xl transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-slate-500" />
            <span>Problem Brief</span>
          </button>
        </div>
      </section>

    </div>
  );
};
