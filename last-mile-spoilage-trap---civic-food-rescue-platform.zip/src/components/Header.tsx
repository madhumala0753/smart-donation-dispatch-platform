import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  ShieldCheck, 
  FileText, 
  Zap, 
  LogOut, 
  Bell, 
  MapPin, 
  History, 
  LayoutDashboard,
  Building2,
  Bike,
  Home
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenJudgeSuite: () => void;
  onOpenProblemStatement: () => void;
  onOpenNotifications: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenJudgeSuite,
  onOpenProblemStatement,
  onOpenNotifications
}) => {
  const { currentUser, logout, notifications } = useSimulation();
  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-6 px-6 sm:px-10 lg:px-12 py-4 bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-2xs">
      
      {/* Zone 1: Brand wordmark (single text element) */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={() => setActiveTab('corporate_landing')}
          className="flex items-center gap-2.5 text-left group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-xs group-hover:bg-emerald-700 transition-colors">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <span className="text-sm sm:text-base font-extrabold tracking-tight text-slate-900 whitespace-nowrap">
            Last-Mile Spoilage Trap
          </span>
        </button>
      </div>

      {/* Zone 2: Navigation links */}
      <nav className="hidden lg:flex items-center gap-5 text-xs font-semibold text-slate-600">
        
        <button
          onClick={() => setActiveTab('corporate_landing')}
          className={`whitespace-nowrap transition-colors hover:text-slate-900 pb-0.5 ${
            activeTab === 'corporate_landing' 
              ? 'text-emerald-700 border-b-2 border-emerald-600 font-bold' 
              : ''
          }`}
        >
          3 Portals (Front Page)
        </button>

        <button
          onClick={() => setActiveTab('donor_home')}
          className={`whitespace-nowrap transition-colors hover:text-slate-900 pb-0.5 flex items-center gap-1.5 ${
            activeTab === 'donor_home' 
              ? 'text-emerald-700 border-b-2 border-emerald-600 font-bold' 
              : ''
          }`}
        >
          <Building2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>1. Food Donors</span>
        </button>

        <button
          onClick={() => setActiveTab('rider_home')}
          className={`whitespace-nowrap transition-colors hover:text-slate-900 pb-0.5 flex items-center gap-1.5 ${
            activeTab === 'rider_home' 
              ? 'text-emerald-700 border-b-2 border-emerald-600 font-bold' 
              : ''
          }`}
        >
          <Bike className="w-3.5 h-3.5 text-sky-600" />
          <span>2. Delivery Riders</span>
        </button>

        <button
          onClick={() => setActiveTab('shelter_home')}
          className={`whitespace-nowrap transition-colors hover:text-slate-900 pb-0.5 flex items-center gap-1.5 ${
            activeTab === 'shelter_home' 
              ? 'text-emerald-700 border-b-2 border-emerald-600 font-bold' 
              : ''
          }`}
        >
          <Home className="w-3.5 h-3.5 text-emerald-600" />
          <span>3. Food Receivers</span>
        </button>

        <button
          onClick={() => setActiveTab('map')}
          className={`whitespace-nowrap transition-colors hover:text-slate-900 pb-0.5 flex items-center gap-1 ${
            activeTab === 'map' 
              ? 'text-emerald-700 border-b-2 border-emerald-600 font-bold' 
              : ''
          }`}
        >
          <MapPin className="w-3.5 h-3.5 text-rose-500" />
          <span>Google Maps Tracker</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`whitespace-nowrap transition-colors hover:text-slate-900 pb-0.5 flex items-center gap-1 ${
            activeTab === 'history' 
              ? 'text-emerald-700 border-b-2 border-emerald-600 font-bold' 
              : ''
          }`}
        >
          <History className="w-3.5 h-3.5 text-slate-500" />
          <span>Donation History</span>
        </button>

        <button
          onClick={onOpenProblemStatement}
          className="flex items-center gap-1 text-slate-500 hover:text-emerald-700 transition-colors whitespace-nowrap font-medium"
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Brief</span>
        </button>
      </nav>

      {/* Zone 3: Notification Bell & Profile Controls */}
      <div className="flex items-center gap-3 shrink-0">
        
        {/* Real-time Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          title="Real-Time Alerts"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-white font-mono text-[9px] font-bold flex items-center justify-center ring-2 ring-white">
              {unreadCount}
            </span>
          )}
        </button>

        {/* Current user role badge */}
        {currentUser ? (
          <div className="flex items-center gap-1.5">
            <div className="px-2.5 py-1 rounded-xl text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-2xs flex items-center gap-1.5">
              <span>
                {currentUser.role === 'donor' ? '🍲 Donor' : currentUser.role === 'rider' ? '🛵 Rider' : currentUser.role === 'shelter' ? '🏠 Receiver' : '🛡️ Admin'}
              </span>
              <span className="text-[11px] text-slate-500 font-normal">({currentUser.name.split(' ')[0]})</span>
            </div>

            <button
              onClick={logout}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
              title="Sign Out / Switch Role"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={logout}
            className="text-xs font-bold text-emerald-700 hover:underline"
          >
            Sign In
          </button>
        )}

        <button
          onClick={onOpenJudgeSuite}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-all shadow-xs shadow-emerald-600/20 whitespace-nowrap active:scale-[0.98]"
        >
          <Zap className="w-3.5 h-3.5 fill-white" />
          <span>Failure Tests</span>
        </button>

      </div>

    </header>
  );
};
