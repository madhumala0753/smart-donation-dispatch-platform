import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { Play, Pause, FastForward, RotateCcw, AlertTriangle, Users, MapPin, ShieldAlert, Sparkles } from 'lucide-react';

interface JudgeSimulatorBarProps {
  onOpenDetails: () => void;
}

export const JudgeSimulatorBar: React.FC<JudgeSimulatorBarProps> = ({ onOpenDetails }) => {
  const {
    simulationSpeed,
    setSimulationSpeed,
    isPaused,
    togglePause,
    resetToInitial,
    triggerGhostRiderStall,
    triggerMidTransitShelterClosure,
    triggerBulkSurgePartition,
    triggerDependencyDispatchTest,
    virtualTimeElapsedSeconds,
    activeScenarioId
  } = useSimulation();

  const minutesElapsed = Math.floor(virtualTimeElapsedSeconds / 60);
  const secondsElapsed = Math.floor(virtualTimeElapsedSeconds % 60);

  return (
    <div className="bg-white/95 border-b border-slate-200/90 px-6 py-2.5 shadow-2xs">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
        
        {/* Left: Simulation Time & Speed Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span className="text-slate-700 font-semibold">Virtual Time:</span>
            <span className="font-mono text-rose-600 font-bold tabular-nums bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
              +{String(minutesElapsed).padStart(2, '0')}:{String(secondsElapsed).padStart(2, '0')}
            </span>
          </div>

          <div className="h-4 w-px bg-slate-200 mx-1" />

          {/* Time speed selector */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
            <button
              onClick={togglePause}
              title={isPaused ? "Resume simulation" : "Pause simulation"}
              className={`p-1.5 rounded-lg text-xs transition-colors ${
                isPaused 
                  ? 'bg-amber-100 text-amber-900 font-bold shadow-2xs' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {isPaused ? <Play className="w-3.5 h-3.5 fill-amber-700 text-amber-700" /> : <Pause className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => { if (isPaused) togglePause(); setSimulationSpeed(1); }}
              className={`px-2.5 py-1 text-xs font-mono transition-colors rounded-lg ${
                !isPaused && simulationSpeed === 1 
                  ? 'bg-white text-slate-900 font-bold shadow-2xs' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              1x
            </button>
            <button
              onClick={() => { if (isPaused) togglePause(); setSimulationSpeed(5); }}
              className={`px-2.5 py-1 text-xs font-mono transition-colors rounded-lg ${
                !isPaused && simulationSpeed === 5 
                  ? 'bg-white text-rose-600 font-bold shadow-2xs' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              5x
            </button>
            <button
              onClick={() => { if (isPaused) togglePause(); setSimulationSpeed(15); }}
              className={`px-2.5 py-1 text-xs font-mono transition-colors rounded-lg flex items-center gap-1 ${
                !isPaused && simulationSpeed === 15 
                  ? 'bg-rose-50 text-rose-700 font-bold border border-rose-200 shadow-2xs' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FastForward className="w-3 h-3" />
              15x
            </button>
          </div>

          <button
            onClick={resetToInitial}
            className="p-1.5 text-xs text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
            title="Reset Simulation State"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Center / Right: Live Failure Scenario Buttons for Judges */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          <span className="text-slate-400 text-xs hidden lg:inline font-medium">
            Test Failures:
          </span>

          {/* Trigger 1: Ghost Volunteer Stall */}
          <button
            onClick={() => triggerGhostRiderStall('rider_ravi')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all ${
              activeScenarioId === 'ghost_rider_stall'
                ? 'bg-amber-100 text-amber-900 border-amber-300 font-semibold'
                : 'bg-amber-50/70 border-amber-200/80 hover:bg-amber-100 text-amber-800'
            }`}
            title="Volunteer claims 40 meals, goes unresponsive. Watch SLA heartbeat breach and auto-reassignment to Standby Reserve Rider."
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span>1. Ghost Claim Stall</span>
          </button>

          {/* Trigger 2: Mid-Transit Shelter Closure */}
          <button
            onClick={() => triggerMidTransitShelterClosure('shelter_alpha', 50)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all ${
              activeScenarioId === 'shelter_closure_midtransit'
                ? 'bg-sky-100 text-sky-900 border-sky-300 font-semibold'
                : 'bg-sky-50/70 border-sky-200/80 hover:bg-sky-100 text-sky-800'
            }`}
            title="Citizen walks into Shelter Alpha with 50 meals. Incoming Rider Alex is dynamically rerouted mid-journey to Shelter Echo."
          >
            <MapPin className="w-3.5 h-3.5 text-sky-600" />
            <span>2. Mid-Transit Shelter Reroute</span>
          </button>

          {/* Trigger 3: Bulk Surge Split */}
          <button
            onClick={() => triggerBulkSurgePartition(180, 65)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all ${
              activeScenarioId === 'bulk_surge_partition'
                ? 'bg-emerald-100 text-emerald-900 border-emerald-300 font-semibold'
                : 'bg-emerald-50/70 border-emerald-200/80 hover:bg-emerald-100 text-emerald-800'
            }`}
            title="180 cooked meals donated at once with 65-min safe window. Auto-splits across 4 riders and multiple receiving shelters."
          >
            <Users className="w-3.5 h-3.5 text-emerald-600" />
            <span>3. Bulk Surge (180 Meals)</span>
          </button>

          {/* Trigger 4: Dependency Check Trap */}
          <button
            onClick={() => triggerDependencyDispatchTest('shelter_charlie')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all ${
              activeScenarioId === 'dependency_safety_trap'
                ? 'bg-rose-100 text-rose-900 border-rose-300 font-semibold'
                : 'bg-rose-50/70 border-rose-200/80 hover:bg-rose-100 text-rose-800'
            }`}
            title="Attempts dispatch of Infant Formula to Flood Camp Charlie which lacks clean water. System blocks dispatch until verified."
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>4. Prerequisite Lockout</span>
          </button>

          {/* Inspect All Scenarios */}
          <button
            onClick={onOpenDetails}
            className="text-xs text-rose-600 hover:text-rose-700 font-semibold underline underline-offset-2 ml-1"
          >
            Details
          </button>
        </div>

      </div>
    </div>
  );
};
