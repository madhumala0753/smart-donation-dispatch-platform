import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  X, 
  Bell, 
  CheckCheck, 
  Navigation, 
  Bike, 
  Building2, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck 
} from 'lucide-react';
import { RealtimeNotification } from '../types';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ isOpen, onClose }) => {
  const { notifications, markNotificationAsRead, clearNotifications } = useSimulation();

  if (!isOpen) return null;

  const getNotifIcon = (type: RealtimeNotification['type']) => {
    switch (type) {
      case 'surplus_posted':
        return <Building2 className="w-4 h-4 text-emerald-600" />;
      case 'courier_accepted':
        return <Bike className="w-4 h-4 text-sky-600" />;
      case 'rerouted':
        return <Navigation className="w-4 h-4 text-amber-600" />;
      case 'safety_flag':
        return <AlertTriangle className="w-4 h-4 text-rose-600" />;
      case 'delivered':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/30 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white border-l border-slate-200 shadow-2xl flex flex-col">
          
          {/* Header */}
          <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shadow-xs">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">
                  Real-Time Platform Alerts
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Live dispatch, routing updates & food safety flags
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Action Strip */}
          <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span className="font-medium font-mono text-[11px] text-emerald-800">
              {notifications.filter(n => !n.isRead).length} unread updates
            </span>
            <button
              onClick={clearNotifications}
              className="text-xs text-slate-500 hover:text-emerald-700 font-semibold flex items-center gap-1 transition-colors"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Clear all</span>
            </button>
          </div>

          {/* Notifications List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {notifications.length > 0 ? (
              notifications.map(n => (
                <div
                  key={n.id}
                  onClick={() => markNotificationAsRead(n.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    n.isRead 
                      ? 'bg-white border-slate-200/70 hover:bg-slate-50/60' 
                      : 'bg-emerald-50/50 border-emerald-200 ring-1 ring-emerald-200/50 shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 p-2 rounded-xl bg-white border border-slate-200 shadow-2xs">
                        {getNotifIcon(n.type)}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900">
                          {n.title}
                        </h4>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {n.message}
                        </p>
                      </div>
                    </div>

                    <span className="text-[10px] font-mono text-slate-400 whitespace-nowrap mt-0.5">
                      {n.time}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-16 text-center space-y-2">
                <Bell className="w-8 h-8 text-slate-300 mx-auto" />
                <h4 className="text-sm font-semibold text-slate-700">No New Notifications</h4>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  Alerts on surplus listings, route modifications, and delivery handovers will appear here in real time.
                </p>
              </div>
            )}
          </div>

          {/* Footer note */}
          <div className="p-4 border-t border-slate-100 bg-slate-50 text-center text-xs text-slate-400">
            Last-Mile Spoilage Trap · Operational Push Gateway
          </div>

        </div>
      </div>
    </div>
  );
};
