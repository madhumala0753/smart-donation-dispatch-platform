import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Building2, 
  Home, 
  Bike, 
  Truck, 
  AlertTriangle, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  ArrowRight,
  ShieldAlert,
  Flame,
  Droplets,
  RotateCcw
} from 'lucide-react';
import { RiderNode, ShelterNode, DonorNode, SubBatch } from '../types';

export const TopologyMap: React.FC = () => {
  const { 
    riders, 
    shelters, 
    donors, 
    batches, 
    sendRiderHeartbeat, 
    triggerGhostRiderStall,
    triggerMidTransitShelterClosure,
    resolvePrerequisite
  } = useSimulation();

  const [selectedEntity, setSelectedEntity] = useState<{
    type: 'rider' | 'shelter' | 'donor';
    id: string;
  } | null>({ type: 'rider', id: 'rider_ravi' });

  // Get active sub-batches
  const allSubBatches = batches.flatMap(b => b.subBatches);

  // Find entity details if selected
  const selectedRider = selectedEntity?.type === 'rider' ? riders.find(r => r.id === selectedEntity.id) : null;
  const selectedShelter = selectedEntity?.type === 'shelter' ? shelters.find(s => s.id === selectedEntity.id) : null;
  const selectedDonor = selectedEntity?.type === 'donor' ? donors.find(d => d.id === selectedEntity.id) : null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
      
      {/* Main Interactive Map Viewport (3 cols) */}
      <div className="lg:col-span-3 bg-slate-900 rounded-xl border border-slate-800 p-5 relative overflow-hidden shadow-xl">
        
        {/* Header Strip inside Map */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-base font-semibold text-white tracking-tight">
              Urban Micro-Logistics Topology
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span>Zone 4 Civic Relief Grid</span>
              <span aria-hidden="true">·</span>
              <span>Live Coordinate Plane</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400 font-mono tabular-nums">{riders.filter(r => r.status === 'in_transit').length} active transits</span>
            </div>
          </div>

          {/* Map Legend */}
          <div className="flex items-center gap-4 text-xs text-slate-400">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
              <span>Surplus Donors</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" />
              <span>Volunteer Riders</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
              <span>Shelters / Relief Camps</span>
            </div>
          </div>
        </div>

        {/* The SVG Graphic Coordinate Area */}
        <div className="relative w-full aspect-[16/10] bg-slate-950/80 rounded-lg border border-slate-800/80 p-4 overflow-hidden select-none">
          
          {/* Subtle grid lines background */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#475569" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>

          {/* SVG Vector Paths for Active Transits & Rerouting */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
            {allSubBatches.map(sb => {
              const rider = riders.find(r => r.id === sb.riderId);
              const targetShelter = shelters.find(s => s.id === sb.targetShelterId);
              const donor = donors.find(d => d.id === sb.donorId);
              if (!targetShelter) return null;

              // If in transit, draw line from rider current (or donor) to target shelter
              const startX = rider ? rider.x : (donor ? donor.x : 50);
              const startY = rider ? rider.y : (donor ? donor.y : 50);
              const endX = targetShelter.x;
              const endY = targetShelter.y;

              const isRerouted = sb.rerouted;
              const isUnresponsive = rider?.status === 'unresponsive';

              return (
                <g key={`path_${sb.id}`}>
                  {/* Transit line */}
                  <line
                    x1={`${startX}%`}
                    y1={`${startY}%`}
                    x2={`${endX}%`}
                    y2={`${endY}%`}
                    stroke={isRerouted ? '#38bdf8' : isUnresponsive ? '#f59e0b' : '#10b981'}
                    strokeWidth={isRerouted ? '2.5' : '1.5'}
                    strokeDasharray={isRerouted ? '6,4' : '4,4'}
                    strokeOpacity={0.65}
                  />

                  {/* If rerouted, label line */}
                  {isRerouted && (
                    <text
                      x={`${(startX + endX) / 2}%`}
                      y={`${(startY + endY) / 2 - 3}%`}
                      fill="#38bdf8"
                      fontSize="9"
                      fontFamily="JetBrains Mono, monospace"
                      textAnchor="middle"
                      className="font-semibold"
                    >
                      DYNAMIC REROUTE ACTIVE
                    </text>
                  )}
                </g>
              );
            })}
          </svg>

          {/* Node Renderers: Donors */}
          {donors.map(donor => (
            <button
              key={donor.id}
              onClick={() => setSelectedEntity({ type: 'donor', id: donor.id })}
              style={{ left: `${donor.x}%`, top: `${donor.y}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group transition-transform ${
                selectedEntity?.id === donor.id ? 'scale-110' : 'hover:scale-105'
              }`}
            >
              <div className="flex flex-col items-center">
                <div className={`p-2 rounded-lg border shadow-lg transition-colors ${
                  selectedEntity?.id === donor.id 
                    ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400/50' 
                    : 'bg-slate-900 text-amber-400 border-amber-500/40 hover:border-amber-400'
                }`}>
                  <Building2 className="w-4 h-4" />
                </div>
                <span className="mt-1 px-1.5 py-0.5 rounded bg-slate-950/90 border border-slate-800 text-[10px] font-medium text-slate-300 whitespace-nowrap shadow-sm">
                  {donor.name.split(' ')[0]}
                </span>
              </div>
            </button>
          ))}

          {/* Node Renderers: Shelters */}
          {shelters.map(shelter => {
            const hasCleanWater = shelter.prerequisites.cleanWater;
            const unmetMeals = shelter.demandRemaining.cooked_meals;
            const isFilled = unmetMeals === 0;

            return (
              <button
                key={shelter.id}
                onClick={() => setSelectedEntity({ type: 'shelter', id: shelter.id })}
                style={{ left: `${shelter.x}%`, top: `${shelter.y}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group transition-transform ${
                  selectedEntity?.id === shelter.id ? 'scale-110' : 'hover:scale-105'
                }`}
              >
                <div className="flex flex-col items-center">
                  <div className={`p-2 rounded-lg border shadow-lg transition-colors relative ${
                    selectedEntity?.id === shelter.id 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-300 ring-2 ring-emerald-400/50' 
                      : isFilled
                        ? 'bg-slate-900 text-slate-400 border-slate-700'
                        : 'bg-slate-900 text-emerald-400 border-emerald-500/40 hover:border-emerald-400'
                  }`}>
                    <Home className="w-4 h-4" />
                    {!hasCleanWater && (
                      <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-slate-950" title="Missing clean water prerequisite!" />
                    )}
                  </div>
                  <div className="mt-1 flex flex-col items-center">
                    <span className="px-1.5 py-0.5 rounded bg-slate-950/90 border border-slate-800 text-[10px] font-medium text-slate-300 whitespace-nowrap shadow-sm">
                      {shelter.name.split(' ')[0]} {shelter.name.split(' ')[1] || ''}
                    </span>
                    <span className="text-[9px] font-mono text-slate-400 tabular-nums">
                      {isFilled ? 'Demand: 0 (Filled)' : `Need: ${unmetMeals} meals`}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}

          {/* Node Renderers: Riders in Motion */}
          {riders.map(rider => {
            const isUnresponsive = rider.status === 'unresponsive';
            const isStandby = rider.status === 'standby';
            const inTransit = rider.status === 'in_transit';
            const Icon = rider.vehicleType === 'van' ? Truck : Bike;

            return (
              <button
                key={rider.id}
                onClick={() => setSelectedEntity({ type: 'rider', id: rider.id })}
                style={{ left: `${rider.x}%`, top: `${rider.y}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 z-30 group transition-all duration-700 ease-out ${
                  selectedEntity?.id === rider.id ? 'scale-115' : 'hover:scale-105'
                }`}
              >
                <div className="flex flex-col items-center">
                  <div className={`p-1.5 rounded-full border shadow-lg transition-colors relative ${
                    selectedEntity?.id === rider.id 
                      ? 'bg-sky-400 text-slate-950 border-white ring-2 ring-sky-300' 
                      : isUnresponsive
                        ? 'bg-amber-950 text-amber-400 border-amber-500 animate-bounce'
                        : isStandby
                          ? 'bg-slate-900 text-slate-400 border-slate-700'
                          : 'bg-slate-900 text-sky-400 border-sky-500/50 hover:border-sky-400'
                  }`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div className="mt-0.5 px-1 rounded bg-slate-950/90 border border-slate-800 text-[9px] font-mono font-medium text-slate-300 whitespace-nowrap tabular-nums">
                    {rider.name.split(' ')[0]} {rider.currentCargoCount > 0 ? `(${rider.currentCargoCount})` : ''}
                  </div>
                </div>
              </button>
            );
          })}

        </div>

        {/* Bottom map summary ticker */}
        <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/60">
          <div className="flex items-center gap-3">
            <span>Dynamic Heartbeat Protocol Active</span>
            <span aria-hidden="true">·</span>
            <span>Ghost Hold SLA: 25s threshold</span>
            <span aria-hidden="true">·</span>
            <span>Reserve Failover Standby: 1 scooter ready</span>
          </div>
          <div className="text-slate-400 font-mono text-[11px]">
            Map Scale: 1 unit ≈ 150m · Real-time Urban Dispatch Matrix
          </div>
        </div>

      </div>

      {/* Inspector / Action Drawer (1 col) */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-xl">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Node Inspector
        </h3>

        {/* Selected Rider Details */}
        {selectedRider && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white tracking-tight">
                  {selectedRider.name}
                </h4>
                <span className={`text-[11px] font-mono ${
                  selectedRider.status === 'unresponsive' 
                    ? 'text-amber-400 font-bold' 
                    : selectedRider.status === 'in_transit' 
                      ? 'text-emerald-400' 
                      : 'text-slate-400'
                }`}>
                  {selectedRider.status.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Vehicle: {selectedRider.vehicleType.toUpperCase()} · Max: {selectedRider.maxCapacity} units
              </p>
            </div>

            {/* Heartbeat Status Meter */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-400">Heartbeat Ping SLA</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {selectedRider.lastHeartbeatSecondsAgo}s / {selectedRider.heartbeatThresholdSeconds}s max
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${
                    selectedRider.lastHeartbeatSecondsAgo > selectedRider.heartbeatThresholdSeconds * 0.8
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{
                    width: `${Math.min(100, (selectedRider.lastHeartbeatSecondsAgo / selectedRider.heartbeatThresholdSeconds) * 100)}%`
                  }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1.5">
                <span>Reliability Rating</span>
                <span className="font-mono text-emerald-400">{selectedRider.reliabilityScore}%</span>
              </div>
            </div>

            {/* Cargo status */}
            <div className="space-y-1 text-xs text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-400">Current Payload:</span>
                <span className="font-mono font-medium">{selectedRider.currentCargoCount} units</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Target Waypoint:</span>
                <span className="font-medium text-right truncate max-w-[150px]">
                  {selectedRider.assignedShelterId 
                    ? shelters.find(s => s.id === selectedRider.assignedShelterId)?.name 
                    : 'None assigned'}
                </span>
              </div>
            </div>

            {/* Rider Quick Action Buttons */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <button
                onClick={() => sendRiderHeartbeat(selectedRider.id)}
                className="w-full py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Simulate GPS Heartbeat Ping</span>
              </button>

              {selectedRider.status !== 'unresponsive' && (
                <button
                  onClick={() => triggerGhostRiderStall(selectedRider.id)}
                  className="w-full py-1.5 px-3 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-800/60 text-amber-300 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-2"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Simulate Rider Ghost Stall</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Selected Shelter Details */}
        {selectedShelter && (
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-bold text-white tracking-tight">
                {selectedShelter.name}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {selectedShelter.address}
              </p>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Capacity & Occupancy:</span>
                <span className="font-mono tabular-nums text-slate-200">
                  {selectedShelter.currentOccupants} / {selectedShelter.capacityMax}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Cooked Meals Need:</span>
                <span className={`font-mono tabular-nums font-bold ${
                  selectedShelter.demandRemaining.cooked_meals === 0 
                    ? 'text-slate-400' 
                    : 'text-emerald-400'
                }`}>
                  {selectedShelter.demandRemaining.cooked_meals} meals
                </span>
              </div>
            </div>

            {/* Prerequisite status checklist */}
            <div>
              <h5 className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Ground Prerequisites & Safety
              </h5>
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-3.5 h-3.5 text-sky-400" />
                    <span>Clean Potable Water</span>
                  </div>
                  {selectedShelter.prerequisites.cleanWater ? (
                    <span className="text-emerald-400 text-[11px] font-mono">VERIFIED</span>
                  ) : (
                    <button
                      onClick={() => resolvePrerequisite(selectedShelter.id, 'cleanWater')}
                      className="px-2 py-0.5 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded text-[10px] hover:bg-rose-500/30"
                    >
                      Missing · Click to Clear
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>Cooking Fuel / Gas</span>
                  </div>
                  {selectedShelter.prerequisites.cookingFuel ? (
                    <span className="text-emerald-400 text-[11px] font-mono">VERIFIED</span>
                  ) : (
                    <button
                      onClick={() => resolvePrerequisite(selectedShelter.id, 'cookingFuel')}
                      className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded text-[10px] hover:bg-amber-500/30"
                    >
                      Missing · Click to Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Shelter Action */}
            <div className="pt-2 border-t border-slate-800">
              <button
                onClick={() => triggerMidTransitShelterClosure(selectedShelter.id, 50)}
                className="w-full py-1.5 px-3 bg-sky-950/40 hover:bg-sky-900/60 border border-sky-800/60 text-sky-300 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-2"
                title="Simulate local citizen walking into this shelter with 50 meals, dropping its demand to 0 and triggering mid-journey dynamic reroute!"
              >
                <MapPin className="w-3.5 h-3.5 text-sky-400" />
                <span>Simulate Citizen Walk-In Dropoff</span>
              </button>
            </div>
          </div>
        )}

        {/* Selected Donor Details */}
        {selectedDonor && (
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-bold text-white tracking-tight">
                {selectedDonor.name}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {selectedDonor.address}
              </p>
            </div>
            <div className="text-xs text-slate-300 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Donor Type:</span>
                <span className="font-medium capitalize">{selectedDonor.type.replace('_', ' ')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Contact:</span>
                <span>{selectedDonor.contactPerson} ({selectedDonor.phone})</span>
              </div>
            </div>
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-300">
              Active Surplus Batches: {batches.filter(b => b.donorId === selectedDonor.id).length}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
