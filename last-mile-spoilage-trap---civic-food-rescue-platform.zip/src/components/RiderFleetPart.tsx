import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Bike, 
  Truck, 
  Radio, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  Phone, 
  Navigation,
  Clock,
  Sparkles,
  UserCheck
} from 'lucide-react';

export const RiderFleetPart: React.FC = () => {
  const { 
    riders, 
    batches, 
    shelters, 
    sendRiderHeartbeat, 
    triggerGhostRiderStall,
    manualReassignSubBatch,
    completeDelivery
  } = useSimulation();

  const [filterStatus, setFilterStatus] = useState<string>('all');
  const allSubBatches = batches.flatMap(b => b.subBatches.map(sb => ({ ...sb, parentBatch: b })));

  const filteredRiders = riders.filter(r => {
    if (filterStatus === 'all') return true;
    if (filterStatus === 'active') return r.status === 'in_transit' || r.status === 'claimed';
    if (filterStatus === 'unresponsive') return r.status === 'unresponsive';
    if (filterStatus === 'standby') return r.status === 'standby' || r.status === 'available';
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Editorial Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-gradient-to-r from-sky-50 to-blue-50 rounded-2xl border border-sky-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-sky-700 font-bold bg-sky-100/80 px-2.5 py-0.5 rounded-full border border-sky-300">
              Part 2 of 3 · Volunteer Couriers
            </span>
            <span className="text-xs text-sky-800">Two-Wheeler Urban Dispatch</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 mt-1">
            Volunteer Rider Fleet & Live Heartbeat SLA
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Active couriers carrying ticking perishable aid. Continuous heartbeat pings eliminate ghost claims.
          </p>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-sky-200 shadow-xs">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filterStatus === 'all' 
                ? 'bg-sky-500 text-white shadow-xs' 
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Riders ({riders.length})
          </button>
          <button
            onClick={() => setFilterStatus('active')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filterStatus === 'active' 
                ? 'bg-sky-500 text-white shadow-xs' 
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Active ({riders.filter(r => r.status === 'in_transit' || r.status === 'claimed').length})
          </button>
          <button
            onClick={() => setFilterStatus('unresponsive')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filterStatus === 'unresponsive' 
                ? 'bg-amber-500 text-white shadow-xs' 
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Ghost Stalled ({riders.filter(r => r.status === 'unresponsive').length})
          </button>
          <button
            onClick={() => setFilterStatus('standby')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              filterStatus === 'standby' 
                ? 'bg-sky-500 text-white shadow-xs' 
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Standby ({riders.filter(r => r.status === 'standby' || r.status === 'available').length})
          </button>
        </div>
      </div>

      {/* Couriers Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredRiders.map(rider => {
          const isGhost = rider.status === 'unresponsive';
          const isStandby = rider.status === 'standby';
          const activeSubBatch = allSubBatches.find(sb => sb.id === rider.activeSubBatchId);
          const targetShelter = shelters.find(s => s.id === activeSubBatch?.targetShelterId);
          const Icon = rider.vehicleType === 'van' ? Truck : Bike;

          return (
            <div
              key={rider.id}
              className={`p-5 rounded-2xl border shadow-sm transition-all space-y-4 ${
                isGhost
                  ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-300'
                  : rider.status === 'in_transit'
                    ? 'bg-white border-sky-300 ring-1 ring-sky-200'
                    : 'bg-white border-slate-200/90'
              }`}
            >
              
              {/* Card Header: Rider Profile */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center border shadow-xs ${
                    isGhost 
                      ? 'bg-amber-100 text-amber-700 border-amber-300' 
                      : isStandby
                        ? 'bg-slate-100 text-slate-600 border-slate-200'
                        : 'bg-sky-50 text-sky-600 border-sky-200'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                      {rider.name}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                      <span className="capitalize">{rider.vehicleType}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono font-medium">Cap: {rider.maxCapacity} units</span>
                    </div>
                  </div>
                </div>

                {/* Status indicator */}
                <div className="text-right">
                  <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                    isGhost 
                      ? 'bg-amber-200/80 text-amber-900 border-amber-300' 
                      : rider.status === 'in_transit'
                        ? 'bg-sky-100 text-sky-800 border-sky-300'
                        : isStandby
                          ? 'bg-slate-100 text-slate-700 border-slate-200'
                          : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  }`}>
                    {rider.status.toUpperCase()}
                  </span>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    ★ {rider.reliabilityScore}% reliability
                  </div>
                </div>
              </div>

              {/* Heartbeat SLA Countdown Bar */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Radio className={`w-3.5 h-3.5 ${isGhost ? 'text-amber-500 animate-bounce' : 'text-emerald-500 animate-pulse'}`} />
                    Last GPS Ping:
                  </span>
                  <span className="font-mono font-bold text-slate-800 tabular-nums">
                    {rider.lastHeartbeatSecondsAgo}s ago / {rider.heartbeatThresholdSeconds}s max
                  </span>
                </div>

                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-300 ${
                      isGhost 
                        ? 'bg-amber-500' 
                        : rider.lastHeartbeatSecondsAgo > 18 
                          ? 'bg-amber-400' 
                          : 'bg-emerald-500'
                    }`}
                    style={{
                      width: `${Math.min(100, (rider.lastHeartbeatSecondsAgo / rider.heartbeatThresholdSeconds) * 100)}%`
                    }}
                  />
                </div>
              </div>

              {/* Active Cargo Mission / Target */}
              {activeSubBatch ? (
                <div className="space-y-1 text-xs text-slate-700 pt-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Current Payload:</span>
                    <strong className="font-mono text-rose-600">{activeSubBatch.quantity} meals</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Destination:</span>
                    <span className="font-semibold truncate max-w-[170px] text-slate-900">
                      {targetShelter?.name || 'Pending Route'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Safe Window Remaining:</span>
                    <span className="font-mono text-amber-700 font-semibold tabular-nums">
                      {Math.round(activeSubBatch.parentBatch.remainingSafeMinutes)} mins
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-400 italic py-1">
                  No active cargo assigned · Stationed on standby
                </div>
              )}

              {/* Courier Actions */}
              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <button
                  onClick={() => sendRiderHeartbeat(rider.id)}
                  className="flex-1 py-1.5 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Radio className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Ping GPS</span>
                </button>

                {!isGhost && rider.status !== 'standby' && (
                  <button
                    onClick={() => triggerGhostRiderStall(rider.id)}
                    className="py-1.5 px-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 text-xs font-semibold rounded-xl transition-colors"
                    title="Simulate courier stalled in traffic to test SLA auto-revocation"
                  >
                    Simulate Ghost Stall
                  </button>
                )}

                {activeSubBatch && activeSubBatch.status === 'in_transit' && (
                  <button
                    onClick={() => completeDelivery(activeSubBatch.id)}
                    className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs"
                  >
                    Handover
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
