import React, { useState } from 'react';
import { DonorPortalPart } from './DonorPortalPart';
import { RiderFleetPart } from './RiderFleetPart';
import { ShelterDepotPart } from './ShelterDepotPart';
import { Building2, Bike, Home, LayoutGrid } from 'lucide-react';

interface TriPortalHubProps {
  onOpenNewBatchModal: () => void;
}

export const TriPortalHub: React.FC<TriPortalHubProps> = ({ onOpenNewBatchModal }) => {
  const [activeSection, setActiveSection] = useState<'all' | 'donors' | 'riders' | 'shelters'>('all');

  return (
    <div className="space-y-6">
      
      {/* 3-Part Navigation Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            3-Pillar Civic Micro-Logistics Network
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Synchronizing food surplus donors, volunteer riders, and receiving shelters in real-time.
          </p>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-50 rounded-xl border border-slate-200">
          <button
            onClick={() => setActiveSection('all')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeSection === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Unified 3-Part Grid</span>
          </button>

          <button
            onClick={() => setActiveSection('donors')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeSection === 'donors'
                ? 'bg-amber-100/80 text-amber-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-amber-600" />
            <span>1. Donors</span>
          </button>

          <button
            onClick={() => setActiveSection('riders')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeSection === 'riders'
                ? 'bg-sky-100/80 text-sky-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bike className="w-3.5 h-3.5 text-sky-600" />
            <span>2. Riders</span>
          </button>

          <button
            onClick={() => setActiveSection('shelters')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              activeSection === 'shelters'
                ? 'bg-emerald-100/80 text-emerald-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Home className="w-3.5 h-3.5 text-emerald-600" />
            <span>3. Shelters</span>
          </button>
        </div>
      </div>

      {/* Content based on selection */}
      {activeSection === 'all' && (
        <div className="space-y-12">
          <section id="section_donors" className="scroll-mt-20">
            <DonorPortalPart onOpenNewBatchModal={onOpenNewBatchModal} />
          </section>

          <div className="h-px bg-slate-200" />

          <section id="section_riders" className="scroll-mt-20">
            <RiderFleetPart />
          </section>

          <div className="h-px bg-slate-200" />

          <section id="section_shelters" className="scroll-mt-20">
            <ShelterDepotPart />
          </section>
        </div>
      )}

      {activeSection === 'donors' && (
        <DonorPortalPart onOpenNewBatchModal={onOpenNewBatchModal} />
      )}

      {activeSection === 'riders' && (
        <RiderFleetPart />
      )}

      {activeSection === 'shelters' && (
        <ShelterDepotPart />
      )}

    </div>
  );
};
