import React from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  X, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  Users, 
  MapPin, 
  ShieldAlert, 
  RotateCcw,
  Clock,
  ArrowRight
} from 'lucide-react';

interface JudgeSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const JudgeSimulatorModal: React.FC<JudgeSimulatorModalProps> = ({ isOpen, onClose }) => {
  const { 
    triggerGhostRiderStall, 
    triggerMidTransitShelterClosure, 
    triggerBulkSurgePartition, 
    triggerDependencyDispatchTest,
    resetToInitial,
    activeScenarioId
  } = useSimulation();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-6">
        
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-500 shadow-xs">
                <Zap className="w-4 h-4 fill-rose-500" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 tracking-tight">
                Judge Failure Simulation Testbed
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Verify platform resilience against real-world operational breakdowns defined in the Problem Statement.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Test Scenarios */}
        <div className="space-y-4">
          
          {/* Scenario 1: Bulk Expiry Rush */}
          <div className={`p-4 rounded-2xl border transition-all ${
            activeScenarioId === 'bulk_surge_partition'
              ? 'bg-emerald-50 border-emerald-300 ring-2 ring-emerald-200'
              : 'bg-slate-50/70 border-slate-200'
          }`}>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-800 font-bold block">
                  Failure Scenario #1 · Page 1, §Bulk Supply Dilemma
                </span>
                <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                  Bulk Supply vs. Single-Point Capacity Mismatch
                </h4>
              </div>
              <button
                onClick={() => triggerBulkSurgePartition(180, 65)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all shadow-xs active:scale-95"
              >
                Inject Bulk Surge (180 Meals)
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>Ground Dilemma:</strong> A banquet hall prepares 180 hot meals spoiling in 75 mins. A volunteer rider's scooter can only hold 40, and Shelter A can only accept 50.
            </p>
            <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500 font-mono">
              <span>Expected: Auto-partition into 4 vehicle units across 3 shelters</span>
              <span className="text-emerald-700 font-bold">0% Spoilage Invariant</span>
            </div>
          </div>

          {/* Scenario 2: Ghost Volunteer Stall */}
          <div className={`p-4 rounded-2xl border transition-all ${
            activeScenarioId === 'ghost_rider_stall'
              ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-200'
              : 'bg-slate-50/70 border-slate-200'
          }`}>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-amber-800 font-bold block">
                  Failure Scenario #2 · Page 1, §Ghost Claims & Stalls
                </span>
                <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                  Unresponsive Volunteer & Ghost Reservation Revocation
                </h4>
              </div>
              <button
                onClick={() => triggerGhostRiderStall('rider_ravi')}
                className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-xs active:scale-95"
              >
                Simulate Ghost Volunteer Stall
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>Ground Dilemma:</strong> Volunteer Ravi claims 40 hot meals to reserve them, then gets stuck in traffic or goes unresponsive for 30 minutes, burning up safe shelf-life.
            </p>
            <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500 font-mono">
              <span>Expected: Heartbeat SLA decays → Auto-revokes claim → Handed to Standby Maya</span>
              <span className="text-amber-800 font-bold">SLA Auto-Failover</span>
            </div>
          </div>

          {/* Scenario 3: Mid-Transit Sudden Shelter Closure */}
          <div className={`p-4 rounded-2xl border transition-all ${
            activeScenarioId === 'shelter_closure_midtransit'
              ? 'bg-sky-50 border-sky-300 ring-2 ring-sky-200'
              : 'bg-slate-50/70 border-slate-200'
          }`}>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-sky-800 font-bold block">
                  Failure Scenario #3 · Page 1, §Mid-Journey Ground Mutation
                </span>
                <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                  Mid-Journey Destination Cancellation & Dynamic Rerouting
                </h4>
              </div>
              <button
                onClick={() => triggerMidTransitShelterClosure('shelter_alpha', 50)}
                className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl transition-all shadow-xs active:scale-95"
              >
                Trigger Walk-in Dropoff Reroute
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>Ground Dilemma:</strong> While Rider Alex is halfway carrying 45 meals to Shelter Alpha, a walk-in citizen drops off food at the gate, filling demand completely. Alex has ticking cargo and no recipient!
            </p>
            <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500 font-mono">
              <span>Expected: In-transit collision detected → Dynamically reroutes Alex to Shelter Echo</span>
              <span className="text-sky-800 font-bold">Safe Window Intact</span>
            </div>
          </div>

          {/* Scenario 4: Prerequisite Dependency Violation */}
          <div className={`p-4 rounded-2xl border transition-all ${
            activeScenarioId === 'dependency_safety_trap'
              ? 'bg-rose-50 border-rose-300 ring-2 ring-rose-200'
              : 'bg-slate-50/70 border-slate-200'
          }`}>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-rose-800 font-bold block">
                  Failure Scenario #4 · Page 1, §Strict Dependency Rules
                </span>
                <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                  Biochemical Prerequisite & Contamination Lockout
                </h4>
              </div>
              <button
                onClick={() => triggerDependencyDispatchTest('shelter_charlie')}
                className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-all shadow-xs active:scale-95"
              >
                Test Prerequisite Trap
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>Ground Dilemma:</strong> Dispatching powdered infant formula or raw ration kits to flood camp Charlie when clean potable water is unavailable risks fatal infantile diarrhea.
            </p>
            <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500 font-mono">
              <span>Expected: Hard dispatch halt until water purification units are certified</span>
              <span className="text-rose-800 font-bold">Safety Invariant Guard</span>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={resetToInitial}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors font-medium"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All Scenarios</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs"
          >
            Close Simulator
          </button>
        </div>

      </div>
    </div>
  );
};
