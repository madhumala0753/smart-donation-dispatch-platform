import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Smartphone, 
  Bike, 
  MapPin, 
  Navigation, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  PhoneCall, 
  Radio, 
  RefreshCw,
  Sparkles
} from 'lucide-react';

export const RiderAppView: React.FC = () => {
  const { 
    riders, 
    batches, 
    shelters, 
    sendRiderHeartbeat, 
    completeDelivery,
    triggerGhostRiderStall,
    triggerMidTransitShelterClosure
  } = useSimulation();

  const [selectedRiderId, setSelectedRiderId] = useState<string>('rider_alex');

  const currentRider = riders.find(r => r.id === selectedRiderId) || riders[0];
  const allSubBatches = batches.flatMap(b => b.subBatches.map(sb => ({ ...sb, parentBatch: b })));
  const activeSubBatch = allSubBatches.find(sb => sb.id === currentRider.activeSubBatchId);
  const targetShelter = shelters.find(s => s.id === activeSubBatch?.targetShelterId);
  const originalShelter = shelters.find(s => s.id === activeSubBatch?.originalShelterId);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      
      {/* Left Column: Context & Rider Selector (5 cols) */}
      <div className="lg:col-span-5 space-y-6">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">
            Volunteer Rider Field Applet
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Human Unreliability & Mid-Journey Adaptability</span>
            <span aria-hidden="true">·</span>
            <span>Live Field Simulation</span>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          The problem statement emphasizes that volunteer two-wheeler riders are vulnerable to traffic stalls, battery loss, or unexpected destination cancellations. ReliefMesh continuously maintains a lightweight heartbeat handshake with the rider's phone and automatically transmits dynamic fallback waypoints if ground conditions mutate.
        </p>

        {/* Rider Switcher */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Select Volunteer Device to Inspect:
          </label>
          <div className="space-y-2">
            {riders.map(r => (
              <button
                key={r.id}
                onClick={() => setSelectedRiderId(r.id)}
                className={`w-full p-3 rounded-lg border text-left text-xs transition-all flex items-center justify-between ${
                  selectedRiderId === r.id
                    ? 'bg-emerald-500/10 border-emerald-500/60 text-white'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {r.vehicleType.toUpperCase()} · Cargo: {r.currentCargoCount} units · Score: {r.reliabilityScore}%
                  </div>
                </div>

                <div className="text-right font-mono text-[11px]">
                  <span className={r.status === 'unresponsive' ? 'text-amber-400 font-bold' : 'text-slate-400'}>
                    {r.status.toUpperCase()}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Simulator Tests for this Rider */}
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Field Stress Testing Controls:
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => triggerGhostRiderStall(currentRider.id)}
              className="p-2.5 bg-amber-950/30 hover:bg-amber-900/50 border border-amber-800/60 text-amber-300 rounded-lg font-medium transition-colors text-center"
            >
              Simulate Stalled / Lost Signal
            </button>
            <button
              onClick={() => triggerMidTransitShelterClosure('shelter_alpha', 50)}
              className="p-2.5 bg-sky-950/30 hover:bg-sky-900/50 border border-sky-800/60 text-sky-300 rounded-lg font-medium transition-colors text-center"
            >
              Trigger Mid-Transit Reroute
            </button>
          </div>
        </div>

      </div>

      {/* Right Column: Mobile Device Simulation (7 cols) */}
      <div className="lg:col-span-7 flex justify-center">
        
        {/* Mobile Mockup Shell */}
        <div className="w-full max-w-sm bg-slate-950 rounded-[2.5rem] border-4 border-slate-800 p-4 shadow-2xl relative overflow-hidden">
          
          {/* Top Speaker Notch */}
          <div className="w-28 h-4 bg-slate-800 rounded-full mx-auto mb-4 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900" />
          </div>

          {/* App Header Inside Phone */}
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-white">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>ReliefMesh Rider</span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
              <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
              <span>LIVE GPS</span>
            </div>
          </div>

          {/* Dynamic Reroute Push Alert Banner */}
          {activeSubBatch?.rerouted && (
            <div className="mb-3 p-3 bg-sky-950 border border-sky-500 rounded-xl text-xs space-y-1.5 shadow-lg animate-pulse">
              <div className="flex items-center gap-1.5 text-sky-300 font-bold">
                <Navigation className="w-4 h-4 text-sky-400" />
                <span>DYNAMIC ROUTE UPDATE</span>
              </div>
              <p className="text-[11px] text-sky-200 leading-snug">
                Destination <strong>Shelter Alpha</strong> filled by on-ground citizen donor. Re-routed to <strong>Shelter Echo</strong> (Safe shelf-life window preserved!).
              </p>
            </div>
          )}

          {/* Ghost Stall Inactive Alert */}
          {currentRider.status === 'unresponsive' && (
            <div className="mb-3 p-3 bg-amber-950 border border-amber-500 rounded-xl text-xs space-y-1.5 shadow-lg">
              <div className="flex items-center gap-1.5 text-amber-300 font-bold">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>SLA BREACH: UNRESPONSIVE</span>
              </div>
              <p className="text-[11px] text-amber-200 leading-snug">
                No GPS ping for {currentRider.lastHeartbeatSecondsAgo}s. Standby failover is transferring reservation to prevent spoilage. Tap Heartbeat to resume!
              </p>
            </div>
          )}

          {/* Active Cargo Mission Card */}
          {activeSubBatch ? (
            <div className="space-y-4">
              
              {/* Perishable Countdown Clock */}
              <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                    Cargo Safe Shelf-Life
                  </span>
                  <div className="text-lg font-mono font-bold text-white tabular-nums flex items-center gap-1.5 mt-0.5">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>{Math.round(activeSubBatch.parentBatch.remainingSafeMinutes)} min left</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Payload</span>
                  <span className="text-sm font-bold text-emerald-400 font-mono">
                    {activeSubBatch.quantity} Meals
                  </span>
                </div>
              </div>

              {/* Waypoint Route Details */}
              <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 space-y-3 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                    Pickup Location
                  </span>
                  <div className="flex items-center gap-2 text-white font-medium">
                    <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{activeSubBatch.parentBatch.donorName}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block mb-1">
                    Delivery Destination
                  </span>
                  <div className="flex items-center gap-2 text-white font-medium">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className={activeSubBatch.rerouted ? 'text-sky-300 font-bold' : ''}>
                      {targetShelter?.name}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 pl-5">
                    {targetShelter?.address}
                  </div>
                </div>

                {/* Progress ETA */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between font-mono text-[11px]">
                  <span className="text-slate-400">Transit Progress</span>
                  <span className="text-emerald-400 font-bold">{Math.round(activeSubBatch.progressPercent)}%</span>
                </div>
              </div>

              {/* Heartbeat Check-In Button (Variable #3 solution) */}
              <button
                onClick={() => sendRiderHeartbeat(currentRider.id)}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition-all border border-slate-700 flex items-center justify-center gap-2 active:scale-95 shadow-md"
              >
                <Radio className="w-3.5 h-3.5 text-emerald-400" />
                <span>Send GPS Heartbeat ({currentRider.lastHeartbeatSecondsAgo}s ago)</span>
              </button>

              {/* Delivery Complete Button */}
              {activeSubBatch.status === 'in_transit' && (
                <button
                  onClick={() => completeDelivery(activeSubBatch.id)}
                  className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg shadow-emerald-500/20"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Verify Shelter Handover</span>
                </button>
              )}

            </div>
          ) : (
            <div className="py-12 px-4 text-center space-y-3">
              <Bike className="w-8 h-8 text-slate-600 mx-auto" />
              <h4 className="text-sm font-semibold text-white">Standby for Next Dispatch</h4>
              <p className="text-xs text-slate-400">
                You are currently stationed in Zone 4. New perishable surplus requests will pop up automatically.
              </p>
            </div>
          )}

          {/* Bottom Home Indicator */}
          <div className="w-32 h-1 bg-slate-800 rounded-full mx-auto mt-6" />

        </div>

      </div>

    </div>
  );
};
