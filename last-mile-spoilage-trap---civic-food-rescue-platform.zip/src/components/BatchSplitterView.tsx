import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Split, 
  Clock, 
  Bike, 
  Truck, 
  Home, 
  Building2, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  Sparkles,
  Zap
} from 'lucide-react';
import { AidItemType } from '../types';

export const BatchSplitterView: React.FC = () => {
  const { batches, riders, shelters, donors, triggerBulkSurgePartition } = useSimulation();

  // Interactive Sandbox inputs
  const [sandboxQuantity, setSandboxQuantity] = useState<number>(180);
  const [sandboxItemType, setSandboxItemType] = useState<AidItemType>('cooked_meals');
  const [sandboxShelfLife, setSandboxShelfLife] = useState<number>(75);
  const [sandboxScooterCount, setSandboxScooterCount] = useState<number>(3);
  const [sandboxVanCount, setSandboxVanCount] = useState<number>(1);

  // Compute live partition preview for sandbox
  const scooterCapacity = 45;
  const vanCapacity = 100;
  const totalFleetCapacity = (sandboxScooterCount * scooterCapacity) + (sandboxVanCount * vanCapacity);
  const isSufficientCapacity = totalFleetCapacity >= sandboxQuantity;

  const handleRunPartition = () => {
    triggerBulkSurgePartition(sandboxQuantity, sandboxShelfLife);
  };

  return (
    <div className="space-y-8">
      
      {/* Editorial Header */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-white">
          Bulk Supply vs. Micro-Transport Partitioning Engine
        </h2>
        <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
          <span>Active Variable #2: Transport Capacity & Multi-Shelter Balancing</span>
          <span aria-hidden="true">·</span>
          <span>Automatic Lot Decomposition</span>
          <span aria-hidden="true">·</span>
          <span>Zero-Waste Allocation</span>
        </div>
      </div>

      {/* Ground Dilemma Comparison Card */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow-xl">
        <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4">
          Problem Statement Baseline vs. ReliefMesh Coordination
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* The Status Quo Failure Mode */}
          <div className="p-5 rounded-lg bg-rose-950/20 border border-rose-900/50">
            <div className="flex items-center gap-2 text-rose-400 font-semibold text-sm mb-2">
              <AlertCircle className="w-4 h-4" />
              <span>Uncoordinated Status Quo (40% Spoilage)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Banquet hall generates <strong className="text-white">180 cooked meals</strong> spoiling in 75 minutes. A single volunteer arrives on a scooter with capacity for only 40 meals. Nearby Shelter A can only accept 50. 
              The remaining <strong className="text-rose-300">130 meals sit abandoned at the gate</strong> until they pass safe thermal thresholds and get discarded.
            </p>
            <div className="mt-4 pt-3 border-t border-rose-900/40 flex items-center justify-between text-xs text-rose-300 font-mono">
              <span>Rider Deficit: -140 capacity</span>
              <span>Waste Outcome: 72% Lost</span>
            </div>
          </div>

          {/* ReliefMesh Algorithmic Solution */}
          <div className="p-5 rounded-lg bg-emerald-950/20 border border-emerald-900/50">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm mb-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>ReliefMesh Multi-Rider Decomposition (0% Spoilage)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              System instantly parses the 180 bulk lot into <strong className="text-white">4 synchronized micro-dispatches</strong>. Dispatches 3 scooters (40-45 units each) and 1 van (50 units), routing them across Shelter Alpha (50 needed), Shelter Bravo (70 needed), and Shelter Echo (60 needed).
            </p>
            <div className="mt-4 pt-3 border-t border-emerald-900/40 flex items-center justify-between text-xs text-emerald-300 font-mono">
              <span>Parallel Dispatch: 4 Couriers</span>
              <span>Redistribution: 100% Absorbed</span>
            </div>
          </div>

        </div>
      </div>

      {/* Active Partitioned Batches in the System */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
          Currently Partitioned Batches
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {batches.map(batch => (
            <div 
              key={batch.id} 
              className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-lg space-y-4"
            >
              {/* Batch Master Info */}
              <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-amber-400" />
                    <h4 className="text-base font-bold text-white tracking-tight">
                      {batch.title}
                    </h4>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                    <span>{batch.donorName}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-white font-semibold tabular-nums">{batch.totalQuantity} {batch.unit}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-amber-400 font-mono tabular-nums">
                      {Math.round(batch.remainingSafeMinutes)}m shelf-life remaining
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs text-slate-400">
                    Decomposed into <strong className="text-white font-mono">{batch.subBatches.length}</strong> parallel legs
                  </span>
                </div>
              </div>

              {/* Sub-batches breakdown list */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {batch.subBatches.map((sb, idx) => {
                  const targetShelter = shelters.find(s => s.id === sb.targetShelterId);
                  const rider = riders.find(r => r.id === sb.riderId);

                  return (
                    <div 
                      key={sb.id} 
                      className={`p-3.5 rounded-lg border text-xs space-y-2 transition-all ${
                        sb.rerouted 
                          ? 'bg-sky-950/30 border-sky-500/40' 
                          : sb.status === 'delivered' 
                            ? 'bg-slate-950/60 border-slate-800 opacity-75' 
                            : 'bg-slate-950 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center justify-between font-mono text-[11px]">
                        <span className="text-slate-400">Leg #{idx + 1}</span>
                        <span className="text-emerald-400 font-bold">{sb.quantity} {batch.unit}</span>
                      </div>

                      {/* Courier assigned */}
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <Bike className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                        <span className="truncate">
                          {rider ? rider.name.split(' ')[0] : 'Auto-matching courier...'}
                        </span>
                      </div>

                      {/* Destination Shelter */}
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <Home className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate font-medium">
                          {targetShelter ? targetShelter.name.split(' ')[0] : 'Searching...'}
                        </span>
                      </div>

                      {/* Status / ETA */}
                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
                        <span className={sb.rerouted ? 'text-sky-300' : 'text-slate-400'}>
                          {sb.rerouted ? 'REROUTED' : sb.status.toUpperCase()}
                        </span>
                        <span className="text-slate-300 tabular-nums">
                          ETA {sb.deliveryEtaMinutes}m
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          ))}
        </div>
      </div>

      {/* Interactive Batch Partitioning Simulator for Judges */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 shadow-xl space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Dynamic Batch Partitioning Sandbox
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Input custom surplus lots to verify how the algorithm slices bulk volumes and binds them to vehicle constraints.
            </p>
          </div>

          <button
            onClick={handleRunPartition}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs rounded-lg transition-all shadow-md active:scale-95 whitespace-nowrap"
          >
            <Split className="w-3.5 h-3.5" />
            <span>Generate & Dispatch Partition</span>
          </button>
        </div>

        {/* Form controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Surplus Volume (Portions/Kits)
            </label>
            <input
              type="number"
              min="20"
              max="500"
              step="10"
              value={sandboxQuantity}
              onChange={e => setSandboxQuantity(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white font-mono tabular-nums focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Perishable Shelf-Life Window
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="30"
                max="180"
                step="5"
                value={sandboxShelfLife}
                onChange={e => setSandboxShelfLife(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white font-mono tabular-nums focus:outline-none focus:border-emerald-500"
              />
              <span className="text-xs text-slate-400">min</span>
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Available 2-Wheelers (45 Cap)
            </label>
            <input
              type="number"
              min="1"
              max="10"
              value={sandboxScooterCount}
              onChange={e => setSandboxScooterCount(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white font-mono tabular-nums focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Available Vans (100 Cap)
            </label>
            <input
              type="number"
              min="0"
              max="5"
              value={sandboxVanCount}
              onChange={e => setSandboxVanCount(Number(e.target.value))}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white font-mono tabular-nums focus:outline-none focus:border-emerald-500"
            />
          </div>

        </div>

        {/* Mathematical Verification Strip */}
        <div className="p-4 bg-slate-950 rounded-lg border border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4 text-slate-300">
            <span>Required Transport: <strong className="font-mono text-white">{sandboxQuantity} units</strong></span>
            <span aria-hidden="true">·</span>
            <span>Assembled Capacity: <strong className="font-mono text-white">{totalFleetCapacity} units</strong></span>
            <span aria-hidden="true">·</span>
            <span>Calculated Partition Legs: <strong className="font-mono text-emerald-400">{Math.ceil(sandboxQuantity / scooterCapacity)} couriers</strong></span>
          </div>

          <div className="font-mono text-[11px] text-emerald-400">
            {isSufficientCapacity ? '✓ Viable: Fleet Absorbs Full Bulk Batch' : '⚠ Fleet deficit: Standby vehicles required'}
          </div>
        </div>

      </div>

    </div>
  );
};
