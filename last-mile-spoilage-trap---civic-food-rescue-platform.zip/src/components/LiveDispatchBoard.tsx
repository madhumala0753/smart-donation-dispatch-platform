import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { 
  Clock, 
  Bike, 
  Home, 
  AlertTriangle, 
  CheckCircle2, 
  RotateCcw, 
  Navigation, 
  ShieldAlert, 
  UserCheck, 
  ArrowUpRight,
  Sparkles
} from 'lucide-react';
import { SubBatch, RiderNode, ShelterNode } from '../types';

export const LiveDispatchBoard: React.FC = () => {
  const { 
    batches, 
    riders, 
    shelters, 
    sendRiderHeartbeat, 
    triggerGhostRiderStall, 
    manualReassignSubBatch,
    manualRerouteSubBatch,
    completeDelivery
  } = useSimulation();

  const [filterType, setFilterType] = useState<'all' | 'in_transit' | 'claimed' | 'delivered'>('all');
  const [selectedSubBatchForReassign, setSelectedSubBatchForReassign] = useState<string | null>(null);

  // Flatten all sub-batches
  const allSubBatches = batches.flatMap(batch => 
    batch.subBatches.map(sb => ({
      ...sb,
      parentBatch: batch
    }))
  );

  const filteredSubBatches = allSubBatches.filter(sb => {
    if (filterType === 'all') return true;
    return sb.status === filterType;
  });

  const standbyRiders = riders.filter(r => r.status === 'standby' || r.status === 'available');

  return (
    <div className="space-y-6">
      
      {/* Editorial Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-white">
            Live Dispatch & Spoilage Prevention Board
          </h2>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Active Variable #1: Real-time Shelf-Life Decay</span>
            <span aria-hidden="true">·</span>
            <span>Active Variable #3: Ghost Reservation Auto-Recovery</span>
            <span aria-hidden="true">·</span>
            <span>Active Variable #4: Dynamic Rerouting Engine</span>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-slate-800">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              filterType === 'all' 
                ? 'bg-slate-800 text-white' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Sub-Batches ({allSubBatches.length})
          </button>
          <button
            onClick={() => setFilterType('in_transit')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              filterType === 'in_transit' 
                ? 'bg-slate-800 text-emerald-400' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            In Transit ({allSubBatches.filter(s => s.status === 'in_transit').length})
          </button>
          <button
            onClick={() => setFilterType('claimed')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              filterType === 'claimed' 
                ? 'bg-slate-800 text-amber-400' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Claimed / Pending Pickup ({allSubBatches.filter(s => s.status === 'claimed').length})
          </button>
          <button
            onClick={() => setFilterType('delivered')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              filterType === 'delivered' 
                ? 'bg-slate-800 text-sky-400' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Delivered ({allSubBatches.filter(s => s.status === 'delivered').length})
          </button>
        </div>
      </div>

      {/* Grid of Active Dispatches */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredSubBatches.map(sb => {
          const rider = riders.find(r => r.id === sb.riderId);
          const targetShelter = shelters.find(s => s.id === sb.targetShelterId);
          const originalShelter = sb.originalShelterId ? shelters.find(s => s.id === sb.originalShelterId) : null;
          const isGhostStall = rider?.status === 'unresponsive';
          const remainingMinutes = sb.parentBatch.remainingSafeMinutes;
          const isCriticalSpoil = remainingMinutes <= 15;

          return (
            <div
              key={sb.id}
              className={`rounded-xl border p-5 shadow-lg transition-all space-y-4 ${
                sb.rerouted 
                  ? 'bg-slate-900 border-sky-500/60 ring-1 ring-sky-500/30' 
                  : isGhostStall
                    ? 'bg-slate-900 border-amber-500/80 ring-2 ring-amber-500/40'
                    : sb.status === 'delivered'
                      ? 'bg-slate-900/60 border-slate-800 opacity-80'
                      : 'bg-slate-900 border-slate-800'
              }`}
            >
              
              {/* Card Top: Title & Shelf-Life Countdown */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-white tracking-tight line-clamp-1">
                    {sb.parentBatch.title}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                    <span className="font-mono text-emerald-400 font-semibold">{sb.quantity} {sb.parentBatch.unit}</span>
                    <span aria-hidden="true">·</span>
                    <span>{sb.parentBatch.donorName.split(' ')[0]}</span>
                  </div>
                </div>

                {/* Safe shelf-life badge */}
                <div className="text-right">
                  <div className={`text-xs font-mono font-bold tabular-nums flex items-center gap-1 justify-end ${
                    isCriticalSpoil 
                      ? 'text-rose-400 animate-pulse' 
                      : remainingMinutes < 35 
                        ? 'text-amber-400' 
                        : 'text-emerald-400'
                  }`}>
                    <Clock className="w-3.5 h-3.5" />
                    <span>{Math.round(remainingMinutes)}m safe</span>
                  </div>
                  <span className="text-[10px] text-slate-400">spoilage countdown</span>
                </div>
              </div>

              {/* Transit Progress Bar (if in transit) */}
              {sb.status === 'in_transit' && (
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-slate-400">
                    <span>Progress: {Math.round(sb.progressPercent)}%</span>
                    <span className="text-white">ETA {sb.deliveryEtaMinutes}m</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className={`h-full transition-all duration-500 ${
                        sb.rerouted ? 'bg-sky-400' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${sb.progressPercent}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Reroute Banner if dynamic recovery occurred */}
              {sb.rerouted && (
                <div className="p-2.5 rounded-lg bg-sky-950/40 border border-sky-800/60 text-xs text-sky-200 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-sky-300">
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Mid-Transit Dynamic Reroute</span>
                  </div>
                  <p className="text-[11px] text-sky-300/80 leading-relaxed">
                    Original destination ({originalShelter?.name.split(' ')[0]}) demand closed. Cargo redirected to {targetShelter?.name}.
                  </p>
                </div>
              )}

              {/* Ghost Claim Inactivity Alert if volunteer stalled */}
              {isGhostStall && (
                <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-800/80 text-xs text-amber-200 space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-amber-300">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Ghost Claim Timeout Active</span>
                  </div>
                  <p className="text-[11px] text-amber-300/80 leading-relaxed">
                    Volunteer has not pinged GPS for {rider?.lastHeartbeatSecondsAgo}s. Auto-recovery watchdog is transferring cargo to standby reserve.
                  </p>
                </div>
              )}

              {/* Node Details (Courier & Shelter) */}
              <div className="pt-3 border-t border-slate-800/80 space-y-2 text-xs">
                
                {/* Rider Info */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Bike className="w-3.5 h-3.5 text-sky-400" />
                    Courier:
                  </span>
                  <div className="text-right">
                    <span className="font-medium text-white">
                      {rider ? rider.name : 'Unassigned'}
                    </span>
                    {rider && (
                      <div className="text-[10px] text-slate-400 font-mono">
                        Heartbeat: {rider.lastHeartbeatSecondsAgo}s ago
                      </div>
                    )}
                  </div>
                </div>

                {/* Target Shelter Info */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Home className="w-3.5 h-3.5 text-emerald-400" />
                    Shelter:
                  </span>
                  <span className="font-medium text-white truncate max-w-[170px]">
                    {targetShelter ? targetShelter.name : 'Pending Match'}
                  </span>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                
                {sb.status === 'in_transit' && (
                  <button
                    onClick={() => completeDelivery(sb.id)}
                    className="flex-1 py-1.5 px-3 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Confirm Delivery</span>
                  </button>
                )}

                {isGhostStall && (
                  <button
                    onClick={() => {
                      const standby = standbyRiders[0];
                      if (standby) manualReassignSubBatch(sb.id, standby.id);
                    }}
                    className="flex-1 py-1.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>Auto-Revoke & Assign Standby</span>
                  </button>
                )}

                {sb.status === 'claimed' && !isGhostStall && rider && (
                  <button
                    onClick={() => triggerGhostRiderStall(rider.id)}
                    className="py-1 px-2.5 bg-slate-800 hover:bg-amber-950/40 border border-slate-700 hover:border-amber-500/50 text-slate-300 hover:text-amber-300 text-[11px] rounded transition-colors"
                    title="Simulate volunteer becoming unresponsive to test SLA auto-revocation"
                  >
                    Test Ghost Stall
                  </button>
                )}

                {sb.status === 'in_transit' && !sb.rerouted && (
                  <button
                    onClick={() => {
                      const fallback = shelters.find(s => s.id !== sb.targetShelterId);
                      if (fallback) manualRerouteSubBatch(sb.id, fallback.id);
                    }}
                    className="py-1 px-2.5 bg-slate-800 hover:bg-sky-950/40 border border-slate-700 hover:border-sky-500/50 text-slate-300 hover:text-sky-300 text-[11px] rounded transition-colors"
                    title="Test dynamic mid-journey rerouting"
                  >
                    Reroute Waypoint
                  </button>
                )}

              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
