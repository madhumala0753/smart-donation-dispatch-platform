import React, { useState, useEffect } from 'react';
import { SimulationProvider, useSimulation } from './context/SimulationContext';
import { Header } from './components/Header';
import { JudgeSimulatorBar } from './components/JudgeSimulatorBar';
import { RoleLoginPage } from './components/RoleLoginPage';
import { CorporateLandingView } from './components/CorporateLandingView';
import { DonorPage } from './pages/DonorPage';
import { RiderPage } from './pages/RiderPage';
import { ShelterPage } from './pages/ShelterPage';
import { GoogleMapsDeliveryTracker } from './components/GoogleMapsDeliveryTracker';
import { DonationHistoryView } from './components/DonationHistoryView';
import { NotificationDrawer } from './components/NotificationDrawer';
import { AuditFeed } from './components/AuditFeed';
import { JudgeSimulatorModal } from './components/JudgeSimulatorModal';
import { ProblemStatementModal } from './components/ProblemStatementModal';
import { NewBatchModal } from './components/NewBatchModal';
import { 
  ShieldCheck, 
  Clock, 
  Bike, 
  Home, 
  Building2, 
  AlertTriangle, 
  Plus, 
  FileText,
  Activity,
  MapPin,
  Sparkles,
  ArrowLeftRight,
  History,
  LayoutDashboard
} from 'lucide-react';
import { UserRole } from './types';

function DashboardContent() {
  const { currentUser, batches, riders, shelters, auditLogs, logout, switchRole } = useSimulation();

  const [activeTab, setActiveTab] = useState<string>('corporate_landing');
  const [isJudgeModalOpen, setIsJudgeModalOpen] = useState<boolean>(false);
  const [isProblemModalOpen, setIsProblemModalOpen] = useState<boolean>(false);
  const [isNewBatchModalOpen, setIsNewBatchModalOpen] = useState<boolean>(false);
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState<boolean>(false);
  const [showRoleLoginPage, setShowRoleLoginPage] = useState<boolean>(false);

  // Sync tab on user login
  useEffect(() => {
    if (currentUser?.role === 'donor') {
      setActiveTab('donor_home');
      setShowRoleLoginPage(false);
    } else if (currentUser?.role === 'rider') {
      setActiveTab('rider_home');
      setShowRoleLoginPage(false);
    } else if (currentUser?.role === 'shelter') {
      setActiveTab('shelter_home');
      setShowRoleLoginPage(false);
    } else if (currentUser?.role === 'admin') {
      setActiveTab('corporate_landing');
      setShowRoleLoginPage(false);
    }
  }, [currentUser?.role, currentUser?.id]);

  // If user explicitly opens Role Login / Signup screen or clicked "Sign In"
  if (showRoleLoginPage) {
    return (
      <>
        <RoleLoginPage
          onOpenProblemStatement={() => setIsProblemModalOpen(true)}
          onOpenJudgeSuite={() => setIsJudgeModalOpen(true)}
          onBackToPortals={() => setShowRoleLoginPage(false)}
        />

        <JudgeSimulatorModal
          isOpen={isJudgeModalOpen}
          onClose={() => setIsJudgeModalOpen(false)}
        />

        <ProblemStatementModal
          isOpen={isProblemModalOpen}
          onClose={() => setIsProblemModalOpen(false)}
        />
      </>
    );
  }

  // High-level operational metrics
  const allSubBatches = batches.flatMap(b => b.subBatches);
  const totalMealsInSystem = batches.reduce((acc, b) => acc + b.totalQuantity, 0);
  const activeTransits = allSubBatches.filter(sb => sb.status === 'in_transit').length;
  const autoRecoveries = auditLogs.filter(l => l.type === 'AUTO_REASSIGNED' || l.type === 'DYNAMIC_REROUTE').length;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col font-sans">
      
      {/* 1. Header with Brand, Notifications & Profile Badge */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenJudgeSuite={() => setIsJudgeModalOpen(true)}
        onOpenProblemStatement={() => setIsProblemModalOpen(true)}
        onOpenNotifications={() => setIsNotificationDrawerOpen(true)}
      />

      {/* 2. Interactive Failure Testing Bar */}
      <JudgeSimulatorBar onOpenDetails={() => setIsJudgeModalOpen(true)} />

      {/* Main Container with generous spacious container and breathing room */}
      <main className="flex-1 max-w-[1540px] w-full mx-auto px-6 sm:px-10 lg:px-12 py-8 sm:py-12 space-y-8 sm:space-y-10">
        
        {/* FRONT PAGE: When on 'corporate_landing', show ONLY the Three Specialized Portals */}
        {activeTab === 'corporate_landing' ? (
          <CorporateLandingView
            onSelectRole={(role: UserRole) => {
              switchRole(role);
              if (role === 'donor') setActiveTab('donor_home');
              if (role === 'rider') setActiveTab('rider_home');
              if (role === 'shelter') setActiveTab('shelter_home');
            }}
            onOpenProblemStatement={() => setIsProblemModalOpen(true)}
            onOpenJudgeSuite={() => setIsJudgeModalOpen(true)}
            onOpenNewBatchModal={() => setIsNewBatchModalOpen(true)}
            onOpenMap={() => setActiveTab('map')}
            onOpenRoleLogin={() => setShowRoleLoginPage(true)}
          />
        ) : (
          <div className="space-y-8">
            {/* Navigation & Action Bar for Individual Portal Workspaces */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 sm:p-5 bg-white rounded-3xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1 sm:pb-0">
                <button
                  onClick={() => setActiveTab('corporate_landing')}
                  className="flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-2xl transition-all whitespace-nowrap shadow-2xs"
                >
                  <span>← 3 Portals Front Page</span>
                </button>

                <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block" />

                <button
                  onClick={() => setActiveTab('donor_home')}
                  className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-2xl transition-all whitespace-nowrap ${
                    activeTab === 'donor_home'
                      ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20'
                      : 'bg-slate-50 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Building2 className="w-4 h-4" />
                  <span>1. Food Donors</span>
                </button>

                <button
                  onClick={() => setActiveTab('rider_home')}
                  className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-2xl transition-all whitespace-nowrap ${
                    activeTab === 'rider_home'
                      ? 'bg-sky-600 text-white shadow-sm shadow-sky-600/20'
                      : 'bg-slate-50 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Bike className="w-4 h-4" />
                  <span>2. Delivery Riders</span>
                </button>

                <button
                  onClick={() => setActiveTab('shelter_home')}
                  className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-2xl transition-all whitespace-nowrap ${
                    activeTab === 'shelter_home'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-slate-50 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Home className="w-4 h-4" />
                  <span>3. Food Receivers</span>
                </button>

                <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block" />

                <button
                  onClick={() => setActiveTab('map')}
                  className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-2xl transition-all whitespace-nowrap ${
                    activeTab === 'map'
                      ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20'
                      : 'bg-slate-50 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <MapPin className="w-4 h-4" />
                  <span>Google Maps Routing</span>
                </button>

                <button
                  onClick={() => setActiveTab('history')}
                  className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-2xl transition-all whitespace-nowrap ${
                    activeTab === 'history'
                      ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20'
                      : 'bg-slate-50 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <History className="w-4 h-4" />
                  <span>Donation History</span>
                </button>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowRoleLoginPage(true)}
                  className="flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-2xl transition-colors whitespace-nowrap"
                >
                  <ArrowLeftRight className="w-4 h-4" />
                  <span>Switch Role</span>
                </button>

                <button
                  onClick={() => setIsNewBatchModalOpen(true)}
                  className="flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-2xl transition-all shadow-md shadow-emerald-600/25 whitespace-nowrap active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  <span>Upload Surplus</span>
                </button>
              </div>
            </div>

            {/* Individual Portal Workspaces */}
            <div className="transition-all duration-300">
              {activeTab === 'donor_home' && (
                <DonorPage onOpenNewBatchModal={() => setIsNewBatchModalOpen(true)} />
              )}

              {activeTab === 'rider_home' && (
                <RiderPage />
              )}

              {activeTab === 'shelter_home' && (
                <ShelterPage />
              )}

              {activeTab === 'map' && (
                <GoogleMapsDeliveryTracker />
              )}

              {activeTab === 'history' && (
                <DonationHistoryView />
              )}
            </div>
          </div>
        )}

        {/* Algorithmic Safety Audit Trail */}
        <AuditFeed />

      </main>

      {/* Corporate Green & White Footer */}
      <footer className="border-t border-slate-200 bg-white px-6 py-8 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900">Last-Mile Spoilage Trap</span>
              <span className="text-slate-400 mx-2">·</span>
              <span>Civic Food Rescue Micro-Logistics Engine</span>
            </div>
          </div>

          <div className="flex items-center gap-5 text-slate-600">
            <button
              onClick={() => setIsProblemModalOpen(true)}
              className="hover:text-emerald-700 transition-colors font-medium"
            >
              Problem Statement Specifications
            </button>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <button
              onClick={() => setIsJudgeModalOpen(true)}
              className="hover:text-emerald-700 transition-colors font-medium"
            >
              Failure Testing Sandbox
            </button>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <button
              onClick={() => setActiveTab('history')}
              className="hover:text-emerald-700 transition-colors font-medium"
            >
              ESG Impact Report
            </button>
          </div>
        </div>
      </footer>

      {/* Real-time Notification Drawer */}
      <NotificationDrawer
        isOpen={isNotificationDrawerOpen}
        onClose={() => setIsNotificationDrawerOpen(false)}
      />

      {/* Modals */}
      <JudgeSimulatorModal
        isOpen={isJudgeModalOpen}
        onClose={() => setIsJudgeModalOpen(false)}
      />

      <ProblemStatementModal
        isOpen={isProblemModalOpen}
        onClose={() => setIsProblemModalOpen(false)}
      />

      <NewBatchModal
        isOpen={isNewBatchModalOpen}
        onClose={() => setIsNewBatchModalOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <SimulationProvider>
      <DashboardContent />
    </SimulationProvider>
  );
}
