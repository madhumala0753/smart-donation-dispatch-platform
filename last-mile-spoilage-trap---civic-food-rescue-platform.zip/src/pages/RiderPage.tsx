import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { GoogleMapsDeliveryTracker } from '../components/GoogleMapsDeliveryTracker';
import { 
  Bike, 
  MapPin, 
  Clock, 
  Radio, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  Phone, 
  Navigation,
  Sparkles,
  ArrowRight,
  Package,
  Layers,
  Thermometer,
  KeyRound
} from 'lucide-react';

export const RiderPage: React.FC = () => {
  const { 
    currentUser, 
    riders, 
    batches, 
    shelters, 
    donors,
    sendRiderHeartbeat, 
    triggerGhostRiderStall,
    triggerMidTransitShelterClosure,
    completeDelivery,
    riderAcceptPickup 
  } = useSimulation();

  const [enteredOtp, setEnteredOtp] = useState<string>('');
  const [otpError, setOtpError] = useState<string | null>(null);

  // Current rider
  const currentRider = riders.find(r => r.id === currentUser?.id) || riders[3]; // Alex D'Souza
  const allSubBatches = batches.flatMap(b => b.subBatches.map(sb => ({ ...sb, parentBatch: b })));
  const activeSubBatch = allSubBatches.find(sb => sb.id === currentRider?.activeSubBatchId);
  const targetShelter = shelters.find(s => s.id === activeSubBatch?.targetShelterId);
  const isGhostStall = currentRider.status === 'unresponsive';

  // Open pickup requests waiting for a courier
  const openPickupRequests = allSubBatches.filter(sb => sb.status === 'pending_rider');

  const handleVerifyOtpHandover = () => {
    if (!activeSubBatch) return;
    completeDelivery(activeSubBatch.id);
    setEnteredOtp('');
    setOtpError(null);
  };

  return (
    <div className="space-y-8 sm:space-y-10">
      
      {/* Rider Header (Green & White Theme) - Spacious & Airy */}
      <div className="p-6 sm:p-8 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-3xl border border-emerald-200/90 shadow-sm flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700 shadow-sm shrink-0">
            <Bike className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-bold bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-300">
                Verified Civic Courier
              </span>
              <span className="text-xs text-emerald-700 font-medium">Zone 4 Arterial Grid</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
              {currentRider.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600">
              Vehicle: <strong className="text-slate-800">{currentRider.vehicleType.toUpperCase()} (Capacity: {currentRider.maxCapacity} units)</strong> · Reliability Rating: <strong className="text-emerald-700 font-mono">★ {currentRider.rating || 4.9} ({currentRider.completedDeliveriesCount} rescues)</strong>
            </p>
          </div>
        </div>

        {/* Heartbeat Status */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => sendRiderHeartbeat(currentRider.id)}
            className="flex items-center gap-2 px-6 py-3 bg-white hover:bg-slate-50 border border-emerald-300 text-slate-800 font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-xs active:scale-95"
          >
            <Radio className="w-4 h-4 text-emerald-600 animate-pulse" />
            <span>Send GPS Breadcrumb ({currentRider.lastHeartbeatSecondsAgo}s ago)</span>
          </button>
        </div>
      </div>

      {/* Dynamic Mid-Transit Reroute Alert */}
      {activeSubBatch?.rerouted && (
        <div className="p-5 sm:p-6 bg-sky-100/90 border-2 border-sky-300 rounded-3xl shadow-sm text-xs sm:text-sm text-sky-950 flex flex-wrap items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-sky-200 text-sky-800 flex items-center justify-center shrink-0">
              <Navigation className="w-6 h-6 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <div>
              <h4 className="text-sm sm:text-base font-bold text-sky-900">
                DYNAMIC IN-TRANSIT DESTINATION REROUTE ACTIVE
              </h4>
              <p className="text-xs sm:text-sm text-sky-800 mt-1">
                Destination <strong>Shelter Alpha</strong> filled by a local walk-in citizen donation. Automatic collision detector safely redirected you to <strong>Shelter Echo</strong> (Safe window intact!).
              </p>
            </div>
          </div>
          <span className="px-4 py-2 bg-white text-sky-900 font-bold rounded-2xl border border-sky-200 shadow-2xs font-mono text-sm">
            New ETA: {activeSubBatch.deliveryEtaMinutes}m
          </span>
        </div>
      )}

      {/* Ghost Stall Inactivity Warning */}
      {isGhostStall && (
        <div className="p-5 sm:p-6 bg-amber-100/90 border-2 border-amber-300 rounded-3xl shadow-sm text-xs sm:text-sm text-amber-950 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-200 text-amber-800 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm sm:text-base font-bold text-amber-900">
                SLA BREACH: GHOST CLAIM TIMEOUT INITIATED
              </h4>
              <p className="text-xs sm:text-sm text-amber-800 mt-1">
                No GPS breadcrumb for {currentRider.lastHeartbeatSecondsAgo}s. Auto-recovery watchdog is preparing to transfer custody to Standby Maya. Tap Heartbeat to restore active state.
              </p>
            </div>
          </div>
          <button
            onClick={() => sendRiderHeartbeat(currentRider.id)}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl shadow-xs"
          >
            Restore GPS Ping
          </button>
        </div>
      )}

      {/* Available Pickup Requests Queue */}
      <div className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-600" />
            Open Pickup Requests Waiting for Couriers ({openPickupRequests.length})
          </h3>
          <span className="text-xs sm:text-sm text-slate-500">Nearby within 3.5 km arterial zone</span>
        </div>

        {openPickupRequests.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8">
            {openPickupRequests.map(request => {
              const reqDonor = donors.find(d => d.id === request.donorId);
              const reqShelter = shelters.find(s => s.id === request.targetShelterId);

              return (
                <div key={request.id} className="p-6 bg-white rounded-3xl border border-slate-200/90 shadow-sm space-y-4 hover:border-emerald-300 transition-all flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <span className="text-[11px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        SURPLUS READY
                      </span>
                      <span className="text-xs font-mono font-bold text-amber-600 tabular-nums">
                        {Math.round(request.parentBatch.remainingSafeMinutes)}m safe
                      </span>
                    </div>

                    <div>
                      <h4 className="text-base font-bold text-slate-900 line-clamp-1">
                        {request.parentBatch.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-slate-500 mt-1">
                        {reqDonor?.name} · <strong className="text-slate-800">{request.quantity} {request.parentBatch.unit}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs sm:text-sm">
                    <span className="text-slate-500 truncate max-w-[140px]">Dest: {reqShelter?.name.split(' ')[0]}</span>
                    <button
                      onClick={() => riderAcceptPickup(request.id, currentRider.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors shrink-0"
                    >
                      Accept Delivery
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 bg-emerald-50/50 rounded-3xl border border-emerald-200 text-xs sm:text-sm text-emerald-900 flex items-center justify-between">
            <span>✓ All nearby surplus lots currently have assigned couriers en route.</span>
            <span className="font-mono font-semibold">Fleet Balanced</span>
          </div>
        )}
      </div>

      {/* GOOGLE MAPS NAVIGATION ENGINE */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            Turn-by-Turn Google Maps Delivery Routing
          </h3>
          <span className="text-xs sm:text-sm text-slate-500">
            Real-time arterial tracking with dynamic waypoint rerouting
          </span>
        </div>

        <GoogleMapsDeliveryTracker />
      </div>

      {/* Active Cargo Mission Sheet & Handover OTP */}
      {activeSubBatch && (
        <div className="p-7 sm:p-9 bg-white rounded-3xl border border-slate-200/90 shadow-sm space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-6 pb-6 border-b border-slate-100">
            <div className="space-y-1">
              <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider block">
                Active Manifest Handover
              </span>
              <h4 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                {activeSubBatch.parentBatch.title}
              </h4>
              <p className="text-xs sm:text-sm text-slate-500">
                Food Grade Thermal Box · Maintained above 65°C
              </p>
            </div>

            <div className="text-left sm:text-right">
              <div className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-600 tabular-nums">
                {activeSubBatch.quantity} Meals
              </div>
              <span className="text-xs text-slate-400 block mt-0.5">Payload Weight: ~22kg</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="p-4 sm:p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
              <span className="text-slate-500 font-medium text-xs">Pickup Origin:</span>
              <div className="font-bold text-slate-900 text-sm sm:text-base">{activeSubBatch.parentBatch.donorName}</div>
              <div className="text-slate-500 text-xs">Sector 4, Central Avenue</div>
            </div>

            <div className="p-4 sm:p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
              <span className="text-slate-500 font-medium text-xs">Drop-off Destination:</span>
              <div className="font-bold text-slate-900 text-sm sm:text-base">{targetShelter?.name}</div>
              <div className="text-slate-500 text-xs">{targetShelter?.address}</div>
            </div>
          </div>

          {/* Handover OTP Verification Box */}
          <div className="p-5 sm:p-6 bg-emerald-50/70 rounded-2xl border border-emerald-200 flex flex-wrap items-center justify-between gap-6 text-xs sm:text-sm">
            <div className="flex items-center gap-4">
              <KeyRound className="w-6 h-6 text-emerald-700 shrink-0" />
              <div>
                <span className="font-bold text-emerald-950">Shelter Verification Passcode:</span>
                <span className="font-mono text-emerald-800 text-base sm:text-lg font-extrabold ml-2">
                  {activeSubBatch.otpCode || '5821'}
                </span>
                <div className="text-xs text-emerald-700 mt-0.5">Share with shelter coordinator upon physical handover</div>
              </div>
            </div>

            <button
              onClick={handleVerifyOtpHandover}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-md shadow-emerald-600/20 active:scale-95 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm Shelter Handover</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
