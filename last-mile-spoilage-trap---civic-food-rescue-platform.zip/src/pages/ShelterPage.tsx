import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { FoodSafetyCheckModal } from '../components/FoodSafetyCheckModal';
import { 
  Home, 
  Droplets, 
  Flame, 
  Snowflake, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Users, 
  MapPin, 
  Bike,
  Plus,
  Clock,
  ArrowRight,
  Package,
  Search,
  Filter,
  FileCheck,
  Check,
  ShieldCheck
} from 'lucide-react';
import { Batch } from '../types';

export const ShelterPage: React.FC = () => {
  const { 
    currentUser, 
    shelters, 
    riders, 
    batches, 
    resolvePrerequisite, 
    triggerMidTransitShelterClosure,
    completeDelivery,
    receiverRequestFood 
  } = useSimulation();

  const [searchFilter, setSearchFilter] = useState('');
  const [selectedBatchSafety, setSelectedBatchSafety] = useState<Batch | null>(null);

  // Current shelter
  const currentShelter = shelters.find(s => s.id === currentUser?.id) || shelters[0];
  const unmetMeals = currentShelter.demandRemaining.cooked_meals;
  const isDemandFilled = unmetMeals === 0;

  // Inbound deliveries heading to this shelter
  const allSubBatches = batches.flatMap(b => b.subBatches.map(sb => ({ ...sb, parentBatch: b })));
  const inboundDeliveries = allSubBatches.filter(sb => sb.targetShelterId === currentShelter.id && sb.status === 'in_transit');

  // Available surplus catalog for receivers to browse
  const availableSurplusFeed = batches.filter(b => b.remainingSafeMinutes > 10 && b.status !== 'completed');

  return (
    <div className="space-y-8 sm:space-y-10">
      
      {/* Shelter Header (Green & White Theme) - Spacious & Airy */}
      <div className="p-6 sm:p-8 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-3xl border border-emerald-200/90 shadow-sm flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700 shadow-sm shrink-0">
            <Home className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-bold bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-300">
                Verified Civic Receiving Facility
              </span>
              <span className="text-xs text-emerald-700 font-medium">{currentShelter.address}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
              {currentShelter.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600">
              Coordinator: <strong className="text-slate-800">{currentUser?.name || currentShelter.contactPerson}</strong> · Direct Hotline: {currentShelter.phone} · Total Meals Received: {currentShelter.receivedMealsTotal || 3420}
            </p>
          </div>
        </div>

        {/* Walk-in Citizen Dropoff Trigger */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => triggerMidTransitShelterClosure(currentShelter.id, 50)}
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl transition-all shadow-md shadow-emerald-600/20 active:scale-95 flex items-center gap-2"
            title="Simulate a local citizen walking into this shelter with 50 meals, dropping unmet demand to 0 and triggering automated mid-journey rerouting for incoming couriers"
          >
            <Plus className="w-4 h-4" />
            <span>Log Walk-in Citizen Surplus (+50 Meals)</span>
          </button>
        </div>
      </div>

      {/* Shelter Live Status Strips - Airy & Spacious */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
        
        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Shelter Bed Capacity</span>
            <Users className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 tabular-nums">
              {currentShelter.currentOccupants} <span className="text-sm font-normal text-slate-400 font-sans">/ {currentShelter.capacityMax} beds</span>
            </div>
          </div>
          <div className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100">
            {currentShelter.capacityMax - currentShelter.currentOccupants} beds currently open
          </div>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Unmet Meals Demand</span>
            <Home className="w-5 h-5 text-rose-500" />
          </div>
          <div className="my-3">
            <div className={`text-3xl sm:text-4xl font-extrabold font-mono tabular-nums ${isDemandFilled ? 'text-slate-400' : 'text-rose-600'}`}>
              {unmetMeals} <span className="text-sm font-normal text-slate-400 font-sans">meals</span>
            </div>
          </div>
          <div className="text-xs text-slate-500 font-medium pt-3 border-t border-slate-100">
            {isDemandFilled ? 'Demand fully satisfied by walk-in donation' : 'Awaiting courier drop-off'}
          </div>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Inbound Couriers En Route</span>
            <Bike className="w-5 h-5 text-sky-600" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-sky-600 tabular-nums">
              {inboundDeliveries.length} <span className="text-sm font-normal text-slate-400 font-sans">couriers</span>
            </div>
          </div>
          <div className="text-xs text-sky-700 font-medium pt-3 border-t border-slate-100">
            Live GPS telemetry active
          </div>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Ground Hygiene Health</span>
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-600 tabular-nums">
              {currentShelter.prerequisites.cleanWater ? '100%' : '66%'}
            </div>
          </div>
          <div className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100">
            {currentShelter.prerequisites.cleanWater ? 'Clean water verified' : 'Water verification pending'}
          </div>
        </div>

      </div>

      {/* 1. BROWSE AVAILABLE SURPLUS FOOD CATALOG (Prompt Requirement) */}
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Package className="w-5 h-5 text-emerald-600" />
              Browse Available Food Surplus Catalog
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Available batches posted by registered banquet halls and commercial kitchens nearby.
            </p>
          </div>

          <div className="relative min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search surplus catalog..."
              value={searchFilter}
              onChange={e => setSearchFilter(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:border-emerald-500 shadow-2xs"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {availableSurplusFeed.map(batch => (
            <div key={batch.id} className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm space-y-4 hover:border-emerald-300 transition-all flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 uppercase">
                    {batch.dietaryType}
                  </span>
                  <div className="text-right">
                    <span className="text-xs sm:text-sm font-mono font-bold text-amber-600 tabular-nums">
                      {Math.round(batch.remainingSafeMinutes)}m safe
                    </span>
                  </div>
                </div>

                <h4 className="text-base font-bold text-slate-900 line-clamp-1">{batch.title}</h4>
                <p className="text-xs sm:text-sm text-slate-500 line-clamp-2">{batch.description}</p>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs sm:text-sm text-slate-600">
                  <span>Donor: <strong className="text-slate-800">{batch.donorName.split(' ')[0]}</strong></span>
                  <strong className="font-mono text-emerald-700 text-sm">{batch.totalQuantity} {batch.unit}</strong>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                <button
                  onClick={() => setSelectedBatchSafety(batch)}
                  className="text-xs sm:text-sm text-slate-500 hover:text-emerald-700 font-semibold underline underline-offset-4 flex items-center gap-1.5"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Safety Check</span>
                </button>

                <button
                  onClick={() => receiverRequestFood(batch.id, currentShelter.id, 45)}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors active:scale-95 flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>Request Donation</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Inbound Couriers & Handover Verification */}
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider">
            Inbound Couriers & Delivery Handover
          </h3>
          <span className="text-xs text-slate-500">Real-time arrival estimation</span>
        </div>

        {inboundDeliveries.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            {inboundDeliveries.map(sb => {
              const rider = riders.find(r => r.id === sb.riderId);

              return (
                <div key={sb.id} className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-mono font-bold text-sky-800 bg-sky-50 px-3 py-1 rounded-full border border-sky-200">
                        IN TRANSIT · ETA {sb.deliveryEtaMinutes}m
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-slate-900 mt-2">
                        {sb.parentBatch.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                        Courier: <strong className="text-slate-800">{rider?.name}</strong> ({rider?.vehicleType.toUpperCase()})
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-lg font-mono font-bold text-emerald-700">
                        {sb.quantity} Meals
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono">
                      Safe Shelf-Life: {Math.round(sb.parentBatch.remainingSafeMinutes)}m left
                    </span>
                    <button
                      onClick={() => completeDelivery(sb.id)}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs"
                    >
                      Sign & Accept Handover
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 sm:p-10 bg-white rounded-3xl border border-slate-200/90 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
            <h4 className="text-base font-bold text-slate-800">
              {isDemandFilled ? 'Meal Requirements Fully Satisfied' : 'No Inbound Couriers en route'}
            </h4>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
              {isDemandFilled 
                ? 'Local citizen walk-in surplus covered tonight\'s requirements. Incoming couriers have been safely rerouted to Shelter Echo.'
                : 'Browse the surplus catalog above to request food, or click "Log Walk-in Citizen Surplus" to simulate a walk-in drop-off.'}
            </p>
          </div>
        )}
      </div>

      {/* 3. Ground Prerequisite Certification */}
      <div className="p-6 sm:p-8 bg-white rounded-3xl border border-slate-200/90 shadow-sm space-y-6">
        <div>
          <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider">
            Ground Prerequisite Certification (Problem Statement Challenge 4)
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Strict dependency rules prevent dangerous distribution of powdered baby formula or raw lentils to facilities without clean potable water or cooking fuel.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
          
          {/* Clean Water */}
          <div className="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-sky-500" />
                  <span className="text-sm font-bold text-slate-800">Clean Potable Water</span>
                </div>
                {currentShelter.prerequisites.cleanWater ? (
                  <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">VERIFIED ✓</span>
                ) : (
                  <span className="text-xs font-mono font-bold text-rose-700 bg-rose-100 px-2.5 py-0.5 rounded-full border border-rose-300">MISSING ⚠</span>
                )}
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Required for reconstituting powdered infant formula without waterborne infection risks.
              </p>
            </div>
            {!currentShelter.prerequisites.cleanWater && (
              <button
                onClick={() => resolvePrerequisite(currentShelter.id, 'cleanWater')}
                className="w-full py-2 px-3 bg-white border border-rose-300 text-rose-800 font-semibold text-xs rounded-xl hover:bg-rose-50 transition-colors shadow-2xs mt-2"
              >
                Certify Water Purification
              </button>
            )}
          </div>

          {/* Cooking Fuel */}
          <div className="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame className="w-5 h-5 text-amber-500" />
                  <span className="text-sm font-bold text-slate-800">Cooking Fuel / LPG</span>
                </div>
                {currentShelter.prerequisites.cookingFuel ? (
                  <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">VERIFIED ✓</span>
                ) : (
                  <span className="text-xs font-mono font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">MISSING ⚠</span>
                )}
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Required for raw dry ration kits (wheat, rice, pulses) to be boiled and cooked safely.
              </p>
            </div>
            {!currentShelter.prerequisites.cookingFuel && (
              <button
                onClick={() => resolvePrerequisite(currentShelter.id, 'cookingFuel')}
                className="w-full py-2 px-3 bg-white border border-amber-300 text-amber-800 font-semibold text-xs rounded-xl hover:bg-amber-50 transition-colors shadow-2xs mt-2"
              >
                Register Gas Cylinders
              </button>
            )}
          </div>

          {/* Cold Storage */}
          <div className="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Snowflake className="w-5 h-5 text-emerald-500" />
                  <span className="text-sm font-bold text-slate-800">Cold Chain Storage</span>
                </div>
                {currentShelter.prerequisites.coldStorage ? (
                  <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">ACTIVE ✓</span>
                ) : (
                  <span className="text-xs font-mono text-slate-400">NOT EQUIPPED</span>
                )}
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Refrigeration units (2°C–8°C) for preserving pediatric insulin and antibiotics.
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Food Safety Modal */}
      {selectedBatchSafety && (
        <FoodSafetyCheckModal
          isOpen={!!selectedBatchSafety}
          onClose={() => setSelectedBatchSafety(null)}
          safetyCheck={selectedBatchSafety.safetyCheck}
          title={selectedBatchSafety.title}
        />
      )}

    </div>
  );
};
