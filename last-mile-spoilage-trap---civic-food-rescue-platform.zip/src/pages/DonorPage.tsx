import React, { useState } from 'react';
import { useSimulation } from '../context/SimulationContext';
import { FoodSafetyCheckModal } from '../components/FoodSafetyCheckModal';
import { 
  Building2, 
  Clock, 
  Plus, 
  Split, 
  Bike, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
  MapPin,
  Thermometer,
  FileCheck,
  Layers
} from 'lucide-react';
import { AidItemType, Batch } from '../types';

interface DonorPageProps {
  onOpenNewBatchModal: () => void;
}

export const DonorPage: React.FC<DonorPageProps> = ({ onOpenNewBatchModal }) => {
  const { currentUser, donors, batches, triggerBulkSurgePartition } = useSimulation();

  const [selectedBatchForSafety, setSelectedBatchForSafety] = useState<Batch | null>(null);

  const currentDonor = donors.find(d => d.id === currentUser?.id) || donors[0];
  const myBatches = batches.filter(b => b.donorId === currentDonor.id);
  const totalMealsDonated = myBatches.reduce((acc, b) => acc + b.totalQuantity, 0);

  return (
    <div className="space-y-8 sm:space-y-10">
      
      {/* Donor Header (Green & White Theme) - Spacious & Airy */}
      <div className="p-6 sm:p-8 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-3xl border border-emerald-200/90 shadow-sm flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700 shadow-sm shrink-0">
            <Building2 className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-bold bg-emerald-100/90 px-3 py-1 rounded-full border border-emerald-300">
                Verified Food Surplus Donor
              </span>
              <span className="text-xs text-emerald-700 font-medium">FSSAI #{currentDonor.fssaiNumber || '10018022007844'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
              {currentDonor.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600">
              Pickup Location: <strong className="text-slate-800">{currentDonor.address}</strong> · Contact: {currentUser?.name || currentDonor.contactPerson} ({currentDonor.phone})
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => triggerBulkSurgePartition(180, 65)}
            className="px-5 py-3 text-xs sm:text-sm font-semibold text-emerald-900 bg-emerald-200/80 hover:bg-emerald-300 border border-emerald-300 rounded-2xl transition-all shadow-xs"
            title="Simulate 180 cooked biryani meals bulk surplus from Grand Palace"
          >
            Simulate 180-Meal Bulk Surplus
          </button>

          <button
            onClick={onOpenNewBatchModal}
            className="flex items-center gap-2 px-6 py-3 text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-2xl transition-all shadow-md shadow-emerald-600/20 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Surplus Food</span>
          </button>
        </div>
      </div>

      {/* Metric Strips - Airy and Spacious */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
        
        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Surplus Portions Donated</span>
            <Building2 className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 tabular-nums">
              {totalMealsDonated} <span className="text-sm font-normal text-slate-400 font-sans">units</span>
            </div>
          </div>
          <div className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100">
            Zero discarded at kitchen gate
          </div>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Auto-Partitioned Courier Runs</span>
            <Split className="w-5 h-5 text-sky-600" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-slate-900 tabular-nums">
              {myBatches.reduce((acc, b) => acc + b.subBatches.length, 0)} <span className="text-sm font-normal text-slate-400 font-sans">legs</span>
            </div>
          </div>
          <div className="text-xs text-sky-700 font-medium pt-3 border-t border-slate-100">
            Matched to vehicle capacities
          </div>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Thermal Food Safety Score</span>
            <Thermometer className="w-5 h-5 text-rose-500" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-600 tabular-nums">
              99.4%
            </div>
          </div>
          <div className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100">
            Maintained above 65°C hot-holding
          </div>
        </div>

        <div className="p-6 sm:p-7 bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:border-emerald-300 transition-all flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs sm:text-sm text-slate-500 font-medium">
            <span>Spoilage Prevention Rate</span>
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
          </div>
          <div className="my-3">
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-600 tabular-nums">
              100%
            </div>
          </div>
          <div className="text-xs text-emerald-700 font-medium pt-3 border-t border-slate-100">
            Overcoming status quo 40% loss
          </div>
        </div>

      </div>

      {/* Active Batches Logged & Courier Pickup Status */}
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider">
              Active Perishable Surplus Listings & Pickup Requests ({myBatches.length})
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              Real-time safe consumption countdown & automated courier allocation
            </p>
          </div>
          <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Live Telemetry Sync
          </span>
        </div>

        {myBatches.length > 0 ? (
          <div className="space-y-6">
            {myBatches.map(batch => (
              <div 
                key={batch.id} 
                className="p-6 sm:p-8 bg-white rounded-3xl border border-slate-200/90 shadow-sm space-y-6"
              >
                {/* Master Batch Info */}
                <div className="flex flex-wrap items-start justify-between gap-6 pb-6 border-b border-slate-100">
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-3">
                      <h4 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                        {batch.title}
                      </h4>
                      <span className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                        {batch.totalQuantity} {batch.unit}
                      </span>
                      <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-md uppercase">
                        {batch.dietaryType}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-slate-500">
                      <span>Pickup: <strong className="text-slate-700">{batch.pickupAddress}</strong></span>
                      <span aria-hidden="true">·</span>
                      <span>Prepared {batch.preparedTimeAgoMinutes}m ago</span>
                      <span aria-hidden="true">·</span>
                      <button
                        onClick={() => setSelectedBatchForSafety(batch)}
                        className="text-emerald-700 font-bold hover:text-emerald-800 underline underline-offset-4 flex items-center gap-1.5"
                      >
                        <FileCheck className="w-4 h-4" />
                        <span>View Safety Audit ({batch.safetyCheck.preparedTempC}°C)</span>
                      </button>
                    </div>
                  </div>

                  {/* Perishable Safe Countdown */}
                  <div className="text-left sm:text-right">
                    <div className="text-lg sm:text-xl font-bold font-mono text-amber-600 tabular-nums flex items-center gap-2 justify-start sm:justify-end">
                      <Clock className="w-5 h-5 text-amber-500" />
                      <span>{Math.round(batch.remainingSafeMinutes)} mins safe window</span>
                    </div>
                    <span className="text-xs text-slate-400 mt-0.5 block">Strict thermal consumption clock</span>
                  </div>
                </div>

                {/* Sub-Batch Micro-Courier Parcel Splits */}
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between text-xs sm:text-sm text-slate-600 gap-2">
                    <span className="font-bold flex items-center gap-2 text-slate-800">
                      <Split className="w-4 h-4 text-emerald-600" />
                      Auto-Decomposition Matrix: {batch.subBatches.length} Parallel Courier Legs
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Overcoming single-point transport limit
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
                    {batch.subBatches.map((sb, idx) => (
                      <div 
                        key={sb.id} 
                        className={`p-4 sm:p-5 rounded-2xl border text-xs sm:text-sm space-y-3 transition-all ${
                          sb.rerouted 
                            ? 'bg-sky-50/80 border-sky-300 text-sky-950 shadow-2xs' 
                            : sb.status === 'delivered' 
                              ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950 shadow-2xs' 
                              : 'bg-slate-50 border-slate-200/90'
                        }`}
                      >
                        <div className="flex justify-between font-mono font-bold text-xs">
                          <span className="text-slate-600">Parcel #{idx + 1}</span>
                          <span className="text-emerald-700 font-bold">{sb.quantity} {batch.unit}</span>
                        </div>

                        <div className="text-slate-700 flex items-center gap-2">
                          <Bike className="w-4 h-4 text-slate-400 shrink-0" />
                          <span className="font-semibold truncate">
                            {sb.riderId ? `Courier ${sb.riderId.replace('rider_', '').toUpperCase()}` : 'Assigning Courier...'}
                          </span>
                        </div>

                        <div className="pt-2.5 border-t border-slate-200/60 flex justify-between font-mono text-xs">
                          <span className={sb.rerouted ? 'text-sky-700 font-bold' : 'text-slate-500'}>
                            {sb.rerouted ? 'REROUTED' : sb.status.toUpperCase()}
                          </span>
                          <span className="text-slate-800 font-bold">ETA {sb.deliveryEtaMinutes}m</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
            <Building2 className="w-10 h-10 text-slate-300 mx-auto" />
            <h4 className="text-sm font-bold text-slate-700">No Active Surplus Batches</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Ready to log cooked banquet meals or clinical supplies before safe consumption expires.
            </p>
            <button
              onClick={onOpenNewBatchModal}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-xs"
            >
              Upload First Surplus Lot
            </button>
          </div>
        )}
      </div>

      {/* Food Safety Modal */}
      {selectedBatchForSafety && (
        <FoodSafetyCheckModal
          isOpen={!!selectedBatchForSafety}
          onClose={() => setSelectedBatchForSafety(null)}
          safetyCheck={selectedBatchForSafety.safetyCheck}
          title={selectedBatchForSafety.title}
        />
      )}

    </div>
  );
};
